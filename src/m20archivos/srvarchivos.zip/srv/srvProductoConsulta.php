<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/dao/productoConsulta.php";

ejecuta(function () {
 $lista = productoConsulta();
 $render = "";
 foreach ($lista as $it) {
  $prodId = htmlentities($it->prodId);
  $prodNombre = htmlentities($it->prodNombre);
  $archId = $it->archId === null
   ? ""
   : htmlentities($it->archId);
  $render .=
   "<div style='display: flex; flex-direction: row-reverse;
      align-items: center; gap: 0.5rem'>
     <dt style='flex: 1 1 0'>
      <a href='modifica.html?id=$prodId'>{$prodNombre}</a>
     </dt>
     <dd style='flex: 1 1 0; margin: 0'>
      <a href='modifica.html?id=$prodId'><img style='width: 100%'
        alt='Imagen del producto' src='srv/srvArchivo.php?id=$archId'></a>
     </dd>
    </div>";
 }
 return $render;
});
