<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/dao/productoBusca.php";

ejecuta(function () {
 $id = leeEntero("id");
 if ($id === null)
  throw new Exception("Falta el parámetro id.");
 $modelo = productoBusca($id);
 if ($modelo === false) {
  throw new Exception("Producto no encontrado.");
 } else {
  return [
   "id" => $modelo->id,
   "nombre" => $modelo->nombre,
   "imagen" => "srv/srvArchivo.php?id=" . $modelo->archivo->id,
  ];
 }
});
