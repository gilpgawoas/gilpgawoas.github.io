<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "srv/dao/productoAgrega.php";
require_once "lib/php/" .
 "leeSinEspaciosInFin.php";
require_once
 "lib/php/leeBytes.php";

use \lib\php\Servicio;
use \srv\modelo\Archivo;
use \srv\modelo\Producto;

class SrvProductoAgrega
extends Servicio
{

 protected
 function implementacion()
 {
  $modelo = new Producto();
  $modelo->nombre =
   leeSinEspaciosInFin("nombre");

  $archivo = new Archivo();
  $archivo->bytes =
   leeBytes("bytes");
  $modelo->archivo = $archivo;
  productoAgrega($modelo);
  /* Los bytes se daescargan con
   * SrvArchivo. */
  $archivo->bytes = "";
  return $modelo;
 }
}

$servicio =
 new SrvProductoAgrega();
$servicio->ejecuta();
