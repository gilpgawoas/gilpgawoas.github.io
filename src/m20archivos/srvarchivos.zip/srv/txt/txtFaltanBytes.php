<?php

function txtFaltanBytes()
{
 return "Falta el contenido del "
  . "archivo.";
}
