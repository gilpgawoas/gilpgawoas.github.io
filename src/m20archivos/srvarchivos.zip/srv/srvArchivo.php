<?php

require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/dao/AccesoBd.php";
require_once __DIR__ . "/dao/archivoBusca.php";

mb_internal_encoding("UTF-8");
try {
 // Evita que la imagen se cargue en el caché de la computadora.
 header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
 header("Cache-Control: post-check=0, pre-check=0", false);
 header("Pragma: no-cache");
 $con = AccesoBd::getCon();
 $id = leeEntero("id");
 if ($id === null)
  throw new Exception("Falta el parámetro id.");
 $archivo = archivoBusca($id);
 if ($archivo === false) {
  throw new Exception("Archivo no encontrado.");
 }
 echo $archivo->bytes;
} catch (Throwable $t) {
 http_response_code(500);
 echo $t->getMessage();
}
