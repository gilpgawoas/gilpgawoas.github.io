<?php

require_once __DIR__ . "/../../lib/php/recibeFetchAll.php";
require_once __DIR__ . "/../modelo/Producto.php";
require_once __DIR__ . "/AccesoBd.php";

function productoConsulta()
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
    P.PROD_ID AS prodId,
    P.PROD_NOMBRE AS prodNombre,
    A.ARCH_ID AS archId
   FROM PRODUCTO P
    LEFT JOIN ARCHIVO A
    ON P.ARCH_ID = A.ARCH_ID
   ORDER BY P.PROD_NOMBRE"
 );
 $resultado = $stmt->fetchAll(PDO::FETCH_OBJ);
 return recibeFetchAll($resultado);
}
