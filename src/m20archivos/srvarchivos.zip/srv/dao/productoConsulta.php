<?php

require_once
 "lib/php/recibeFetchAll.php";

use srv\dao\AccesoBd;

function productoConsulta()
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
    P.PROD_ID AS prodId,
    P.PROD_NOMBRE AS prodNombre,
    A.ARCH_ID AS archId
   FROM PRODUCTO P
    LEFT JOIN ARCHIVO A
    ON P.ARCH_ID = A.ARCH_ID
   ORDER BY P.PROD_NOMBRE"
 );
 $resultado = $stmt->fetchAll(
  PDO::FETCH_OBJ
 );
 return recibeFetchAll($resultado);
}
