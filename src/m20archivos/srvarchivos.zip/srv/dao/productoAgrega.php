<?php

require_once
 "srv/dao/archivoAgrega.php";

use srv\dao\AccesoBd;
use srv\modelo\Producto;

function productoAgrega(
 Producto $modelo
) {
 $modelo->validaNuevo();
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 archivoAgrega($modelo->archivo);
 $stmt = $con->prepare(
  "INSERT INTO PRODUCTO
    (PROD_NOMBRE, ARCH_ID)
   VALUES
    (:nombre, :archId)"
 );
 $stmt->execute([
  ":nombre" => $modelo->nombre,
  ":archId" => $modelo->archivo->id
 ]);
 /* Si usas una secuencia para
  * generar el id, pasa como
  * parámetro de lastInsertId el
  * nombre de dicha secuencia. */
 $modelo->id =
  $con->lastInsertId();
 $con->commit();
}
