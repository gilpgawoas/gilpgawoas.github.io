<?php

require_once __DIR__ . "/../modelo/Archivo.php";
require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/archivoAgrega.php";

function productoAgrega(Producto $modelo)
{
 $modelo->validaNuevo();
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 archivoAgrega($modelo->archivo);
 $stmt = $con->prepare(
  "INSERT INTO PRODUCTO
    (PROD_NOMBRE, ARCH_ID)
   VALUES
    (:nombre, :archId)"
 );
 $stmt->execute([
  ":nombre" => $modelo->nombre,
  ":archId" => $modelo->archivo->id
 ]);
 /* Si usas una secuencia para generar el id,
  * pasa como parámetro de lastInsertId el
  * nombre de dicha secuencia. */
  $modelo->id = $con->lastInsertId();
  $con->commit();
}
