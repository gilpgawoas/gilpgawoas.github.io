<?php

require_once "srv/txt/" .
 "txtProductoNoEncontrado.php";
require_once "srv/txt/"
 . "txtFaltaElArchivoAnterior.php";
require_once
 "srv/dao/productoBusca.php";
require_once
 "srv/dao/archivoModifica.php";

use srv\dao\AccesoBd;
use srv\modelo\Producto;

function productoModifica(
 Producto $modelo
) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 $archivo = $modelo->archivo;
 $anterior =
  productoBusca($modelo->id);
 if ($anterior === false) {
  throw new Exception(
   txtProductoNoEncontrado()
  );
 }
 if ($anterior->archivo === null) {
  throw new Exception(
   txtFaltaElArchivoAnterior()
  );
 }
 if ($archivo === null) {
  $archivo = $anterior->archivo;
  $modelo->archivo = $archivo;
 } else {
  $archivo->id =
   $anterior->archivo->id;
  archivoModifica($archivo);
 }
 $stmt = $con->prepare(
  "UPDATE PRODUCTO
   SET
    PROD_NOMBRE = :nombre,
    ARCH_ID = :archId
   WHERE PROD_ID = :id"
 );
 $stmt->execute([
  ":id" => $modelo->id,
  ":nombre" => $modelo->nombre,
  ":archId" => $archivo->id
 ]);
 $con->commit();
}
