<?php

require_once __DIR__ . "/../modelo/Producto.php";
require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/archivoModifica.php";

function productoModifica(Producto $modelo)
{
 $modelo->valida();
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 $archivo = $modelo->archivo;
 $anterior = productoBusca($modelo->id);
 if ($anterior === false) {
  throw new Exception("Producto no encontrado.");
 }
 if ($anterior->archivo === null) {
  throw new Exception("Falta el archivo anterior.");
 }
 if ($archivo === null) {
  $archivo = $anterior->archivo;
  $modelo->archivo = $archivo;
 } else {
  $archivo->id = $anterior->archivo->id;
  archivoModifica($archivo);
 }
 $stmt = $con->prepare(
  "UPDATE PRODUCTO
   SET
    PROD_NOMBRE = :nombre,
    ARCH_ID = :archId
   WHERE PROD_ID = :id"
 );
 $stmt->execute([
  ":id" => $modelo->id,
  ":nombre" => $modelo->nombre,
  ":archId" => $archivo->id
 ]);
 $con->commit();
}
