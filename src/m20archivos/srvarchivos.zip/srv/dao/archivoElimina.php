<?php

require_once __DIR__ . "/AccesoBd.php";

function archivoElimina(int $id)
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "DELETE FROM ARCHIVO
   WHERE ARCH_ID = :id"
 );
 $stmt->execute([":id" => $id]);
}
