<?php

require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/archivoElimina.php";
require_once __DIR__ . "/productoBusca.php";

function productoElimina(int $id)
{
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 $modelo = productoBusca($id);
 if ($modelo === false) {
  $con->rollBack();
 } else {
  archivoElimina($modelo->archivo->id);
  $stmt = $con->prepare(
   "DELETE FROM PRODUCTO
    WHERE PROD_ID = :id"
  );
  $stmt->execute([":id" => $modelo->id]);
  $con->commit();
 }
}
