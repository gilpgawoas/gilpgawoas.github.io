<?php

use srv\dao\AccesoBd;
use srv\modelo\Archivo;

function archivoAgrega(
 Archivo $modelo
) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "INSERT INTO ARCHIVO
    (ARCH_BYTES)
   VALUES
    (:bytes)"
 );
 $stmt->execute([
  ":bytes" => $modelo->bytes
 ]);
 /* Si usas una secuencia para
  * generar el id, pasa como
  * parámetro de lastInsertId el
  * nombre de dicha secuencia. */
 $modelo->id =
  $con->lastInsertId();
}
