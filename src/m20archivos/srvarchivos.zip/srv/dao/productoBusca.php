<?php

require_once __DIR__ . "/../modelo/Archivo.php";
require_once __DIR__ . "/../modelo/Producto.php";
require_once __DIR__ . "/AccesoBd.php";

function productoBusca(int $prodId)
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    P.PROD_ID AS prodId,
    P.PROD_NOMBRE AS prodNombre,
    A.ARCH_ID AS archId
   FROM PRODUCTO P
    LEFT JOIN ARCHIVO A
    ON P.ARCH_ID = A.ARCH_ID
   WHERE P.PROD_ID = :prodId"
 );
 $stmt->execute([
  ":prodId" => $prodId
 ]);
 $stmt->setFetchMode(PDO::FETCH_OBJ);
 $obj = $stmt->fetch();
 if ($obj === false) {
  return false;
 } else {
  $id = $obj->prodId;
  $nombre = $obj->prodNombre;
  $archId = $obj->archId;
  $archivo = $archId === null ? null : new Archivo(id: $archId);
  $producto = new Producto(
   id: $id,
   nombre: $nombre,
   archivo: $archivo
  );
  return $producto;
 }
}
