<?php

require_once __DIR__ . "/../modelo/Archivo.php";
require_once __DIR__ . "/AccesoBd.php";

function archivoBusca(int $id): false|Archivo
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    ARCH_ID AS id,
    ARCH_BYTES AS bytes
   FROM ARCHIVO
   WHERE ARCH_ID = :id"
 );
 $stmt->execute([":id" => $id]);
 $stmt->setFetchMode(
  PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
  Archivo::class
 );
 return $stmt->fetch();
}
