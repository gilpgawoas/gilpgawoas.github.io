<?php

require_once  __DIR__ . "/Archivo.php";

class Producto
{

 public int $id;
 public string $nombre;
 public ?Archivo $archivo;

 public function __construct(
  string $nombre = "",
  Archivo $archivo = null,
  int $id = 0,
 ) {
  $this->id = $id;
  $this->nombre = $nombre;
  $this->archivo = $archivo;
 }

 public function validaNuevo()
 {
  if ($this->nombre === "")
   throw new Exception("Falta el nombre.");
  if ($this->archivo === null)
   throw new Exception("Falta el archivo.");
  $this->archivo->valida();
 }

 public function valida()
 {
  if ($this->nombre === "")
   throw new Exception("Falta el nombre.");
 }
}
