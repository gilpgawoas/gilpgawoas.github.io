<?php

class Archivo
{

 public int $id;
 public string $bytes;

 public function __construct(string $bytes = "",  int $id = 0)
 {
  $this->id = $id;
  $this->bytes = $bytes;
 }

 public function valida()
 {
  if ($this->bytes === "")
   throw new Exception("Falta el contenido del archivo.");
 }
}
