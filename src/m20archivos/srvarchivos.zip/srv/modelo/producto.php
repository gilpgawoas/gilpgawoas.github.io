<?php

namespace srv\modelo;

require_once "lib/php/"
 . "validaNombreNoVacio.php";
require_once
 "lib/php/validaNoNull.php";
require_once
 "srv/txt/txtFaltaElArchivo.php";

class Producto
{

 public int $id;
 public string $nombre;
 public ?Archivo $archivo;

 public function validaNuevo()
 {
  validaNombreNoVacio(
   $this->nombre
  );
  $this->validaArchivoNoNull();
 }

 public function valida()
 {
  validaNombreNoVacio(
   $this->nombre
  );
 }

 function validaArchivoNoNull()
 {
  validaNoNull(
   $this->archivo,
   txtFaltaElArchivo()
  );
 }
}
