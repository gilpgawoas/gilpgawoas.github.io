<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeBytes.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";
require_once __DIR__ . "/modelo/Archivo.php";
require_once __DIR__ . "/modelo/Producto.php";
require_once __DIR__ . "/dao/productoAgrega.php";

ejecuta(function () {
 $bytes = leeBytes("bytes");
 $archivo = $bytes === "" ? null : new Archivo(bytes: $bytes);

 $nombre = trim(leeTexto("nombre"));
 $modelo = new Producto(nombre: $nombre, archivo: $archivo);

 productoAgrega($modelo);

 // Los bytes se descargan con SrvArchivo; no desde aquí.
 $modelo->archivo->bytes = "";
 return $modelo;
});
