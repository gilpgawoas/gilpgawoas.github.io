<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "srv/dao/productoElimina.php";
require_once
 "lib/php/leeEntero.php";

use \lib\php\Servicio;

class SrvProductoElimina
extends Servicio
{

 protected
 function implementacion()
 {
  $id = leeEntero("id");
  productoElimina($id);
  return [];
 }
}

$servicio =
 new SrvProductoElimina();
$servicio->ejecuta();
