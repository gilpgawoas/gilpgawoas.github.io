<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/../lib/php/leeBytes.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";
require_once __DIR__ . "/modelo/Archivo.php";
require_once __DIR__ . "/modelo/Producto.php";
require_once __DIR__ . "/dao/productoModifica.php";

ejecuta(function () {
 $bytes = leeBytes("bytes");
 $archivo = $bytes === "" ? null : new Archivo(bytes: $bytes);

 $nombre = trim(leeTexto("nombre"));
 $id = leeEntero("id");
 if ($id === null)
  throw new Exception("Falta el id.");
 $modelo = new Producto(nombre: $nombre, archivo: $archivo, id: $id);

 productoModifica($modelo);
 // Los bytes se descargan con SrvArchivo; no desde aquí.
 $modelo->archivo->bytes = "";
 return $modelo;
});
