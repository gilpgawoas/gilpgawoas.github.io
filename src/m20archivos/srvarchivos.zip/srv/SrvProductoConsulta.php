<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "srv/dao/productoConsulta.php";

use \lib\php\Servicio;

class SrvProductoConsulta
extends Servicio
{

 protected
 function implementacion()
 {
  $lista = productoConsulta();
  $render = "";
  foreach ($lista as $it) {
   $prodId =
    htmlentities($it->prodId);
   $prodNombre =
    htmlentities($it->prodNombre);
   $archId =
    $it->archId === null
    ? ""
    : htmlentities($it->archId);
   $render .=
    "<li>
      <p>
<a style='display: flex;
          align-items: center;
          gap: 0.5rem'
  href='modifica.html?id=$prodId'>
 <img style='width: 50%'
   alt='Imagen del producto'
   src=
  'srv/SrvArchivo.php?id=$archId'>
 <strong>{$prodNombre}</strong></a>
      </p>
     </li>";
  }
  return $render;
 }
}

$servicio =
 new SrvProductoConsulta();
$servicio->ejecuta();
