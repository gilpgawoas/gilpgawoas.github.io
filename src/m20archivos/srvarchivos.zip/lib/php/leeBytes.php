<?php

function leeBytes(string $parametro): string
{
 /* Si el archivo se recibió y contiene bytes, los recupera;
  * en caso contrario, devuelve false. */
 $contents = isset($_FILES[$parametro]) && $_FILES[$parametro]["size"] > 0
  ?  file_get_contents($_FILES[$parametro]["tmp_name"])
  : false;
 return $contents === false
  ? ""
  : $contents;
}
