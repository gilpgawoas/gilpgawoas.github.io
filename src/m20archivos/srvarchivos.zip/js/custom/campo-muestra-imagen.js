export class CampoMuestraImagen
 extends HTMLElement {

 connectedCallback() {
  this.innerHTML = /* HTML */
   `<figure>
     <img id="img"
       style="max-width: 100%;"
       alt="Imagen del producto">
    </figure>`
 }

}

customElements.define(
 "campo-muestra-imagen",
 CampoMuestraImagen)