export class CampoSubeImagen
 extends HTMLElement {

 connectedCallback() {
  this.innerHTML = /* HTML */
   `<p>
     <label>
      Imagen
      <input name="bytes"
        type="file"
        accept="image/*">
     </label>
    </p>`
 }

}

customElements.define(
 "campo-sube-imagen",
 CampoSubeImagen)