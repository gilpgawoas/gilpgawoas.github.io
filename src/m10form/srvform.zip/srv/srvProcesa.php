<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";

ejecuta(function () {
 $saludo = leeTexto("saludo");
 $nombre = leeTexto("nombre");
 if ($saludo === "") {
  throw new Exception(
   "Falta el saludo"
  );
 }
 if ($nombre === "") {
  throw new Exception(
   "Falta el nombre"
  );
 }
 $resultado =
  "{$saludo} {$nombre}.";
 return $resultado;
});
