<?php

const ROL_IDS = "rolIds";