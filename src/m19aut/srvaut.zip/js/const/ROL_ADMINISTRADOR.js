export const ROL_ADMINISTRADOR = "Administrador"

// Permite que los eventos de html usen la constante.
window["ROL_ADMINISTRADOR"] = ROL_ADMINISTRADOR