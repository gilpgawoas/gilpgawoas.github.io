export const ROL_CLIENTE = "Cliente"

// Permite que los eventos de html usen la constante.
window["ROL_CLIENTE"] = ROL_CLIENTE