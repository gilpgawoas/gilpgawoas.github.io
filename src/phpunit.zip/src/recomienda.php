<?php

function recomienda(string $genero): string
{
 if ($genero === "pop") {
  return "Dua Lipa.";
 } elseif ($genero === "reg") {
  return "Bad Bunny.";
 } else {
  return "De eso no conozco";
 }
}
