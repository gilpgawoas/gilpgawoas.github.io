<?php

const ROL_ID_CLIENTE = "Cliente";