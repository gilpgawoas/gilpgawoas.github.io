<?php

const ROL = "ROL";
const ROL_ID = "ROL_ID";
const ROL_DESCRIPCION = "ROL_DESCRIPCION";
