<?php

const ROL_ID_ADMINISTRADOR = "Administrador";
