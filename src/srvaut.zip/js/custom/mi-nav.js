export class MiNav extends HTMLElement {

 constructor() {
  super()
  this.cargado = false
 }

 connectedCallback() {

  this.style.display = "block"

  if (this.cargado === false) {
   this.innerHTML = /* html */
    `<nav>
      <ul>
       <li><a href="index.html">Inicio</a></li>
       <li id="ocupado"><progress max="100">Cargando&hellip;</progress></li>
       <li id="aAdmin" hidden>
        <a href="administrador.html">Para administradores</a>
       </li>
       <li id="aCliente" hidden><a href="cliente.html">Para clientes</a></li>
       <li id="san" hidden></li>
       <li id="aPerfil"><a href="perfil.html">Perfil</a></li>
      </ul>
     </nav>`

   this.cargado = true
  }
 }

}

customElements.define("mi-nav", MiNav)