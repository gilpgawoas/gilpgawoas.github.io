export class MiNav extends HTMLElement {

 constructor() {
  super()
  this.cargado = false
 }

 connectedCallback() {

  this.style.display = "block"

  if (this.cargado === false) {
   this.innerHTML = /* html */
    `<nav>
      <ul style="display: flex;
                 flex-wrap: wrap;
                 padding:0;
                 gap: 0.5em;
                 list-style-type: none">
       <li id="ocupado"><progress max="100">Cargando&hellip;</progress></li>
       <li id="aIndex" hidden><a href="index.html">Inicio</a></li>
       <li id="aAdmin" hidden>
        <a href="administrador.html">Para administradores</a>
       </li>
       <li id="aCliente" hidden><a href="cliente.html">Para clientes</a></li>
       <li id="san" hidden></li>
       <li id="aPerfil" hidden><a href="perfil.html">Perfil</a></li>
      </ul>
     </nav>`

   this.cargado = true
  }
 }

}

customElements.define("mi-nav", MiNav)