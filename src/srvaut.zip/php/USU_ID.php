<?php

const USU_ID = "USU_ID";