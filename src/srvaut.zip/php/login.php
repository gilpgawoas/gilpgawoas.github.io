<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/BAD_REQUEST.php";
require_once __DIR__ . "/lib/recibeTextoObligatorio.php";
require_once __DIR__ . "/lib/recibeTexto.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/lib/rolIdsParaUsuId.php";
require_once __DIR__ . "/SAN.php";
require_once __DIR__ . "/USU_ID.php";
require_once __DIR__ . "/ROL_IDS.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/protegeLogin.php";
require_once __DIR__ . "/usuarioBuscaSan.php";

list($san, $rolIds) = protegeLogin([]);

$san = recibeTextoObligatorio("san");
$sen = recibeTexto("sen");

$bd = Bd::pdo();

$usuario = usuarioBuscaSan($bd, $san);

if (
 $usuario === false
 || !password_verify(
  ($sen === false || $sen === null) ? "" : $sen,
  $usuario["USU_SEN"]
 )
)
 throw new ProblemDetailsException([
  "status" => BAD_REQUEST,
  "type" => "/errors/datosincorrectos.html",
  "title" => "Datos incorrectos.",
  "detail" => "El san y/o el sen proporcionados son incorrectos.",
 ]);

$_SESSION[SAN] = $san;
$_SESSION[USU_ID] = $usuario[USU_ID];

devuelveJson([
 SAN => $san,
 ROL_IDS => rolIdsParaUsuId($bd, $usuario[USU_ID])
]);
