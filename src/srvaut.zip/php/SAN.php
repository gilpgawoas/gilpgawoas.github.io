<?php

const SAN = "san";