<?php

const NO_AUTORIZADO = 401;
