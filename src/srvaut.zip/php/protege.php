<?php

require_once __DIR__ . "/lib/NO_AUTORIZADO.php";
require_once __DIR__ . "/lib/ProblemDetailsException.php";
require_once __DIR__ . "/lib/rolIdsParaUsuId.php";
require_once __DIR__ . "/SAN.php";
require_once __DIR__ . "/USU_ID.php";
require_once __DIR__ . "/Bd.php";

function protege(array $rolIdsPermitidos)
{

 session_start();

 $san = isset($_SESSION[SAN]) ? $_SESSION[SAN] : "";
 $usuId = isset($_SESSION[USU_ID]) ? $_SESSION[USU_ID] : -1;
 $rolIds = rolIdsParaUsuId(Bd::pdo(), $usuId);

 if (count($rolIdsPermitidos) === 0) {

  return [$san, $rolIds, $usuId];
 } else {

  if ($san === "")  throw creaNoAutorizado();

  foreach ($rolIdsPermitidos as $rolId) {
   if (array_search($rolId, $rolIds, true) !== false) {
    return [$san, $rolIds, $usuId];
   }
  }

  throw creaNoAutorizado();
 }
}

function creaNoAutorizado()
{
 return new ProblemDetailsException([
  "status" => NO_AUTORIZADO,
  "type" => "/errors/noautorizado.html",
  "title" => "No autorizado.",
  "detail" => "No estás autorizado para usar este recurso.",
 ]);
}
