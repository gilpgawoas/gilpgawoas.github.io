<?php

require_once __DIR__ . "/leeTexto.php";

/**
 * Recupera el valor entero de un parámetro
 * enviado al servidor por medio de GET,
 * POST o cookie.
 */
function leeEntero(string $parametro): int
{
 return trim(leeTexto($parametro));
}
