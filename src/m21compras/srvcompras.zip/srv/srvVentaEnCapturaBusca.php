<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/modelo/DetalleDeVenta.php";
require_once __DIR__ . "/dao/ventaEnCapturaBusca.php";

ejecuta(function () {
 $modelo = ventaEnCapturaBusca();
 if ($modelo === false)
  throw new Exception("Venta no encontrada");
 $detalles = $modelo->detalles;
 $productoIds = [];
 foreach ($detalles as $detalle) {
  $id = $detalle->producto->id;
  $productoIds[$id] = true;
 }
 $renderDetalles = "";
 foreach ($detalles as $detalle) {
  $producto = $detalle->producto;
  $prodId = htmlentities($producto->id);
  $prodNombre = htmlentities($producto->nombre);
  $precio = htmlentities("$" . number_format($detalle->precio, 2));
  $cantidad = htmlentities(number_format($detalle->cantidad, 2));
  $renderDetalles .=
   "<dt>$prodNombre</dt>
    <dd>
     <a href= 'modifica.html?prodId=$prodId'>Modificar o eliminar</a>
    </dd>
    <dd>
     <dl>
      <dt>Cantidad</dt>
      <dd>$cantidad</dd>
      <dt>Precio</dt>
      <dd>$precio</dd>
     </dl>
    </dd>";
 }
 $modelo->detalles = [];
 return [
  "folio" => $modelo->id,
  "detalles" => $renderDetalles
 ];
});
