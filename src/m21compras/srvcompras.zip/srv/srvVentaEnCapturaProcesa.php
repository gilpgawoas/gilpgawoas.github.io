<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/dao/ventaEnCapturaProcesa.php";

ejecuta(function () {
 ventaEnCapturaProcesa();
 return [];
});
