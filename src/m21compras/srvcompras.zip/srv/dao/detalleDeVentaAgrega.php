<?php

require_once __DIR__ . "/../modelo/DetalleDeVenta.php";
require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/productoBusca.php";

function detalleDeVentaAgrega(DetalleDeVenta $modelo)
{
 $con = AccesoBd::getCon();
 $producto = productoBusca($modelo->producto->id);
 if ($producto === false)
  throw new Exception("Producto no encontrado.");
 $venta = ventaEnCapturaBusca();
 if ($venta === false)
  throw new Exception("Venta no encontrada.");
 $modelo->venta = $venta;
 $modelo->precio = $producto->precio;
 $modelo->producto = $producto;
 $modelo->valida();
 $stmt = $con->prepare(
  "INSERT INTO DET_VENTA
     (VENT_ID, PROD_ID, DTV_CANTIDAD, DTV_PRECIO)
    VALUES
     (:ventId, :prodId, :cantidad, :precio)"
 );
 $stmt->execute(
  [
   ":ventId" => $venta->id,
   ":prodId" => $producto->id,
   ":cantidad" => $modelo->cantidad,
   ":precio" => $producto->precio
  ]
 );
}
