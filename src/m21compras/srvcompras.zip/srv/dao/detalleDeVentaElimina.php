<?php

require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";

function detalleDeVentaElimina(int $prodId)
{
 $venta = ventaEnCapturaBusca();
 if ($venta !== false) {
  $con = AccesoBd::getCon();
  $stmt = $con->prepare(
   "DELETE FROM DET_VENTA
    WHERE VENT_ID = :ventId
     AND PROD_ID = :prodId"
  );
  $stmt->execute([
   ":ventId" => $venta->id,
   ":prodId" => $prodId,
  ]);
 }
}
