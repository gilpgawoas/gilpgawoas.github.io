<?php

require_once __DIR__ . "/../modelo/Venta.php";
require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/detalleDeVentaConsulta.php";

function ventaEnCapturaBusca()
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT VENT_ID as id
   FROM VENTA
   WHERE VENT_EN_CAPTURA = 1"
 );
 $stmt->setFetchMode(PDO::FETCH_OBJ);
 $obj = $stmt->fetch();
 if ($obj === false) {
  return false;
 } else {
  $venta = new Venta(id: $obj->id, enCaptura: true);
  $venta->detalles = detalleDeVentaConsulta($venta);
  return $venta;
 }
}
