<?php

require_once __DIR__ . "/../modelo/Venta.php";
require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/ventaAgrega.php";

function ventaEnCapturaProcesa()
{
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 $modelo = ventaEnCapturaBusca();
 if ($modelo === false)
  throw new Exception("Venta no encontrada.");
 $modelo->valida();
 $detalles = $modelo->detalles;
 $stmt = $con->prepare(
  "UPDATE PRODUCTO
   SET PROD_EXISTENCIAS = :existencias
   WHERE PROD_ID = :prodId"
 );
 foreach ($detalles as $dtv) {
  $producto = $dtv->producto;
  $stmt->execute(([
   ":prodId" => $producto->id,
   ":existencias" => $producto->existencias - $dtv->cantidad
  ]));
 }
 $stmt = $con->prepare(
  "UPDATE VENTA
    SET VENT_EN_CAPTURA = 0
    WHERE VENT_ID = :id"
 );
 $stmt->execute([":id" => $modelo->id]);
 ventaAgrega(new Venta(enCaptura: true));
 $con->commit();
}
