<?php

require_once __DIR__ . "/../../lib/php/recibeFetchAll.php";
require_once __DIR__ . "/../modelo/Producto.php";
require_once __DIR__ . "/AccesoBd.php";

/** @return Producto[] */
function productoConsulta(): array
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
    PROD_ID as id,
    PROD_NOMBRE as nombre,
    PROD_PRECIO as precio,
    PROD_EXISTENCIAS as existencias
   FROM PRODUCTO
   ORDER BY PROD_NOMBRE"
 );
 $resultado = $stmt->fetchAll(
  PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
  Producto::class
 );
 return recibeFetchAll($resultado);
}
