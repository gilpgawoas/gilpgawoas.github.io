<?php

require_once __DIR__ . "/AccesoBd.php";

function productoCuenta(): false|int
{
 $con = AccesoBd::getCon();
 $stmt = $con->query("SELECT COUNT(*) FROM PRODUCTO");
 return $stmt->fetchColumn();
}
