<?php

require_once __DIR__ . "/AccesoBd.php";

function ventaCuenta(): false|int
{
 $con = AccesoBd::getCon();
 $stmt = $con->query("SELECT COUNT(*) FROM VENTA");
 return $stmt->fetchColumn();
}
