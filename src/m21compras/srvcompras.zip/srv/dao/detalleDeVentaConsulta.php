<?php

require_once __DIR__ . "/../../lib/php/recibeFetchAll.php";
require_once __DIR__ . "/../modelo/Venta.php";
require_once __DIR__ . "/../modelo/DetalleDeVenta.php";
require_once __DIR__ . "/../modelo/Producto.php";
require_once __DIR__ . "/AccesoBd.php";

function detalleDeVentaConsulta(Venta $venta)
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
    DV.PROD_ID AS prodId,
    P.PROD_NOMBRE AS prodNombre,
    P.PROD_EXISTENCIAS AS prodExistencias,
    P.PROD_PRECIO AS prodPrecio,
    DV.DTV_CANTIDAD AS cantidad,
    DV.DTV_PRECIO AS precio
   FROM DET_VENTA DV, PRODUCTO P
   WHERE
    DV.PROD_ID = P.PROD_ID
    AND DV.VENT_ID = :ventId
   ORDER BY P.PROD_NOMBRE"
 );
 $stmt->execute([":ventId" => $venta->id]);
 $resultado = $stmt->fetchAll(PDO::FETCH_OBJ);
 $objs = recibeFetchAll($resultado);
 /** @var DetalleDeVenta[] */
 $detalles = [];
 foreach ($objs as $obj) {
  $producto = new Producto(
   id: $obj->prodId,
   nombre: $obj->prodNombre,
   existencias: $obj->prodExistencias,
   precio: $obj->prodPrecio
  );
  $detalle = new DetalleDeVenta(
   venta: $venta,
   producto: $producto,
   cantidad: $obj->cantidad,
   precio: $obj->precio
  );
  $detalles[] = $detalle;
 }
 return $detalles;
}
