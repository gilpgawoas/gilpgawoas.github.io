<?php

require_once __DIR__ . "/../modelo/DetalleDeVenta.php";
require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/productoBusca.php";


function detalleDeVentaModifica(DetalleDeVenta $modelo)
{
 $con = AccesoBd::getCon();
 $producto = productoBusca($modelo->producto->id);
 if ($producto === false)
  throw new Exception("Producto no encontrado.");
 $venta = ventaEnCapturaBusca();
 if ($venta === false)
  throw new Exception("Venta no encontrada.");
 $modelo->venta = $venta;
 $modelo->producto = $producto;
 $modelo->precio =  $producto->precio;
 $modelo->valida();
 $stmt = $con->prepare(
  "UPDATE DET_VENTA
   SET
    DTV_CANTIDAD = :cantidad,
    DTV_PRECIO = :precio
   WHERE 
    VENT_ID = :ventId
    AND PROD_ID = :prodId"
 );
 $stmt->execute(
  [
   ":ventId" => $venta->id,
   ":prodId" => $producto->id,
   ":cantidad" => $modelo->cantidad,
   ":precio" => $modelo->precio
  ]
 );
}
