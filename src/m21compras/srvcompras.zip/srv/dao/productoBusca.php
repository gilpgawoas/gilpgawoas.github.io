<?php

require_once __DIR__ . "/../modelo/Producto.php";
require_once __DIR__ . "/AccesoBd.php";

function productoBusca(int $id): false|Producto
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    PROD_ID AS id,
    PROD_NOMBRE AS nombre,
    PROD_PRECIO AS precio,
    PROD_EXISTENCIAS AS existencias
   FROM PRODUCTO
   WHERE PROD_ID = :id"
 );
 $stmt->execute([":id" => $id]);
 $stmt->setFetchMode(
  PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
  Producto::class
 );
 return $stmt->fetch();
}
