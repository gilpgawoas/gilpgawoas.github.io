<?php

require_once __DIR__ . "/../modelo/Venta.php";
require_once __DIR__ . "/AccesoBd.php";

function ventaAgrega(Venta $modelo)
{
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "INSERT INTO VENTA
    (VENT_EN_CAPTURA)
   VALUES
    (:enCaptura)"
 );
 $stmt->execute(([":enCaptura" => $modelo->enCaptura]));
 /* Si usas una secuencia para generar el id,
  * pasa como parámetro de lastInsertId el
  * nombre de dicha secuencia. */
 $modelo->id = $con->lastInsertId();
}
