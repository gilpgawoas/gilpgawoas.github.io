<?php

require_once __DIR__ . "/../modelo/Venta.php";
require_once __DIR__ . "/../modelo/Producto.php";
require_once __DIR__ . "/bdCrea.php";
require_once __DIR__ . "/productoCuenta.php";
require_once __DIR__ . "/productoAgrega.php";
require_once __DIR__ . "/ventaCuenta.php";
require_once __DIR__ . "/ventaAgrega.php";

class AccesoBd
{

 private static ?PDO $con = null;

 public static function getCon(): PDO
 {
  if (self::$con === null) {
   self::$con = self::conecta();
   self::prepara(self::$con);
  }
  return self::$con;
 }

 private static function conecta(): PDO
 {
  return new PDO(
   // cadena de conexión
   "sqlite:srvcompras.db",
   // usuario
   null,
   // contraseña
   null,
   [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
  );
 }
 private static function prepara(PDO $con)
 {
  bdCrea($con);
  if (productoCuenta() === 0) {
   productoAgrega(
    new Producto(nombre: "Sandwich", existencias: 50, precio: 15)
   );
   productoAgrega(
    new Producto(nombre: "Hot dog", existencias: 40, precio: 30)
   );
   productoAgrega(
    new Producto(nombre: "Hamburguesa", existencias: 30, precio: 40)
   );
  }
  if (ventaCuenta() === 0) {
   ventaAgrega(new Venta(enCaptura: true));
  }
 }
}
