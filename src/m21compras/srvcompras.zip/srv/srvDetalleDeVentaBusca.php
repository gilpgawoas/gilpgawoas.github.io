<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/dao/detalleDeVentaBusca.php";

ejecuta(function () {
 $prodId = leeEntero("prodId");
 $modelo = detalleDeVentaBusca($prodId);
 if ($modelo === false)
  throw new Exception("Detalle de venta no encontrado.");
 $producto = $modelo->producto;
 return [
  "prodId" => $producto->id,
  "prodNombre" => $producto->nombre,
  "precio" => "$" . number_format($modelo->precio, 2),
  "cantidad" => $modelo->cantidad,
 ];
});
