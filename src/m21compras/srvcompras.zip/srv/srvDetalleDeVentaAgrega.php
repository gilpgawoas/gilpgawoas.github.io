<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/../lib/php/leeDecimal.php";
require_once __DIR__ . "/modelo/Producto.php";
require_once __DIR__ . "/modelo/DetalleDeVenta.php";
require_once __DIR__ . "/dao/detalleDeVentaAgrega.php";

ejecuta(function () {
 $prodId = leeEntero("id");
 $cantidad = leeDecimal("cantidad");
 $producto = new Producto(id: $prodId);
 $modelo = new DetalleDeVenta(producto: $producto, cantidad: $cantidad);
 detalleDeVentaAgrega($modelo);
 // Rompe el ciclo de referencias para poder generar JSON.
 $modelo->venta->detalles = [];
 return $modelo;
});
