<?php

require_once __DIR__ . "/DetalleDeVenta.php";

class Venta
{

 public int $id;
 public bool $enCaptura;
 /** @var DetalleDeVenta[] */
 public array $detalles;

 public function __construct(
  bool $enCaptura = false,
  array $detalles = [],
  int $id = 0
 ) {
  $this->id = $id;
  $this->enCaptura = $enCaptura;
  $this->detalles = $detalles;
 }

 public function valida()
 {
  foreach ($this->detalles as $detalle) {
   if (!($detalle instanceof DetalleDeVenta))
    throw new Exception("Tipo incorrecto para un detalle de venta.");
   $detalle->valida();
  }
 }
}
