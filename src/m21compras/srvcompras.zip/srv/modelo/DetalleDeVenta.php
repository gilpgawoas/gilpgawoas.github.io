<?php

require_once __DIR__ . "/Venta.php";
require_once __DIR__ . "/Producto.php";

class DetalleDeVenta
{

 public ?Venta $venta;
 public ?Producto $producto;
 public float $cantidad;
 public float $precio;

 public function __construct(
  float $cantidad = NAN,
  float $precio = NAN,
  ?Producto $producto = null,
  ?Venta $venta = null
 ) {
  $this->cantidad = $cantidad;
  $this->precio = $precio;
  $this->producto = $producto;
  $this->venta = $venta;
 }

 public function valida()
 {
  if ($this->producto === null)
   throw new Exception("Detalle de venta sin producto.");
  if (is_nan($this->cantidad))
   throw new Exception("La cantidad no puede ser NAN.");
  if (is_nan($this->precio))
   throw new Exception("El precio no puede ser NAN.");
 }
}
