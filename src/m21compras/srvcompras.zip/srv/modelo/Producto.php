<?php

class Producto
{

 public int $id;
 public string $nombre;
 public float $existencias;
 public float $precio;

 public function __construct(
  string $nombre = "",
  float $existencias = NAN,
  float $precio = NAN,
  int $id = 0
 ) {
  $this->id = $id;
  $this->nombre = $nombre;
  $this->existencias = $existencias;
  $this->precio = $precio;
 }

 public function valida()
 {
  if ($this->nombre === "")
   throw new Exception("Falta el nombre.");
  if (is_nan($this->existencias))
   throw new Exception("Las existencias no pueden ser NAN.");
  if (is_nan($this->precio))
   throw new Exception("El precio no puede ser NAN.");
 }
}
