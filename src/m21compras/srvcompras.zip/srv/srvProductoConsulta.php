<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/dao/productoConsulta.php";

ejecuta(function () {
 $lista = productoConsulta();
 $render = "";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo->id);
  $nombre = htmlentities($modelo->nombre);
  $precio = htmlentities("$" . number_format($modelo->precio, 2));
  $existencias = htmlentities(number_format($modelo->existencias, 2));
  $render .=
   "<dt>$nombre</dt>
    <dd>
     <a href='agrega.html?id=$id'>Agregar al carrito</a>
    </dd>
    <dd>
     <dl>
      <dt>Precio</dt>
      <dd>$precio</dd>
      <dt>Existencias</dt>
      <dd>$existencias</dd>
     </dl>
    </dd>";
 }
 return $render;
});
