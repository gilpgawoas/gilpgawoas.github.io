<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/../lib/php/leeDecimal.php";
require_once __DIR__ . "/modelo/Producto.php";
require_once __DIR__ . "/modelo/DetalleDeVenta.php";
require_once __DIR__ . "/dao/detalleDeVentaModifica.php";

ejecuta(function () {
 $prodId = leeEntero("prodId");
 $producto = new Producto(id: $prodId);
 $cantidad = leeDecimal("cantidad");
 $modelo = new DetalleDeVenta(producto: $producto, cantidad: $cantidad);
 detalleDeVentaModifica($modelo);
 // Rompe el ciclo de referencias para poder generar JSON.
 $modelo->venta->detalles = [];
 return $modelo;
});
