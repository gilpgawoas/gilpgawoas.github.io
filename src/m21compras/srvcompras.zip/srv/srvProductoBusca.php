<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/dao/productoBusca.php";

ejecuta(function () {
 $id = leeEntero("id");
 $modelo = productoBusca($id);
 if ($modelo === false) {
  throw new Exception("Producto no encontrado.");
 } else {
  return [
   "id" => $modelo->id,
   "producto" => $modelo->nombre,
   "precio" => "$" . number_format($modelo->precio, 2),
  ];
 }
});
