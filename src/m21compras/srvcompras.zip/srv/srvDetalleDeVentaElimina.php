<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/dao/detalleDeVentaElimina.php";

ejecuta(function () {
 $prodId = leeEntero("prodId");
 detalleDeVentaElimina($prodId);
 return [];
});
