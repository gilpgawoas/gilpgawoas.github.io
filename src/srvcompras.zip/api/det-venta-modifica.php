<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeFlotanteObligatorio.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";

$prodId = recibeEnteroObligatorio("prodId");
$cantidad = recibeFlotanteObligatorio("cantidad");

$bd = Bd::conexion();

$producto = productoBusca($bd, $prodId);
$producto = validaEntidadObligatoria("Producto",  $producto);

$venta = ventaEnCapturaBusca($bd);
$venta = validaEntidadObligatoria("Venta en captura",  $venta);

$stmt = $bd->prepare(
 "UPDATE DET_VENTA
   SET
    DTV_CANTIDAD = :DTV_CANTIDAD,
    DTV_PRECIO = :DTV_PRECIO
   WHERE
   DTV_VNT_ID = :DTV_VNT_ID
    AND DTV_PRD_ID = :DTV_PRD_ID"
);
$stmt->execute([
 ":DTV_CANTIDAD" => $cantidad,
 ":DTV_PRECIO" => $producto["PRD_PRECIO"],
 ":DTV_VNT_ID" => $venta["VNT_ID"],
 ":DTV_PRD_ID" => $prodId
]);

devuelveJson([
 "prodId" => ["value" => $prodId],
 "prodNombre" => ["value" => $producto["PRD_NOMBRE"]],
 "precio" => ["value" => "$" . number_format($producto["PRD_PRECIO"], 2)],
 "cantidad" => ["valueAsNumber" => $cantidad],
]);
