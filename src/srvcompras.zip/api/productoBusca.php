<?php

function productoBusca(\PDO $bd, int $prodId)
{
 $stmt = $bd->prepare("SELECT * FROM PRODUCTO WHERE PRD_ID = :PRD_ID");
 $stmt->execute([":PRD_ID" => $prodId]);
 $modelo = $stmt->fetch(PDO::FETCH_ASSOC);
 return $modelo;
}
