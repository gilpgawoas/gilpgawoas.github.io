<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/detVentaConsulta.php";
require_once __DIR__ . "/Bd.php";

$bd = Bd::conexion();

$venta = ventaEnCapturaBusca($bd);
$venta = validaEntidadObligatoria("Venta en captura",  $venta);

$detalles = detVentaConsulta($bd, $venta["VNT_ID"]);

$renderDetalles = "";
foreach ($detalles as $detVenta) {
 $prodId = $detVenta["DTV_PRD_ID"];
 $query = htmlentities(http_build_query(["prodId" => $prodId]));
 $urlModifica = "modifica.html?$query";
 $prodNombre = htmlentities($detVenta["PRD_NOMBRE"]);
 $precio = htmlentities("$" . number_format($detVenta["PRD_PRECIO"], 2));
 $cantidad = htmlentities(number_format($detVenta["DTV_CANTIDAD"], 2));
 $renderDetalles .=
  "<dt>$prodNombre</dt>
    <dd>
     <a href= '$urlModifica'>Modificar o eliminar</a>
    </dd>
    <dd>
     <dl>
      <dt>Cantidad</dt>
      <dd>$cantidad</dd>
      <dt>Precio</dt>
      <dd>$precio</dd>
     </dl>
    </dd>";
}

devuelveJson([
 "folio" => ["value" => $venta["VNT_ID"]],
 "detalles" => ["innerHTML" => $renderDetalles]
]);
