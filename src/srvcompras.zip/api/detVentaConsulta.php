<?php

function detVentaConsulta(\PDO $bd, int $ventaId)
{
 $stmt = $bd->prepare(
  "SELECT
    DV.DTV_PRD_ID,
    P.PRD_NOMBRE,
    P.PRD_EXISTENCIAS,
    P.PRD_PRECIO,
    DV.DTV_CANTIDAD,
    DV.DTV_PRECIO
   FROM DET_VENTA DV, PRODUCTO P
   WHERE
    DV.DTV_PRD_ID = P.PRD_ID
    AND DV.DTV_VNT_ID = :DTV_VNT_ID
   ORDER BY P.PRD_NOMBRE"
 );
 $stmt->execute([":DTV_VNT_ID" => $ventaId]);
 $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);
 return $lista;
}
