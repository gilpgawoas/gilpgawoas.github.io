<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

$bd = Bd::conexion();
$stmt = $bd->query("SELECT * FROM PRODUCTO ORDER BY PRD_NOMBRE");
$lista = $stmt->fetchAll(PDO::FETCH_ASSOC);

$render = "";
foreach ($lista as $modelo) {
 $id = $modelo["PRD_ID"];
 $query = htmlentities(http_build_query(["id" => $id]));
 $urlAgrega = "agrega.html?$query";
 $nombre = htmlentities($modelo["PRD_NOMBRE"]);
 $precio = htmlentities("$" . number_format($modelo["PRD_PRECIO"], 2));
 $existencias = htmlentities(number_format($modelo["PRD_EXISTENCIAS"], 2));
 $render .=
  "<dt>$nombre</dt>
    <dd>
     <a href='$urlAgrega'>Agregar al carrito</a>
    </dd>
    <dd>
     <dl>
      <dt>Existencias</dt>
      <dd>$existencias</dd>
      <dt>Precio</dt>
      <dd>$precio</dd>
     </dl>
    </dd>";
}
devuelveJson(["lista" => ["innerHTML" => $render]]);
