<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/devuelveNoContent.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";

$prodId = recibeEnteroObligatorio("prodId");

$bd = Bd::conexion();

$venta = ventaEnCapturaBusca($bd);
if ($venta !== false) {
 $stmt = $bd->prepare(
  "DELETE FROM
    DET_VENTA
   WHERE DTV_VNT_ID = :DTV_VNT_ID AND DTV_PRD_ID = :DTV_PRD_ID"
 );
 $stmt->execute([":DTV_VNT_ID" => $venta["VNT_ID"], ":DTV_PRD_ID" => $prodId]);
}
devuelveNoContent();
