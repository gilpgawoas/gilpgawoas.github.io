<?php

function ventaEnCapturaAgrega(\PDO $bd)
{
 $bd->exec("INSERT INTO VENTA (VNT_EN_CAPTURA) VALUES (1)");
}
