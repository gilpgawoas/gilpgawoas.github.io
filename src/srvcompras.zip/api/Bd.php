<?php

require_once __DIR__ . "/ventaEnCapturaAgrega.php";

class Bd
{

 private static ?PDO $pdo = null;

 public static function conexion(): PDO
 {
  if (self::$pdo === null) {
   self::$pdo = new PDO(
    // cadena de conexión
    "sqlite:" . __DIR__ . "/srvcompras.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: pdos no persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS VENTA (
      VNT_ID INTEGER,
      VNT_EN_CAPTURA INTEGER NOT NULL,
      CONSTRAINT PK_VNT PRIMARY KEY(VNT_ID)
     )'
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS PRODUCTO (
      PRD_ID INTEGER,
      PRD_NOMBRE TEXT NOT NULL,
      PRD_EXISTENCIAS REAL NOT NULL,
      PRD_PRECIO REAL NOT NULL,
      CONSTRAINT PK_PRD PRIMARY KEY(PRD_ID),
      CONSTRAINT UQ_PRD_NOM UNIQUE(PRD_NOMBRE),
      CONSTRAINT CHK_PRD_NOM CHECK(LENGTH(PRD_NOMBRE) > 0)
     )'
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS DET_VENTA (
      DTV_VNT_ID INTEGER NOT NULL,
      DTV_PRD_ID INTEGER NOT NULL,
      DTV_CANTIDAD REAL NOT NULL,
      DTV_PRECIO REAL NOT NULL,
      CONSTRAINT PK_DTV PRIMARY KEY (DTV_VNT_ID, DTV_PRD_ID),
      CONSTRAINT FK_DTV_VNT FOREIGN KEY (DTV_VNT_ID) REFERENCES VENTA(VNT_ID),
      CONSTRAINT FK_DTV_PRD FOREIGN KEY (DTV_PRD_ID) REFERENCES PRODUCTO(PRD_ID)
      )'
   );

   $cantidadDeProductos =
    self::$pdo->query("SELECT COUNT(PRD_ID) FROM PRODUCTO")->fetchColumn(0);

   if ($cantidadDeProductos === 0) {
    self::$pdo->exec(
     "INSERT INTO PRODUCTO
       (PRD_NOMBRE, PRD_EXISTENCIAS, PRD_PRECIO)
      VALUES
       ('Sandwich', 50, 15),
       ('Hot dog', 40, 30),
       ('Hamburguesa', 30, 40)"
    );
   }

   $cantidadDeVentas =
    self::$pdo->query("SELECT COUNT(VNT_ID) FROM VENTA")->fetchColumn(0);

   if ($cantidadDeVentas === 0) {
    ventaEnCapturaAgrega(self::$pdo);
   }
  }

  return self::$pdo;
 }
}
