<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";

$prodId = recibeEnteroObligatorio("prodId");

$bd = Bd::conexion();

$venta = ventaEnCapturaBusca($bd);
$venta = validaEntidadObligatoria("Venta en captura",  $venta);

$producto = productoBusca($bd, $prodId);
$producto = validaEntidadObligatoria("Producto",  $producto);

$stmt = $bd->prepare(
 "SELECT *
   FROM DET_VENTA
   WHERE DTV_VNT_ID = :DTV_VNT_ID AND DTV_PRD_ID = :DTV_PRD_ID"
);
$stmt->execute([":DTV_VNT_ID" => $venta["VNT_ID"], ":DTV_PRD_ID" => $prodId]);
$detVenta = $stmt->fetch(PDO::FETCH_ASSOC);
$detVenta = validaEntidadObligatoria("Detalle de venta",  $detVenta);

devuelveJson([
 "prodId" => ["value" => $prodId],
 "prodNombre" => ["value" => $producto["PRD_NOMBRE"]],
 "precio" => ["value" => "$" . number_format($detVenta["DTV_PRECIO"], 2)],
 "cantidad" => ["valueAsNumber" => $detVenta["DTV_CANTIDAD"]],
]);
