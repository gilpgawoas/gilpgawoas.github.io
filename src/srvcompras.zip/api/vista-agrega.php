<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";

$id = recibeEnteroObligatorio("id");

$producto = productoBusca(Bd::conexion(), $id);
$producto = validaEntidadObligatoria("Producto",  $producto);

devuelveJson([
 "id" => ["value" => $id],
 "producto" => ["value" => $producto["PRD_NOMBRE"]],
 "precio" => ["value" => "$" . number_format($producto["PRD_PRECIO"], 2)],
]);
