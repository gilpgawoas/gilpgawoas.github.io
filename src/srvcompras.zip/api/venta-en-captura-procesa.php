<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/devuelveCreated.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/detVentaConsulta.php";
require_once __DIR__ . "/ventaEnCapturaAgrega.php";

$bd = Bd::conexion();
$bd->beginTransaction();

$venta = ventaEnCapturaBusca($bd);
$venta = validaEntidadObligatoria("Venta en captura",  $venta);

$detalles = detVentaConsulta($bd, $venta["VNT_ID"]);

// Actualiza las existencias de los productos vendidos.
$update = $bd->prepare(
 "UPDATE PRODUCTO
   SET PRD_EXISTENCIAS = :PRD_EXISTENCIAS
   WHERE PRD_ID = :PRD_ID"
);
foreach ($detalles as $detVenta) {
 $update->execute([
  ":PRD_ID" => $detVenta["DTV_PRD_ID"],
  ":PRD_EXISTENCIAS" =>
  $detVenta["PRD_EXISTENCIAS"] - $detVenta["DTV_CANTIDAD"]
 ]);
}

$update = $bd->prepare(
 "UPDATE VENTA
   SET VNT_EN_CAPTURA = 0
   WHERE VNT_ID = :VNT_ID"
);
$update->execute([":VNT_ID" => $venta["VNT_ID"]]);

ventaEnCapturaAgrega($bd);
$folio = $bd->lastInsertId();

$bd->commit();

devuelveCreated("/srv/venta-en-captura.php", [
 "folio" => ["value" => $folio],
 "detalles" => ["innerHTML" => ""]
]);
