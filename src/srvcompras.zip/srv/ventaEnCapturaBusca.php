<?php

require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/Bd.php";

function ventaEnCapturaBusca()
{

 $conexion = Bd::getConexion();

 return fetch($conexion->query(
  "SELECT
    VENT_ID as id,
    VENT_EN_CAPTURA as enCaptura
   FROM VENTA
   WHERE VENT_EN_CAPTURA = 1"
 ));
}
