<?php

require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/validaVenta.php";
require_once __DIR__ . "/detVentaConsulta.php";

try {

 $conexion = Bd::getConexion();
 $conexion->beginTransaction();

 $venta = ventaEnCapturaBusca();
 validaVenta($venta);

 $detalles = detVentaConsulta($venta->id);

 // Actualiza las existencias de los productos vendidos.
 $update = $conexion->prepare(
  "UPDATE PRODUCTO
   SET PROD_EXISTENCIAS = :existencias
   WHERE PROD_ID = :prodId"
 );
 foreach ($detalles as $detVenta) {
  $update->execute([
   ":prodId" => $detVenta->prodId,
   ":existencias" => $detVenta->prodExistencias - $detVenta->cantidad
  ]);
 }

 $conexion->prepare(
  "UPDATE VENTA
    SET VENT_EN_CAPTURA = 0
    WHERE VENT_ID = :id"
 )
  ->execute([":id" => $venta->id]);

 $conexion->exec(
  "INSERT INTO VENTA
    (VENT_EN_CAPTURA)
   VALUES
    (1)"
 );

 /* Recupera el id generado. Si usas una secuencia, pasa como
  * parámetro de lastInsertId el nombre de dicha secuencia y
  * poner esta instrucción antes del INSERT, al cual se le
  * pasarle el id generado. */
 $folio = $conexion->lastInsertId();

 $conexion->commit();

 devuelveCreated("/srv/venta-en-captura.php", [
  "folio" => ["value" => $folio],
  "detalles" => ["innerHTML" => ""]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
