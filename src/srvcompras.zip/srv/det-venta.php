<?php

require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/validaProducto.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/validaVenta.php";

try {

 $prodId = recuperaIdEntero("prodId");

 $venta = ventaEnCapturaBusca();
 validaVenta($venta);

 $producto = productoBusca($prodId);
 validaProducto($producto, $prodId);

 $conexion = Bd::getConexion();

 $detVenta = fetch(
  $conexion->prepare(
   "SELECT
    DTV_CANTIDAD AS cantidad,
    DTV_PRECIO AS precio
   FROM DET_VENTA
   WHERE
    VENT_ID = :ventId
    AND PROD_ID = :prodId"
  ),
  [
   ":ventId" => $venta->id,
   ":prodId" => $prodId
  ]
 );

 if ($detVenta === false) {
  $htmlId = htmlentities($prodId);
  throw new ProblemDetails(
   status: NOT_FOUND,
   type: "/error/detalledeventanoencontrado.html",
   title: "Detalle de venta no encontrado.",
   detail: "No se encontró ningún detalle de venta con el id de producto "
    . $htmlId . ".",
  );
 }

 devuelveJson([
  "prodId" => ["value" => $prodId],
  "prodNombre" => ["value" => $producto->nombre],
  "precio" => ["value" => "$" . number_format($detVenta->precio, 2)],
  "cantidad" => ["valueAsNumber" => $detVenta->cantidad],
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
