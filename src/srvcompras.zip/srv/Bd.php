<?php

class Bd
{

 private static ?PDO $conexion = null;

 public static function getConexion(): PDO
 {
  if (self::$conexion === null) {
   self::$conexion = new PDO(
    // cadena de conexión
    "sqlite:srvcompras.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: conexiones persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS VENTA (
      VENT_ID INTEGER,
      VENT_EN_CAPTURA INTEGER NOT NULL,
      CONSTRAINT VENT_PK
       PRIMARY KEY(VENT_ID)
     )'
   );
   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS PRODUCTO (
      PROD_ID INTEGER,
      PROD_NOMBRE TEXT NOT NULL,
      PROD_EXISTENCIAS REAL NOT NULL,
      PROD_PRECIO REAL NOT NULL,
      CONSTRAINT PROD_PK
       PRIMARY KEY(PROD_ID),
      CONSTRAINT PROD_NOM_UNQ
       UNIQUE(PROD_NOMBRE),
      CONSTRAINT PROD_NOM_NV
       CHECK(LENGTH(PROD_NOMBRE) > 0)
     )'
   );
   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS DET_VENTA (
      VENT_ID INTEGER NOT NULL,
      PROD_ID INTEGER NOT NULL,
      DTV_CANTIDAD REAL NOT NULL,
      DTV_PRECIO REAL NOT NULL,
      CONSTRAINT DTV_PK
       PRIMARY KEY (VENT_ID, PROD_ID),
      CONSTRAINT DTV_VENT_FK
       FOREIGN KEY (VENT_ID) REFERENCES VENTA(VENT_ID),
      CONSTRAINT DTV_PROD_FK
       FOREIGN KEY (PROD_ID) REFERENCES PRODUCTO(PROD_ID)
      )'
   );

   $cantidadDeProductos =
    self::$conexion->query("SELECT COUNT(PROD_ID) FROM PRODUCTO")
    ->fetchColumn();

   if ($cantidadDeProductos === 0) {
    self::$conexion->exec(
     "INSERT INTO PRODUCTO
       (PROD_NOMBRE, PROD_EXISTENCIAS, PROD_PRECIO)
      VALUES
       ('Sandwich', 50, 15),
       ('Hot dog', 40, 30),
       ('Hamburguesa', 30, 40)"
    );
   }

   $cantidadDeVentas =
    self::$conexion->query("SELECT COUNT(VENT_ID) FROM VENTA")
    ->fetchColumn();

   if ($cantidadDeVentas === 0) {
    self::$conexion->exec(
     "INSERT INTO VENTA
       (VENT_EN_CAPTURA)
      VALUES
       (1)"
    );
   }
  }

  return self::$conexion;
 }
}
