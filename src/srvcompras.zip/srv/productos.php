<?php

require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/select.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/TABLA_PRODUCTO.php";

ejecutaServicio(function () {

 $pdo = Bd::pdo();

 $lista = select(pdo: $pdo, from: PRODUCTO, orderBy: PROD_NOMBRE);

 $render = "";
 foreach ($lista as $modelo) {
  $encodeId = urlencode($modelo[PROD_ID]);
  $id = htmlentities($encodeId);
  $nombre = htmlentities($modelo[PROD_NOMBRE]);
  $precio = htmlentities("$" . number_format($modelo[PROD_PRECIO], 2));
  $existencias = htmlentities(number_format($modelo[PROD_EXISTENCIAS], 2));
  $render .=
   "<dt>$nombre</dt>
    <dd>
     <a href='agrega.html?id=$id'>Agregar al carrito</a>
    </dd>
    <dd>
     <dl>
      <dt>Precio</dt>
      <dd>$precio</dd>
      <dt>Existencias</dt>
      <dd>$existencias</dd>
     </dl>
    </dd>";
 }
 devuelveJson(["lista" => ["innerHTML" => $render]]);
});
