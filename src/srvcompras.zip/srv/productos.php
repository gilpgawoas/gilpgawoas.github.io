<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $conexionexion = Bd::getConexion();
 $lista = fetchAll($conexionexion->query(
  "SELECT
    PROD_ID as id,
    PROD_NOMBRE as nombre,
    PROD_PRECIO as precio,
    PROD_EXISTENCIAS as existencias
   FROM PRODUCTO
   ORDER BY PROD_NOMBRE"
 ));

 $render = "";
 foreach ($lista as $modelo) {
  $encodeId = urlencode($modelo->id);
  $id = htmlentities($encodeId);
  $nombre = htmlentities($modelo->nombre);
  $precio = htmlentities("$" . number_format($modelo->precio, 2));
  $existencias = htmlentities(number_format($modelo->existencias, 2));
  $render .=
   "<dt>$nombre</dt>
    <dd>
     <a href='agrega.html?id=$id'>Agregar al carrito</a>
    </dd>
    <dd>
     <dl>
      <dt>Precio</dt>
      <dd>$precio</dd>
      <dt>Existencias</dt>
      <dd>$existencias</dd>
     </dl>
    </dd>";
 }
 devuelveJson(["lista" => ["innerHTML" => $render]]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
