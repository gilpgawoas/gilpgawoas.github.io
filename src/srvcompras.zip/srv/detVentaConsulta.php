<?php

require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/../lib/php/fetchAll.php";

function detVentaConsulta(int $ventaId)
{

 $conexion = Bd::getConexion();

 return fetchAll(
  $conexion->query(
   "SELECT
    DV.PROD_ID AS prodId,
    P.PROD_NOMBRE AS prodNombre,
    P.PROD_EXISTENCIAS AS prodExistencias,
    P.PROD_PRECIO AS prodPrecio,
    DV.DTV_CANTIDAD AS cantidad,
    DV.DTV_PRECIO AS precio
   FROM DET_VENTA DV, PRODUCTO P
   WHERE
    DV.PROD_ID = P.PROD_ID
    AND DV.VENT_ID = :ventId
   ORDER BY P.PROD_NOMBRE"
  ),
  [":ventId" => $ventaId]
 );
}
