<?php

const VENTA = "VENTA";
const VENT_ID = "VENT_ID";
const VENT_EN_CAPTURA = "VENT_EN_CAPTURA";
