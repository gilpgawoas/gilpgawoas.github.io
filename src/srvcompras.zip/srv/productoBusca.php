<?php

require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/Bd.php";

function productoBusca(int $id)
{

 $conexion = Bd::getConexion();

 return fetch(
  $conexion->prepare(
   "SELECT
    PROD_NOMBRE AS nombre,
    PROD_PRECIO AS precio,
    PROD_EXISTENCIAS AS existencias
   FROM PRODUCTO
   WHERE PROD_ID = :id"
  ),
  [":id" => $id]
 );
}
