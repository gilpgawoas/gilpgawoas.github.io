<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/validaVenta.php";
require_once __DIR__ . "/detVentaConsulta.php";

try {

 $venta = ventaEnCapturaBusca();
 validaVenta($venta);

 $detalles = detVentaConsulta($venta->id);

 $renderDetalles = "";
 foreach ($detalles as $detVenta) {
  $encodeProdId = urlencode($detVenta->prodId);
  $prodId = htmlentities($encodeProdId);
  $prodNombre = htmlentities($detVenta->prodNombre);
  $precio = htmlentities("$" . number_format($detVenta->prodPrecio, 2));
  $cantidad = htmlentities(number_format($detVenta->cantidad, 2));
  $renderDetalles .=
   "<dt>$prodNombre</dt>
    <dd>
     <a href= 'modifica.html?prodId=$prodId'>Modificar o eliminar</a>
    </dd>
    <dd>
     <dl>
      <dt>Cantidad</dt>
      <dd>$cantidad</dd>
      <dt>Precio</dt>
      <dd>$precio</dd>
     </dl>
    </dd>";
 }

 devuelveJson([
  "folio" => ["value" => $venta->id],
  "detalles" => ["innerHTML" => $renderDetalles]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
