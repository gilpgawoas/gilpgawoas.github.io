<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/recuperaDecimal.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaCantidad.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/validaProducto.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/validaVenta.php";

try {

 $prodId = recuperaIdEntero("prodId");
 $cantidad = recuperaDecimal("cantidad");

 $cantidad = validaCantidad($cantidad);

 $producto = productoBusca($prodId);
 validaProducto($producto, $prodId);

 $venta = ventaEnCapturaBusca();
 validaVenta($venta);

 $conexion = Bd::getConexion();
 $conexion->prepare(
  "UPDATE DET_VENTA
    SET
     DTV_CANTIDAD = :cantidad,
     DTV_PRECIO = :precio
    WHERE 
     VENT_ID = :ventId
     AND PROD_ID = :prodId"
 )
  ->execute(
   [
    ":ventId" => $venta->id,
    ":prodId" => $prodId,
    ":cantidad" => $cantidad,
    ":precio" => $producto->precio
   ]
  );

 devuelveJson([
  "prodId" => ["value" => $prodId],
  "prodNombre" => ["value" => $producto->nombre],
  "precio" => ["value" => "$" . number_format($producto->precio, 2)],
  "cantidad" => ["valueAsNumber" => $cantidad],
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
