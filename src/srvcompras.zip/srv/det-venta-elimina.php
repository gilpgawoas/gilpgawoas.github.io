<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/devuelveNoContent.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";

try {

 $prodId = recuperaIdEntero("prodId");

 $venta = ventaEnCapturaBusca();

 if ($venta !== false) {

  $conexion = Bd::getConexion();

  $conexion->prepare(
   "DELETE FROM DET_VENTA
    WHERE VENT_ID = :ventId
     AND PROD_ID = :prodId"
  )
   ->execute([
    ":ventId" => $venta->id,
    ":prodId" => $prodId,
   ]);
 }

 devuelveNoContent();
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
