<?php

require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/validaProducto.php";

ejecutaServicio(function () {

 $id = recuperaIdEntero("id");

 $producto = productoBusca(Bd::pdo(), $id);
 validaProducto($producto, $id);

 devuelveJson([
  "id" => ["value" => $id],
  "producto" => ["value" => $producto[PROD_NOMBRE]],
  "precio" => ["value" => "$" . number_format($producto[PROD_PRECIO], 2)],
 ]);
});
