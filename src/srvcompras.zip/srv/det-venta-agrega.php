<?php

require_once __DIR__ . "/../lib/php/BAD_REQUEST.php";
require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/recuperaDecimal.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaCantidad.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/validaProducto.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/validaVenta.php";

try {

 $prodId = recuperaIdEntero("id");

 $cantidad = recuperaDecimal("cantidad");

 $cantidad = validaCantidad($cantidad);

 $producto = productoBusca($prodId);
 validaProducto($producto, $prodId);

 $venta = ventaEnCapturaBusca();
 validaVenta($venta);

 $conexion = Bd::getConexion();
 $conexion->prepare(
  "INSERT INTO DET_VENTA
     (VENT_ID, PROD_ID, DTV_CANTIDAD, DTV_PRECIO)
    VALUES
     (:ventId, :prodId, :cantidad, :precio)"
 )
  ->execute(
   [
    ":ventId" => $venta->id,
    ":prodId" => $prodId,
    ":cantidad" => $cantidad,
    ":precio" => $producto->precio,
   ]
  );

 $encodeProdId = urlencode($prodId);

 devuelveCreated("/srv/det-venta.php?id=$encodeProdId", [
  "prodId" => ["value" => $prodId],
  "prodNombre" => ["value" => $producto->nombre],
  "precio" => ["value" => "$" . number_format($producto->precio, 2)],
  "cantidad" => ["valueAsNumber" => $cantidad],
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
