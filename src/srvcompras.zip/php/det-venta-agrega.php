<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/recibeFlotanteObligatorio.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/lib/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";


$prodId = recibeEnteroObligatorio("id");
$cantidad = recibeFlotanteObligatorio("cantidad");

$bd = Bd::pdo();

$producto = productoBusca($bd, $prodId);
$producto = validaEntidadObligatoria("Producto",  $producto);

$venta = ventaEnCapturaBusca($bd);
$venta = validaEntidadObligatoria("Venta en captura",  $venta);

$stmt = $bd->prepare(
 "INSERT INTO DET_VENTA (
    VENT_ID, PROD_ID, DTV_CANTIDAD, DTV_PRECIO
   ) values (
    :VENT_ID, :PROD_ID, :DTV_CANTIDAD, :DTV_PRECIO
   )"
);
$stmt->execute([
 ":VENT_ID" => $venta["VENT_ID"],
 ":PROD_ID" => $prodId,
 ":DTV_CANTIDAD" => $cantidad,
 ":DTV_PRECIO" => $producto["PROD_PRECIO"],
]);

$encodeProdId = urlencode($prodId);
devuelveCreated("/php/vista-modifica.php?id=$encodeProdId", [
 "prodId" => ["value" => $prodId],
 "prodNombre" => ["value" => $producto["PROD_NOMBRE"]],
 "precio" => ["value" => "$" . number_format($producto["PROD_PRECIO"], 2)],
 "cantidad" => ["valueAsNumber" => $cantidad],
]);
