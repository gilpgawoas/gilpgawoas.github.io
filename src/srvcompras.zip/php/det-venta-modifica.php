<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/recibeFlotanteObligatorio.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";

$prodId = recibeEnteroObligatorio("prodId");
$cantidad = recibeFlotanteObligatorio("cantidad");

$bd = Bd::pdo();

$producto = productoBusca($bd, $prodId);
$producto = validaEntidadObligatoria("Producto",  $producto);

$venta = ventaEnCapturaBusca($bd);
$venta = validaEntidadObligatoria("Venta en captura",  $venta);

$stmt = $bd->prepare(
 "UPDATE DET_VENTA
   SET
    DTV_CANTIDAD = :DTV_CANTIDAD,
    DTV_PRECIO = :DTV_PRECIO
   WHERE
    VENT_ID = :VENT_ID
    AND PROD_ID = :PROD_ID"
);
$stmt->execute([
 ":DTV_CANTIDAD" => $cantidad,
 ":DTV_PRECIO" => $producto["PROD_PRECIO"],
 ":VENT_ID" => $venta["VENT_ID"],
 ":PROD_ID" => $prodId
]);

devuelveJson([
 "prodId" => ["value" => $prodId],
 "prodNombre" => ["value" => $producto["PROD_NOMBRE"]],
 "precio" => ["value" => "$" . number_format($producto["PROD_PRECIO"], 2)],
 "cantidad" => ["valueAsNumber" => $cantidad],
]);
