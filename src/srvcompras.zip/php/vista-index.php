<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

$bd = Bd::pdo();
$stmt = $bd->query("SELECT * FROM PRODUCTO ORDER BY PROD_NOMBRE");
$lista = $stmt->fetchAll(PDO::FETCH_ASSOC);

$render = "";
foreach ($lista as $modelo) {
 $encodeId = urlencode($modelo["PROD_ID"]);
 $id = htmlentities($encodeId);
 $nombre = htmlentities($modelo["PROD_NOMBRE"]);
 $precio = htmlentities("$" . number_format($modelo["PROD_PRECIO"], 2));
 $existencias = htmlentities(number_format($modelo["PROD_EXISTENCIAS"], 2));
 $render .=
  "<dt>$nombre</dt>
    <dd>
     <a href='agrega.html?id=$id'>Agregar al carrito</a>
    </dd>
    <dd>
     <dl>
      <dt>Precio</dt>
      <dd>$precio</dd>
      <dt>Existencias</dt>
      <dd>$existencias</dd>
     </dl>
    </dd>";
}
devuelveJson(["lista" => ["innerHTML" => $render]]);
