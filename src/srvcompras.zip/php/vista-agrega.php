<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";

$id = recibeEnteroObligatorio("id");

$producto = productoBusca(Bd::pdo(), $id);
$producto = validaEntidadObligatoria("Producto",  $producto);

devuelveJson([
 "id" => ["value" => $id],
 "producto" => ["value" => $producto["PROD_NOMBRE"]],
 "precio" => ["value" => "$" . number_format($producto["PROD_PRECIO"], 2)],
]);
