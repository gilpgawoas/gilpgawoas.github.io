<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/devuelveNoContent.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";

$prodId = recibeEnteroObligatorio("prodId");

$bd = Bd::pdo();

$venta = ventaEnCapturaBusca($bd);
if ($venta !== false) {
 $stmt = $bd->prepare(
  "DELETE FROM DET_VENTA WHERE VENT_ID = :VENT_ID AND PROD_ID = :PROD_ID"
 );
 $stmt->execute([":VENT_ID" => $venta["VENT_ID"], ":PROD_ID" => $prodId]);
}
devuelveNoContent();
