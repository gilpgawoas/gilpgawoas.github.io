<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/devuelveCreated.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/ventaEnCapturaBusca.php";
require_once __DIR__ . "/detVentaConsulta.php";
require_once __DIR__ . "/ventaEnCapturaAgrega.php";

$bd = Bd::pdo();
$bd->beginTransaction();

$venta = ventaEnCapturaBusca($bd);
$venta = validaEntidadObligatoria("Venta en captura",  $venta);

$detalles = detVentaConsulta($bd, $venta["VENT_ID"]);

// Actualiza las existencias de los productos vendidos.
$update = $bd->prepare(
 "UPDATE PRODUCTO
   SET PROD_EXISTENCIAS = :PROD_EXISTENCIAS
   WHERE PROD_ID = :PROD_ID"
);
foreach ($detalles as $detVenta) {
 $update->execute([
  ":PROD_ID" => $detVenta["PROD_ID"],
  ":PROD_EXISTENCIAS" =>
  $detVenta["PROD_EXISTENCIAS"] - $detVenta["DTV_CANTIDAD"]
 ]);
}

$update = $bd->prepare(
 "UPDATE VENTA
   SET VENT_EN_CAPTURA = 0
   WHERE VENT_ID = :VENT_ID"
);
$update->execute([":VENT_ID" => $venta["VENT_ID"]]);

ventaEnCapturaAgrega($bd);
$folio = $bd->lastInsertId();

$bd->commit();

devuelveCreated("/srv/venta-en-captura.php", [
 "folio" => ["value" => $folio],
 "detalles" => ["innerHTML" => ""]
]);
