<?php

require_once __DIR__ . "/ventaEnCapturaAgrega.php";

class Bd
{

 private static ?PDO $pdo = null;

 public static function pdo(): PDO
 {
  if (self::$pdo === null) {
   self::$pdo = new PDO(
    // cadena de conexión
    "sqlite:" . __DIR__ . "/srvcompras.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: pdos no persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS VENTA (
      VENT_ID INTEGER,
      VENT_EN_CAPTURA INTEGER NOT NULL,
      CONSTRAINT VENT_PK
       PRIMARY KEY(VENT_ID)
     )'
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS PRODUCTO (
      PROD_ID INTEGER,
      PROD_NOMBRE TEXT NOT NULL,
      PROD_EXISTENCIAS REAL NOT NULL,
      PROD_PRECIO REAL NOT NULL,
      CONSTRAINT PROD_PK
       PRIMARY KEY(PROD_ID),
      CONSTRAINT PROD_NOM_UNQ
       UNIQUE(PROD_NOMBRE),
      CONSTRAINT PROD_NOM_NV
       CHECK(LENGTH(PROD_NOMBRE) > 0)
     )'
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS DET_VENTA (
      VENT_ID INTEGER NOT NULL,
      PROD_ID INTEGER NOT NULL,
      DTV_CANTIDAD REAL NOT NULL,
      DTV_PRECIO REAL NOT NULL,
      CONSTRAINT DTV_PK
       PRIMARY KEY (VENT_ID, PROD_ID),
      CONSTRAINT DTV_VENT_FK
       FOREIGN KEY (VENT_ID) REFERENCES VENTA(VENT_ID),
      CONSTRAINT DTV_PROD_FK
       FOREIGN KEY (PROD_ID) REFERENCES PRODUCTO(PROD_ID)
      )'
   );

   $cantidadDeProductos =
    self::$pdo->query("SELECT COUNT(PROD_ID) FROM PRODUCTO")->fetchColumn(0);

   if ($cantidadDeProductos === 0) {
    self::$pdo->exec(
     "INSERT INTO PRODUCTO
       (PROD_NOMBRE, PROD_EXISTENCIAS, PROD_PRECIO)
      VALUES
       ('Sandwich', 50, 15),
       ('Hot dog', 40, 30),
       ('Hamburguesa', 30, 40)"
    );
   }

   $cantidadDeVentas =
    self::$pdo->query("SELECT COUNT(VENT_ID) FROM VENTA")->fetchColumn(0);

   if ($cantidadDeVentas === 0) {
    ventaEnCapturaAgrega(self::$pdo);
   }
  }

  return self::$pdo;
 }
}
