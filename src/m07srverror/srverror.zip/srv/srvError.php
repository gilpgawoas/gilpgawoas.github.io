<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";

ejecuta(function () {
 throw new Exception("Ouch");
});
