<?php

require_once __DIR__ . "/../lib/php/BAD_REQUEST.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";

function validaPasId(false|null|int $pasId)
{

 if ($pasId === false)
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "Falta pasId.",
   type: "/error/faltapasid.html",
   detail: "La solicitud no tiene el valor de pasId."
  );

 return $pasId;
}
