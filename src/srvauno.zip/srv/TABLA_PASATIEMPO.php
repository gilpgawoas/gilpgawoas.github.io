<?php

const PASATIEMPO = "PASATIEMPO";
const PAS_ID = "PAS_ID";
const PAS_NOMBRE = "PAS_NOMBRE";
