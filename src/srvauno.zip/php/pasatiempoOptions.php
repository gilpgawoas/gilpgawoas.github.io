<?php

require_once __DIR__ . "/Bd.php";

function pasatiempoOptons()
{
 $bd = Bd::pdo();
 $stmt = $bd->query("SELECT * FROM PASATIEMPO ORDER BY PAS_NOMBRE");
 $lista = $stmt->fetchAll(PDO::FETCH_ASSOC);

 $render = "<option value=''>-- Sin pasatiempo --</option>";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo["PAS_ID"]);
  $nombre = htmlentities($modelo["PAS_NOMBRE"]);
  $render .= "<option value='$id'>{$nombre}</option>";
 }

 return $render;
}
