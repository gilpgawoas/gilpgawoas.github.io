<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/recibeTextoObligatorio.php";
require_once __DIR__ . "/lib/recibeEnteroOpcional.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/pasatiempoOptions.php";

$id = recibeEnteroObligatorio("id");
$nombre = recibeTextoObligatorio("nombre");
$pasId = recibeEnteroOpcional("pasId");

$bd = Bd::pdo();
$stmt = $bd->prepare(
 "UPDATE AMIGO
   SET
    AMI_NOMBRE = :AMI_NOMBRE,
    PAS_ID = :PAS_ID
   WHERE
    AMI_ID = :AMI_ID"
);
$stmt->execute([
 ":AMI_NOMBRE" => $nombre,
 ":PAS_ID" => $pasId,
 ":AMI_ID" => $id,
]);

devuelveJson([
 "id" => ["value" => $id],
 "nombre" => ["value" => $nombre],
 "pasId" => [
  "innerHTML" => pasatiempoOptons(),
  "value" => $pasId === null ? "" : $pasId
 ]
]);
