<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/pasatiempoOptions.php";

$amiId = recibeEnteroObligatorio("id");

$bd = Bd::pdo();
$stmt = $bd->prepare("SELECT * FROM AMIGO WHERE AMI_ID = :AMI_ID");
$stmt->execute([":AMI_ID" => $amiId]);
$modelo = $stmt->fetch(PDO::FETCH_ASSOC);

$modelo = validaEntidadObligatoria("Amigo",  $modelo);

devuelveJson([
 "id" => ["value" => $amiId],
 "nombre" => ["value" => $modelo["AMI_NOMBRE"]],
 "pasId" => [
  "innerHTML" => pasatiempoOptons(),
  "value" => $modelo["PAS_ID"] === null ? "" : $modelo["PAS_ID"]
 ]
]);
