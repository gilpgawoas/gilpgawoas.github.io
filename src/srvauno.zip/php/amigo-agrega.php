<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEntero.php";
require_once __DIR__ . "/lib/recibeTextoObligatorio.php";
require_once __DIR__ . "/lib/recibeEnteroOpcional.php";
require_once __DIR__ . "/lib/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/pasatiempoOptions.php";

$nombre = recibeTextoObligatorio("nombre");
$pasId = recibeEnteroOpcional("pasId");

$pdo = Bd::pdo();
$stmt = $pdo->prepare(
 "INSERT INTO AMIGO (
   AMI_NOMBRE, PAS_ID
  ) values (
   :PAS_NOMBRE, :PAS_ID
  )"
);
$stmt->execute([
 ":PAS_NOMBRE" => $nombre,
 ":PAS_ID" => $pasId
]);
$id = $pdo->lastInsertId();

$encodeId = urlencode($id);
devuelveCreated(
 "/php/amigo-vista-modifica.php?id=$encodeId",
 [
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
  "pasId" => [
   "innerHTML" => pasatiempoOptons(),
   "value" => $pasId === null ? "" : $pasId
  ]
 ]
);
