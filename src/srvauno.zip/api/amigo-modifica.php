<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeTextoObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroOpcional.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/pasatiempoOptions.php";

$id = recibeEnteroObligatorio("id");
$nombre = recibeTextoObligatorio("nombre");
$pasId = recibeEnteroOpcional("pasId");

$bd = Bd::conexion();
$stmt = $bd->prepare(
 "UPDATE AMIGO
   SET
    AMI_NOMBRE = TRIM(:AMI_NOMBRE),
    AMI_PAS_ID = :AMI_PAS_ID
   WHERE
    AMI_ID = :AMI_ID"
);
$stmt->execute([
 ":AMI_NOMBRE" => $nombre,
 ":AMI_PAS_ID" => $pasId,
 ":AMI_ID" => $id,
]);

devuelveJson([
 "id" => ["value" => $id],
 "nombre" => ["value" => $nombre],
 "pasId" => [
  "innerHTML" => pasatiempoOptons(),
  "value" => $pasId === null ? "" : $pasId
 ]
]);
