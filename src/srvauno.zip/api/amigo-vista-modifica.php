<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/pasatiempoOptions.php";

$amiId = recibeEnteroObligatorio("id");

$bd = Bd::conexion();
$stmt = $bd->prepare("SELECT * FROM AMIGO WHERE AMI_ID = :AMI_ID");
$stmt->execute([":AMI_ID" => $amiId]);
$modelo = $stmt->fetch(PDO::FETCH_ASSOC);

$modelo = validaEntidadObligatoria("Amigo",  $modelo);
$pasId = $modelo["AMI_PAS_ID"];

devuelveJson([
 "id" => ["value" => $amiId],
 "nombre" => ["value" => $modelo["AMI_NOMBRE"]],
 "pasId" => [
  "innerHTML" => pasatiempoOptons(),
  "value" => $pasId === null ? "" : $pasId
 ]
]);
