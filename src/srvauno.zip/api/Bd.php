<?php

class Bd
{
 private static ?PDO $pdo = null;

 static function conexion(): PDO
 {
  if (self::$pdo === null) {

   self::$pdo = new PDO(
    // cadena de conexión
    "sqlite:" . __DIR__ . "/srvauno.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: pdos no persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$pdo->exec(
    "CREATE TABLE IF NOT EXISTS PASATIEMPO (
      PAS_ID INTEGER,
      PAS_NOMBRE TEXT NOT NULL,
      CONSTRAINT PK_PAS PRIMARY KEY(PAS_ID),
      CONSTRAINT UQ_PAS_NOM UNIQUE(PAS_NOMBRE),
      CONSTRAINT CHK_PAS_NOM CHECK(LENGTH(PAS_NOMBRE) > 0)
     )"
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS AMIGO (
      AMI_ID INTEGER,
      AMI_NOMBRE TEXT NOT NULL,
      AMI_PAS_ID INTEGER,
      CONSTRAINT PK_AMI PRIMARY KEY(AMI_ID),
      CONSTRAINT UQ_AMI_NOM UNIQUE(AMI_NOMBRE),
      CONSTRAINT CHK_AMI_NOM CHECK(LENGTH(AMI_NOMBRE) > 0),
      CONSTRAINT FK_AMI_PAS
       FOREIGN KEY (AMI_PAS_ID) REFERENCES PASATIEMPO(PAS_ID)
     )'
   );

   $cantidadDePasatiempos =
    self::$pdo->query("SELECT COUNT(PAS_ID) FROM PASATIEMPO")->fetchColumn(0);

   if ($cantidadDePasatiempos === 0) {
    self::$pdo->exec(
     "INSERT INTO PASATIEMPO (PAS_NOMBRE) VALUES ('Futbol'), ('Videojuegos')"
    );
   }
  }

  return self::$pdo;
 }
}
