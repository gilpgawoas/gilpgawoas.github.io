<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

$bd = Bd::conexion();
$stmt = $bd->query(
 "SELECT
    A.AMI_ID,
    A.AMI_NOMBRE,
    P.PAS_NOMBRE
   FROM AMIGO A
    LEFT JOIN PASATIEMPO P
    ON A.AMI_PAS_ID = P.PAS_ID
   ORDER BY
    A.AMI_NOMBRE"
);
$lista = $stmt->fetchAll(PDO::FETCH_ASSOC);

$render = "";
foreach ($lista as $modelo) {
 $amiId = $modelo["AMI_ID"];
 $query = htmlentities(http_build_query(["id" => $amiId]));
 $urlModifica = "modifica.html?$query";
 $amiNombre = htmlentities($modelo["AMI_NOMBRE"]);
 $pasNombre = $modelo["PAS_NOMBRE"] === null
  ? "<em>-- Sin pasatiempo --</em>"
  : htmlentities($modelo["PAS_NOMBRE"]);
 $render .=
  "<dt><a href='$urlModifica'>$amiNombre</a></dt>
    <dd><a href='$urlModifica'>$pasNombre</a></dd>";
}

devuelveJson(["lista" => ["innerHTML" => $render]]);
