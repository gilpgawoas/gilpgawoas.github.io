<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/pasatiempoOptions.php";

devuelveJson(["pasId" => ["innerHTML" => pasatiempoOptons()]]);
