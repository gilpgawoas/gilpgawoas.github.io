<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEntero.php";
require_once __DIR__ . "/../libservidorphp/recibeTextoObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroOpcional.php";
require_once __DIR__ . "/../libservidorphp/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/pasatiempoOptions.php";

$nombre = recibeTextoObligatorio("nombre");
$pasId = recibeEnteroOpcional("pasId");

$pdo = Bd::conexion();
$stmt = $pdo->prepare(
 "INSERT INTO AMIGO (
   AMI_NOMBRE, AMI_PAS_ID
  ) values (
   TRIM(:AMI_NOMBRE), :AMI_PAS_ID
  )"
);
$stmt->execute([
 ":AMI_NOMBRE" => $nombre,
 ":AMI_PAS_ID" => $pasId
]);
$id = $pdo->lastInsertId();

$query = http_build_query(["id" => $id]);
devuelveCreated(
 "/api/amigo-vista-modifica.php?$query",
 [
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
  "pasId" => [
   "innerHTML" => pasatiempoOptons(),
   "value" => $pasId === null ? "" : $pasId
  ]
 ]
);
