<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/devuelveJson.php";

devuelveJson([
 [
  "nombre" => "pp",
  "color" => "azul"
 ],
 [
  "nombre" => "kq",
  "color" => "rojo"
 ],
 [
  "nombre" => "tt",
  "color" => "rosa"
 ],
 [
  "nombre" => "bb",
  "color" => "azul"
 ]
]);
