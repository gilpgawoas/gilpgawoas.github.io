<?php
require_once __DIR__ .
 "/../lib/php/Servicio.php";

class SrvRender extends Servicio
{
 protected
 function implementacion()
 {
  $lista = [
   ["nombre" => "pp"],
   ["nombre" => "kq"],
   ["nombre" => "tt"],
   ["nombre" => "bb"]
  ];
  $render = "";
  foreach ($lista as $it) {
   $nombre =
    htmlentities($it["nombre"]);
   $render .=
    "<li>
      <p>
       {$nombre}
      </p>
     </li>";
  }
  return ["render" => $render];
 }
}

$servicio = new SrvRender();
$servicio->ejecuta();
