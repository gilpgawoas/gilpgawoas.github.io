<?php

namespace Srv;

use \SplObjectStorage;
use
 Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

const ID = "id";
const CASTIGADO = "castigado";
const PERDONAME = "perdóname";
const ALIAS = "alias";
const ADMINISTRADOR =
"administrador";
const MENSAJE = "mensaje";

class ChatSerio implements
 MessageComponentInterface
{
 private
 SplObjectStorage $conexiones;
 private string $msgCastigado;

 public function __construct()
 {
  // Crea un arreglo de objetos.
  $this->conexiones =
   new SplObjectStorage;
  $info_castigado = [
   ALIAS => ADMINISTRADOR,
   MENSAJE => CASTIGADO
  ];
  $this->msgCastigado =
   json_encode($info_castigado);
 }

 public function onOpen(
  ConnectionInterface $con
 ) {
  // Guarda la conexión.
  $this->conexiones->attach(
   $con,
   [
    ID => $con->resourceId,
    CASTIGADO => false
   ]
  );
  echo "Conectado: " .
   $con->resourceId . "\n";
 }

 public function onMessage(
  ConnectionInterface $origen,
  $msg
 ) {
  $conexiones = $this->conexiones;
  $info = $conexiones[$origen];
  $id = $info[ID];
  $castigado = $info[CASTIGADO];
  $json = json_decode($msg);
  $alias = $json->alias;
  $mensaje = $json->mensaje;

  if ($castigado) {
   if ($mensaje === PERDONAME) {
    $castigado = false;
   } else {
    $origen->send(
     $this->msgCastigado
    );
   }
  } elseif (
   preg_match(
    "/(^|\s+)wey($|\s+)/i",
    $mensaje
   )
   !== 0
  ) {
   $castigado = true;
   $origen->send(
    $this->msgCastigado
   );
  }
  $info[CASTIGADO] = $castigado;
  $conexiones[$origen] = $info;
  echo "
Origen: {$id}
Castigado: {$castigado}
alias: {$alias}
Mensaje: {$mensaje}
";
  $conexiones->rewind();
  while ($conexiones->valid()) {
   $con = $conexiones->current();
   $info = $conexiones->getInfo();
   var_dump($info);
   if (!$info[CASTIGADO]) {
    $con->send($msg);
   }
   $conexiones->next();
  }
 }

 public function onClose(
  ConnectionInterface $con
 ) {
  $this->conexiones->detach($con);
  echo "Desconectado: " .
   $con->resourceId . "\n";
 }

 public function onError(
  ConnectionInterface $con,
  \Exception $e
 ) {
  echo "Error: " .
   $e->getMessage() . "\n";
  $con->close();
 }
}
