<?php

namespace Srv;

require_once
 "srv/txt/txtAdministrador.php";
require_once
 "srv/txt/txtCastigado.php";
require_once
 "srv/txt/txtPerdoname.php";

use \SplObjectStorage;
use
 Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

const ID = "id";
const ALIAS = "alias";
const MENSAJE = "mensaje";
const CASTIGADO = "castigado";

class ChatSerio implements
 MessageComponentInterface
{
 private
 SplObjectStorage $conexiones;
 private string $msgCastigado;
 private string $perdoname;

 public function __construct()
 {
  // Crea un arreglo de objetos.
  $this->conexiones =
   new SplObjectStorage;
  $this->perdoname =
   txtPerdoname();
  $info_castigado = [
   ALIAS => txtAdministrador(),
   MENSAJE => txtCastigado()
  ];
  $this->msgCastigado =
   json_encode($info_castigado);
 }

 public function onOpen(
  ConnectionInterface $con
 ) {
  // Guarda la conexión.
  $this->conexiones->attach(
   $con,
   [
    ID => $con->resourceId,
    CASTIGADO => false
   ]
  );
  echo "Conectado: " .
   $con->resourceId . "\n";
 }

 public function onMessage(
  ConnectionInterface $origen,
  $msg
 ) {
  $conexiones = $this->conexiones;
  $info = $conexiones[$origen];
  $id = $info[ID];
  $castigado = $info[CASTIGADO];
  $json = json_decode($msg);
  $alias = $json->alias;
  $mensaje = $json->mensaje;

  if ($castigado) {
   if (
    $mensaje === $this->perdoname
   ) {
    $castigado = false;
   } else {
    $origen->send(
     $this->msgCastigado
    );
   }
  } elseif (
   preg_match(
    "/(^|\s+)wey($|\s+)/i",
    $mensaje
   )
   !== 0
  ) {
   $castigado = true;
   $origen->send(
    $this->msgCastigado
   );
  }
  $info[CASTIGADO] = $castigado;
  $conexiones[$origen] = $info;
  $casStr =
   $castigado ? "true" : "false";
  echo "
Origen: {$id}
Castigado: {$casStr}
alias: {$alias}
Mensaje: {$mensaje}
";
  $conexiones->rewind();
  while ($conexiones->valid()) {
   $con = $conexiones->current();
   $info = $conexiones->getInfo();
   var_dump($info);
   if (!$info[CASTIGADO]) {
    $con->send($msg);
   }
   $conexiones->next();
  }
 }

 public function onClose(
  ConnectionInterface $con
 ) {
  $this->conexiones->detach($con);
  echo "Desconectado: " .
   $con->resourceId . "\n";
 }

 public function onError(
  ConnectionInterface $con,
  \Exception $e
 ) {
  echo "Error: " .
   $e->getMessage() . "\n";
  $con->close();
 }
}
