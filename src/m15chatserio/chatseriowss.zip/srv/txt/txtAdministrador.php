<?php

function txtAdministrador(): string
{
 return "Administrador";
}
