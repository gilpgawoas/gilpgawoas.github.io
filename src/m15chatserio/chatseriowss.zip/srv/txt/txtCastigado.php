<?php

function txtCastigado(): string
{
 return "Castigado.";
}
