<?php

function txtPerdoname(): string
{
 return "perdóname";
}
