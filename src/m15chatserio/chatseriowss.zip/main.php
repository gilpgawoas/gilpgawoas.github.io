<?php

require __DIR__ .
 '/vendor/autoload.php';

/* Como este ejemplo usa el
 * autoload de composer, los
 * nombres de las clases y de los
 * namespace debe coincidir en
 * mayúsculas y minúsculas con el
 * nombre de las carpetas y de los
 * archivos. */

use Srv\ChatSerio;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

$server = IoServer::factory(
 new HttpServer(
  new WsServer(
   new ChatSerio()
  )
 ),
 80
);

$server->run();
