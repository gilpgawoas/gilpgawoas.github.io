<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/rolCheckboxes.php";

devuelveJson(["roles" => ["innerHTML" =>  rolCheckboxes()]]);
