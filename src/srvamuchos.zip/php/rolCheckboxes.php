<?php

require_once __DIR__ . "/Bd.php";

function rolCheckboxes()
{
 $bd = Bd::pdo();
 $lista =
  $bd->query("SELECT * FROM ROL ORDER BY ROL_ID")->fetchAll(PDO::FETCH_ASSOC);

 $render = "<legend>Roles</legend>";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo["ROL_ID"]);
  $descripcion = htmlentities($modelo["ROL_DESCRIPCION"]);
  $render .=
   "<p>
    <label style='display: flex'>
     <input type='checkbox' name='rolIds[]' value='$id'>
     <span>
      <strong style='display: block'>$id</strong>
      $descripcion
     </span>
    </label>
   </p>";
 }

 return $render;
}
