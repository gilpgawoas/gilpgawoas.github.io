<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeTextoObligatorio.php";
require_once __DIR__ . "/lib/recibeArray.php";
require_once __DIR__ . "/lib/usuRolAgrega.php";
require_once __DIR__ . "/lib/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/rolCheckboxes.php";

$san = recibeTextoObligatorio("san");
$rolIds = recibeArray("rolIds");

$bd = Bd::pdo();
$bd->beginTransaction();

$stmt = $bd->prepare(
 "INSERT INTO USUARIO (
    USU_SAN
   ) values (
    :USU_SAN
   )"
);
$stmt->execute([
 ":USU_SAN" => $san
]);
$usuId = $bd->lastInsertId();

usuRolAgrega($bd, $usuId, $rolIds);

$bd->commit();

$encodeUsuId = urlencode($usuId);
devuelveCreated("/php/usuario-vista-modifica.php?id=$encodeUsuId", [
 "id" => ["value" => $usuId],
 "san" => ["value" => $san],
 "roles" => ["innerHTML" =>  rolCheckboxes()],
 "rolIds[]" => ["value" => $rolIds],
]);
