<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/lib/rolIdsParaUsuId.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/rolCheckboxes.php";

$usuId = recibeEnteroObligatorio("id");

$bd = Bd::pdo();

$stmt = $bd->prepare("SELECT * FROM USUARIO WHERE USU_ID = :USU_ID");
$stmt->execute([":USU_ID" => $usuId]);
$modelo = $stmt->fetch(PDO::FETCH_ASSOC);

$modelo = validaEntidadObligatoria("Usuario",  $modelo);

$rolIds = rolIdsParaUsuId(Bd::pdo(), $usuId);

devuelveJson([
 "id" => ["value" => $usuId],
 "san" => ["value" => $modelo["USU_SAN"]],
 "roles" => ["innerHTML" =>  rolCheckboxes()],
 "rolIds[]" => $rolIds
]);
