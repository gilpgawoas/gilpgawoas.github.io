<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/devuelveNoContent.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/usuRolElimina.php";

$usuId = recibeEnteroObligatorio("id");

$bd = Bd::pdo();
$bd->beginTransaction();

usuRolElimina($bd, $usuId);

$stmt = $bd->prepare("DELETE FROM USUARIO WHERE USU_ID = :USU_ID");
$stmt->execute([":USU_ID" => $usuId]);

$bd->commit();

devuelveNoContent();
