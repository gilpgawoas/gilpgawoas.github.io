<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

$bd = Bd::pdo();
$stmt = $bd->query(
 "SELECT
    U.USU_ID,
    U.USU_SAN,
    GROUP_CONCAT(UR.ROL_ID, ', ') AS roles
   FROM
    USUARIO U LEFT JOIN USU_ROL UR
     ON U.USU_ID = UR.USU_ID
   GROUP BY
    U.USU_SAN
   ORDER BY
    U.USU_SAN"
);
$lista = $stmt->fetchAll(PDO::FETCH_ASSOC);

$render = "";
foreach ($lista as $modelo) {
 $encodeUsuId = urlencode($modelo["USU_ID"]);
 $usuId = htmlentities($encodeUsuId);
 $usuSan = htmlentities($modelo["USU_SAN"]);
 $roles = $modelo["roles"] === null || $modelo["roles"] === ""
  ? "<em>-- Sin roles --</em>"
  : htmlentities($modelo["roles"]);
 $render .=
  "<dt><a href='modifica.html?id=$usuId'>$usuSan</a></dt>
    <dd><a href='modifica.html?id=$usuId'>$roles</a></dd>";
}

devuelveJson(["lista" => ["innerHTML" => $render]]);
