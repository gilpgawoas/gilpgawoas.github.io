<?php

function usuRolElimina(\PDO $bd, string $usuId)
{
 $usuRolElimina = $bd->prepare("DELETE FROM USU_ROL WHERE USU_ID = :USU_ID");
 $usuRolElimina->execute([":USU_ID" => $usuId]);
}
