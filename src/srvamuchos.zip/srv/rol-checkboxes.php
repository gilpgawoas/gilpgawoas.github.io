<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $conexionexion = Bd::getConexion();
 $lista = fetchAll($conexionexion->query(
  "SELECT
    ROL_ID as id,
    ROL_DESCRIPCION as descripcion
   FROM ROL
   ORDER BY ROL_ID"
 ));

 $render = "";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo->id);
  $descripcion = htmlentities($modelo->descripcion);
  $render .=
   "<p>
     <label style='display: flex'>
      <input type='checkbox' name='rolIds[]' value='$id'>
      <span>
       <strong>$id</strong>
       <br>$descripcion
      </span>
     </label>
    </p>";
 }

 devuelveJson(["roles" => ["innerHTML" => $render]]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
