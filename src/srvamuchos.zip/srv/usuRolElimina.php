<?php

require_once __DIR__ . "/Bd.php";

function usuRolElimina(int $usuId)
{

 $conexion = Bd::getConexion();

 $conexion->prepare(
  "DELETE FROM USU_ROL
   WHERE USU_ID = :usuId"
 )
  ->execute([":usuId" => $usuId]);
}
