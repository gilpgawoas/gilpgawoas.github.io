<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $conexionexion = Bd::getConexion();
 $lista = fetchAll($conexionexion->query(
  "SELECT
    U.USU_ID AS usuId,
    U.USU_CUE AS usuCue,
    GROUP_CONCAT(R.ROL_ID, ', ') AS roles
   FROM USUARIO U
    LEFT JOIN USU_ROL UR
    ON U.USU_ID = UR.USU_ID
    LEFT JOIN ROL R
    ON UR.ROL_ID = R.ROL_ID
   GROUP BY U.USU_CUE
   ORDER BY U.USU_CUE"
 ));

 $render = "";
 foreach ($lista as $modelo) {
  $encodeUsuId = urlencode($modelo->usuId);
  $usuId = htmlentities($encodeUsuId);
  $usuCue = htmlentities($modelo->usuCue);
  $roles = $modelo->roles === null || $modelo->roles === ""
   ? "<em>-- Sin roles --</em>"
   : htmlentities($modelo->roles);
  $render .=
   "<dt><a href='modifica.html?id=$usuId'>$usuCue</a></dt>
    <dd><a href='modifica.html?id=$usuId'>$roles</a></dd>";
 }

 devuelveJson(["lista" => ["innerHTML" => $render]]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
