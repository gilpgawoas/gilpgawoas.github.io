<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaArray.php";
require_once __DIR__ . "/../lib/php/validaCue.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/../lib/php/usuRolAgrega.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/usuRolElimina.php";

try {

 $usuId = recuperaIdEntero("id");
 $cue = recuperaTexto("cue");
 $rolIds = recuperaArray("rolIds");

 $cue = validaCue($cue);

 $conexion = Bd::getConexion();
 $conexion->beginTransaction();

 $conexion->prepare(
  "UPDATE USUARIO
   SET USU_CUE = :cue
   WHERE USU_ID = :id"
 )
  ->execute([
   ":id" => $usuId,
   ":cue" => $cue
  ]);

 usuRolElimina($usuId);
 usuRolAgrega($conexion, $usuId, $rolIds);

 $conexion->commit();

 devuelveJson([
  "id" => ["value" => $usuId],
  "cue" => ["value" => $cue],
  "rolIds" => ["value" => $rolIds],
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
