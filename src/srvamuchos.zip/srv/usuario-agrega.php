<?php

require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaArray.php";
require_once __DIR__ . "/../lib/php/validaCue.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/../lib/php/usuRolAgrega.php";
require_once __DIR__ . "/Bd.php";

try {

 $cue = recuperaTexto("cue");
 $rolIds = recuperaArray("rolIds");

 $cue = validaCue($cue);

 $conexion = Bd::getConexion();
 $conexion->beginTransaction();

 $conexion->prepare(
  "INSERT INTO USUARIO
    (USU_CUE)
   VALUES
    (:cue)"
 )
  ->execute([":cue" => $cue]);

 /* Recupera el id generado. Si usas una secuencia, pasa como
  * parámetro de lastInsertId el nombre de dicha secuencia y
  * poner esta instrucción antes del INSERT, al cual se le
  * pasarle el id generado. */
  $usuId = $conexion->lastInsertId();

 usuRolAgrega($conexion, $usuId, $rolIds);

 $conexion->commit();

 $encodeUsuId = urlencode($usuId);

 devuelveCreated("/srv/usuario.php?id=$encodeUsuId", [
  "id" => ["value" => $usuId],
  "cue" => ["value" => $cue],
  "rolIds" => ["value" => $rolIds],
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
