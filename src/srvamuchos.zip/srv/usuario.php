<?php

require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/../lib/php/usuRolIds.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $usuId = recuperaIdEntero("id");

 $conexion = Bd::getConexion();
 $modelo = fetch(
  $conexion->prepare(
   "SELECT
    USU_ID as id,
    USU_CUE as cue
   FROM USUARIO
   WHERE USU_ID = :usuId"
  ),
  [":usuId" => $usuId]
 );

 if ($modelo === false) {
  $htmlId = htmlentities($id);
  throw new ProblemDetails(
   title: "Usuario no encontrado.",
   status: NOT_FOUND,
   type: "/error/usuarionoencontrado.html",
   detail: "No se encontró ningún usuario con el id $htmlId.",
  );
 } else {

  $rolIds = usuRolIds($conexion, $usuId);

  devuelveJson([
   "id" => ["value" => $usuId],
   "cue" => ["value" => $modelo->cue],
   "rolIds[]" => $rolIds
  ]);
 }
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
