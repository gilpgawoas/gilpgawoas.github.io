<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/devuelveNoContent.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/usuRolElimina.php";

try {

 $usuId = recuperaIdEntero("id");

 $conexion = Bd::getConexion();
 $conexion->beginTransaction();

 usuRolElimina($usuId);

 $stmt = $conexion->prepare(
  "DELETE FROM USUARIO
   WHERE USU_ID = :id"
 )
  ->execute([":id" => $usuId]);

 $conexion->commit();

 devuelveNoContent();
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
