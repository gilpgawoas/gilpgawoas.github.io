<?php

const USUARIO = "USUARIO";
const USU_ID = "USU_ID";
const USU_CUE = "USU_CUE";
