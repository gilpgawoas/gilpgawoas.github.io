<?php

const USU_ROL = "USU_ROL";
