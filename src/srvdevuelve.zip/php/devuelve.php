<?php

require_once __DIR__ . "/lib/devuelveJson.php";

devuelveJson([
 "nombre" => "pp",
 "mensaje" => "Hola.",
]);
