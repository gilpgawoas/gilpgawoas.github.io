<?php

use \SplObjectStorage;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements MessageComponentInterface
{

 protected SplObjectStorage $conexionesDeClientes;

 public function __construct()
 {
  // Crea una colección que se accesa usando objetos.
  $this->conexionesDeClientes = new SplObjectStorage;
 }

 /** Se invoca al abrirse una conexión desde un cliente. */
 public function onOpen(ConnectionInterface $conexionDeCliente)
 {
  // Guarda la conexión.
  $this->conexionesDeClientes->attach(
   $conexionDeCliente,
   $conexionDeCliente->resourceId
  );
  echo "Conectado: " . $conexionDeCliente->resourceId . "\n";
 }

 /** Se invoca al recibir un mensaje de un cliente. */
 public function onMessage(
  ConnectionInterface $conexionDeClienteQueEnvia,
  $mensaje
 ) {
  $id = $this->conexionesDeClientes[$conexionDeClienteQueEnvia];
  echo "
Origen: {$id}
Mensaje: $mensaje
";
  foreach ($this->conexionesDeClientes as $conexionDeCliente) {
   $conexionDeCliente->send($mensaje);
  }
 }

 /** Se invoca al cerrar la conexión de un cliente. */
 public function onClose(ConnectionInterface $conexionDeCliente)
 {
  $this->conexionesDeClientes->detach($conexionDeCliente);
  echo "Desconectado: " . $conexionDeCliente->resourceId . "\n";
 }

 /** Se invoca cuando hay un error en la conexión de un cliente. */
 public function onError(
  ConnectionInterface $conexionDeCliente,
  Exception $error
 ) {
  echo "Error: " . $error->getMessage() . "\n";
  $conexionDeCliente->close();
 }
}
