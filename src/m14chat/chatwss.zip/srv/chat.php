<?php

namespace Srv;

use \SplObjectStorage;
use
 Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements
 MessageComponentInterface
{
 protected
 SplObjectStorage $conexiones;

 public function __construct()
 {
  // Crea un arreglo de objetos.
  $this->conexiones =
   new SplObjectStorage;
 }

 public function onOpen(
  ConnectionInterface $con
 ) {
  // Guarda la conexión.
  $this->conexiones->attach(
   $con,
   $con->resourceId
  );
  echo "Conectado: " .
   $con->resourceId . "\n";
 }

 public function onMessage(
  ConnectionInterface $origen,
  $msg
 ) {
  $id = $this->conexiones[$origen];
  echo "
Origen: {$id}
Mensaje: $msg\n";
  foreach ($this->conexiones
   as $con) {
   $con->send($msg);
  }
 }

 public function onClose(
  ConnectionInterface $con
 ) {
  $this->conexiones->detach($con);
  echo "Desconectado: " .
   $con->resourceId . "\n";
 }

 public function onError(
  ConnectionInterface $con,
  \Exception $e
 ) {
  echo "Error: " .
   $e->getMessage() . "\n";
  $con->close();
 }
}
