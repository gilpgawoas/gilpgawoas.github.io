<?php

require_once __DIR__ . "/../lib/php/BAD_REQUEST.php";
require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/validaToken.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";

ejecutaServicio(function () {

 session_start();

 $token = recuperaTexto("token");
 if ($token === false) {
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "Falta el token.",
   type: "/error/faltatoken.html",
  );
 }

 validaToken("formulario", $token);

 // Si el token se halló, precesa normalmente la forma.

 $saludo = recuperaTexto("saludo");
 $nombre = recuperaTexto("nombre");

 if ($saludo === false)
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "Falta el saludo.",
   type: "/error/faltasaludo.html",
   detail: "La solicitud no tiene el valor de saludo.",
  );

 if ($saludo === "")
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "El saludo está en blanco.",
   type: "/error/saludoenblanco.html",
   detail: "Pon texto en el campo saludo.",
  );

 if ($nombre === false)
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "Falta el nombre.",
   type: "/error/faltanombre.html",
   detail: "La solicitud no tiene el valor de nombre.",
  );

 if ($nombre === "")
  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "El nombre está en blanco.",
   type: "/error/nombreenblanco.html",
   detail: "Pon texto en el campo nombre.",
  );

 $resultado = "{$saludo} {$nombre}.";

 devuelveJson($resultado);
});
