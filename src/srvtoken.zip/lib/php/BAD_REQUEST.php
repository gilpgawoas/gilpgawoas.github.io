<?php

const BAD_REQUEST = 400;
