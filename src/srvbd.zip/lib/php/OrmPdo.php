<?php

require_once __DIR__ . "/fetch.php";

class OrmPdo
{
 private string $nombreDeTabla;
 /**
  * @var string[]
  */
 private array $nombresDeLlaves;
 /**
  * @var string[]
  */
 private array $nombresDeCampos;
 private bool $autoincrement;
 private string $sequence;

 /**
  * @param string[] $nombresDeLlaves
  * @param string[] $nombresDeCampos
  */
 public function __construct(
  string $nombreDeTabla,
  array $nombresDeLlaves,
  array $nombresDeCampos,
  bool $autoincrement = true,
  string $sequence = "",
 ) {
  $this->nombreDeTabla = $nombreDeTabla;
  $this->nombresDeLlaves = $nombresDeLlaves;
  $this->autoincrement = $autoincrement;
  $this->sequence = $sequence;
  $this->nombresDeCampos = $nombresDeCampos;
 }

 /**
  * @param array[] $objetos
  */
 public function insert(PDO $conexion, array $objetos)
 {

  $sqlCampos = implode(",", $this->nombresDeCampos);
  $sqlValoresCampos =
   implode(",", $this->convierteCamposEnParametros($this->nombresDeCampos));

  if ($this->autoincrement) {

   $sql =
    "INSERT INTO $this->nombreDeTabla ($sqlCampos) VALUES ($sqlValoresCampos)";

   /**
    * @var string[]
    */
   $llaves = [];
   $statement = $conexion->prepare($sql);
   foreach ($objetos as $objeto) {
    $this->ejecutaStatement($statement, $objeto);
    if ($this->sequence === "") {
     $id = $conexion->lastInsertId();
    } else {
     $id = $conexion->lastInsertId($this->sequence);
    }
    if ($id === false) {
     $llaves[] = "";
    } else {
     $llaves[] = $id;
    }
   }
   return $llaves;
  } else {

   $sqlLlaves = implode(",", $this->nombresDeLlaves);
   $sqlValoresLlaves =
    implode(",", $this->convierteCamposEnParametros($this->nombresDeLlaves));
   $sql =
    "INSERT INTO $this->nombreDeTabla ($sqlLlaves,$sqlCampos)
      VALUES ($sqlValoresLlaves,$sqlValoresCampos)";

   $statement = $conexion->prepare($sql);
   foreach ($objetos as $objeto) {
    $this->ejecutaStatement($statement, $objeto);
   }
   return [];
  }
 }

 /**
  * @param array[] $objetos
  */
 public function update(PDO $conexion, array $objetos)
 {

  $sqlCampos =
   implode(",", $this->convierteCamposEnAsignaciones($this->nombresDeCampos));
  $sqlLlaves = implode(
   " AND ",
   $this->convierteCamposEnAsignaciones($this->nombresDeLlaves)
  );
  $sql = "UPDATE $this->nombreDeTabla SET $sqlCampos WHERE $sqlLlaves";

  $statement = $conexion->prepare($sql);
  foreach ($objetos as $objeto) {
   $this->ejecutaStatement($statement, $objeto);
  }
 }

 /**
  * @param array[] $laves
  */
 public function delete(PDO $conexion, array $llaves)
 {

  $sqlLlaves = implode(
   " AND ",
   $this->convierteCamposEnAsignaciones($this->nombresDeLlaves)
  );
  $sql = "DELETE FROM $this->nombreDeTabla WHERE $sqlLlaves";

  $statement = $conexion->prepare($sql);
  foreach ($llaves as $llave) {
   $this->ejecutaStatement($statement, $llave);
  }
 }

 /**
  * @param array $valor
  */
 public function select(
  PDO $conexion,
  array $lave,
  int $mode = PDO::FETCH_ASSOC,
  $opcional = null
 ) {

  $sqlLlaves = implode(
   " AND ",
   $this->convierteCamposEnAsignaciones($this->nombresDeLlaves)
  );
  $sql = "SELECT * FROM $this->nombreDeTabla WHERE $sqlLlaves";

  $statement = $conexion->prepare($sql);
  $parametros = $this->convierteAsignacionEnParametros($lave);
  return fetch($statement, $parametros, $mode, $opcional);
 }

 /**
  * @param string[] $campos
  */
 private function convierteCamposEnParametros(array $campos)
 {
  $parametros = [];
  foreach ($campos as $campo) {
   $parametros[] = ":$campo";
  }
  return $parametros;
 }

 /**
  * @param string[] $campos
  */
 private function convierteCamposEnAsignaciones(array $campos)
 {
  $parametros = [];
  foreach ($campos as $campo) {
   $parametros[] = "$campo=:$campo";
  }
  return $parametros;
 }

 private function convierteAsignacionEnParametros(array $asignacion)
 {
  $parametros = [];
  foreach ($asignacion as $llave => $valor) {
   $parametros[":$llave"] = $valor;
  }
  return $parametros;
 }

 private function ejecutaStatement(PDOStatement $statement, array $asignacion)
 {
  $statement->execute($this->convierteAsignacionEnParametros($asignacion));
 }
}
