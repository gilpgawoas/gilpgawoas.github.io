<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/devuelveNoContent.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/pasatiempoOrm.php";

try {
 $id = recuperaIdEntero("id");
 $pasatiempoOrm->delete(Bd::getConexion(), [[PAS_ID => $id]]);
 devuelveNoContent();
} catch (ProblemDetails $details) {
 devuelveProblemDetails($details);
} catch (Throwable $error) {
 devuelveErrorInterno($error);
}
