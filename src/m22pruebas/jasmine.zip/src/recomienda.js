/**
 * @param {string} genero
 */
export function recomienda(genero) {
 if (genero === "pop") {
  return "Dua Lipa."
 } else if (genero === "reg") {
  return "Bad Bunny."
 } else {
  return "De eso no conozco."
 }
}