import { recomienda } from '../src/recomienda.js'

describe("recomienda", () => {
 it("pop", () => expect(recomienda("pop")).toBe("Dua Lipa."))
 it("reg", () => expect(recomienda("reg")).toBe("Bad Bunny."))
 it("reg2", () => expect(recomienda("reg")).toBe("Daddy Yankee."))
})