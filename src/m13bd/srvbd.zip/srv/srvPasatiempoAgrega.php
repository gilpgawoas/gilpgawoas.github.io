<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";
require_once __DIR__ . "/modelo/Pasatiempo.php";
require_once __DIR__ . "/dao/pasatiempoAgrega.php";

ejecuta(function () {
 $nombre = trim(leeTexto("nombre"));
 $modelo = new Pasatiempo(nombre: $nombre);
 pasatiempoAgrega($modelo);
 return $modelo;
});
