<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "lib/php/leeEntero.php";
require_once
 "srv/dao/pasatiempoBusca.php";
require_once "srv/txt/"
 . "txtPasatiempoNoEncontrado.php";

use \lib\php\Servicio;

class SrvPasatiempoBusca
extends Servicio
{

 protected
 function implementacion()
 {
  $id = leeEntero("id");
  $modelo = pasatiempoBusca($id);
  if ($modelo === false) {
   throw new Exception(
    txtPasatiempoNoEncontrado()
   );
  } else {
   return $modelo;
  }
 }
}

$servicio =
 new SrvPasatiempoBusca();
$servicio->ejecuta();
