<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once "lib/php/"
 . "leeSinEspaciosInFin.php";
require_once
 "srv/dao/pasatiempoAgrega.php";

use \lib\php\Servicio;
use \srv\modelo\Pasatiempo;

class SrvPasatiempoAgrega
extends Servicio
{

 protected
 function implementacion()
 {
  $modelo = new Pasatiempo();
  $modelo->nombre =
   leeSinEspaciosInFin("nombre");
  pasatiempoAgrega($modelo);
  return $modelo;
 }
}

$servicio =
 new SrvPasatiempoAgrega();
$servicio->ejecuta();
