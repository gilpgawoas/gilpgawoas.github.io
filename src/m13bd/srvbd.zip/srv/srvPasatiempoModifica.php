<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";
require_once __DIR__ . "/modelo/Pasatiempo.php";
require_once __DIR__ . "/dao/pasatiempoModifica.php";

ejecuta(function () {
 $id = leeEntero("id");
 if ($id === null)
  throw new Exception("Falta el id.");
 $nombre = trim(leeTexto("nombre"));
 $modelo = new Pasatiempo(nombre: $nombre, id: $id);
 pasatiempoModifica($modelo);
 return $modelo;
});
