<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/dao/pasatiempoConsulta.php";

ejecuta(function () {
 $lista = pasatiempoConsulta();
 $render = "";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo->id);
  $nombre = htmlentities($modelo->nombre);
  $render .=
   "<li>
     <p>
      <a href='modifica.html?id=$id'>{$nombre}</a>
     </p>
    </li>";
 }
 return $render;
});
