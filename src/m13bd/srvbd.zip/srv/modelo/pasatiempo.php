<?php

namespace srv\modelo;

require_once
 "lib/php/validaNombreNoVacio.php";

class Pasatiempo
{

 public int $id;
 public string $nombre;

 public function valida()
 {
  validaNombreNoVacio(
   $this->nombre
  );
 }
}
