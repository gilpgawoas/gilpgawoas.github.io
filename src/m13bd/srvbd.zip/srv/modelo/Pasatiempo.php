<?php

class Pasatiempo
{

 public int $id;
 public string $nombre;

 public function __construct(string $nombre = "", int $id = 0)
 {
  $this->id = $id;
  $this->nombre = $nombre;
 }

 public function valida()
 {
  if ($this->nombre === "")
   throw new Exception("Faltala el nombre.");
 }
}
