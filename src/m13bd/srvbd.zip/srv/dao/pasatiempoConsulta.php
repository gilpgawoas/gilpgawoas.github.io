<?php

require_once
 "lib/php/recibeFetchAll.php";

use srv\dao\AccesoBd;
use srv\modelo\Pasatiempo;

/** @return Pasatiempo[] */
function pasatiempoConsulta()
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
    PAS_ID AS id,
    PAS_NOMBRE AS nombre
   FROM PASATIEMPO
   ORDER BY PAS_NOMBRE"
 );
 $resultado = $stmt->fetchAll(
  PDO::FETCH_CLASS,
  Pasatiempo::class
 );
 return recibeFetchAll($resultado);
}
