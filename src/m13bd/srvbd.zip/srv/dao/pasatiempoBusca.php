<?php

require_once __DIR__ . "/../modelo/Pasatiempo.php";
require_once __DIR__ . "/AccesoBd.php";

function pasatiempoBusca(int $id): false|Pasatiempo
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    PAS_ID AS id,
    PAS_NOMBRE AS nombre
   FROM PASATIEMPO
   WHERE PAS_ID = :id"
 );
 $stmt->execute([":id" => $id]);
 $stmt->setFetchMode(
  PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
  Pasatiempo::class
 );
 return $stmt->fetch();
}
