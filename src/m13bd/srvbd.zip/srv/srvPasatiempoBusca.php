<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/modelo/Pasatiempo.php";
require_once __DIR__ . "/dao/pasatiempoBusca.php";

ejecuta(function () {
 $id = leeEntero("id");
 if ($id === null)
  throw new Exception("Falta el parámetro id.");
 $modelo = pasatiempoBusca($id);
 if ($modelo === false) {
  throw new Exception("Pasatiempo no encontrado.");
 } else {
  return $modelo;
 }
});
