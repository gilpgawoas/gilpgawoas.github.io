<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "srv/dao/pasatiempoConsulta.php";

use \lib\php\Servicio;

class SrvPasatiempoConsulta
extends Servicio
{

 protected
 function implementacion()
 {
  $lista = pasatiempoConsulta();
  $render = "";
  foreach ($lista as $modelo) {
   $id = htmlentities($modelo->id);
   $nombre =
    htmlentities($modelo->nombre);
   $render .=
    "<li>
      <p>
    <a href='modifica.html?id=$id'>
     {$nombre}</a>
      </p>
     </li>";
  }
  return $render;
 }
}

$servicio =
 new SrvPasatiempoConsulta();
$servicio->ejecuta();
