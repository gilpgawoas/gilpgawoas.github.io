<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";

ejecuta(function () {
 return [
  "nombre" => "pp",
  "apellido" => "tkt",
  "edad" => 18,
  "numero" => 5,
  "aprobado" => true,
  "gracioso" => false,
  "emplacado" => false,
  "direccion" => "Girasoles 23\ncolonia Rosales",
  "encabezado" => "<em>Hola, soy <strong>pp</strong>",
  "imagen1" => "https://gilpgawoas.github.io/img/icono/maskable_icon_x48.png",
  "imagen2" => "",
  "pasatiempos[]" => ["fut", "basket"],
  "madrugador" => ["no"],
  "nacimiento" => "2000-07-04"
 ];
});
