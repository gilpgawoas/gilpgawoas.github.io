import "../../lib/js/custom/indicador-cargando.js"

export class CampoRoles
 extends HTMLElement {

 connectedCallback() {
  this.style.display = "block"
  this.innerHTML = /* HTML */
   `<fieldset>
     <legend>Roles</legend>
     <div id="roles">
      <indicador-cargando>
      </indicador-cargando>
     </div>
    </fieldset>`

 }
}

customElements.define(
 "campo-roles", CampoRoles)