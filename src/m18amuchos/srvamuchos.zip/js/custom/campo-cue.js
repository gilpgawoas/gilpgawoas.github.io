export class CampoCue
 extends HTMLElement {

 connectedCallback() {
  this.style.display = "block"
  this.innerHTML = /* HTML */
   `<p>
     <label>
      <!-- Usamos cue para que los
      navegadores no bloqueen la
      página. -->
      Cue *
      <input name="cue" required>
     </label>
    </p>`
 }
}

customElements.define("campo-cue",
 CampoCue)