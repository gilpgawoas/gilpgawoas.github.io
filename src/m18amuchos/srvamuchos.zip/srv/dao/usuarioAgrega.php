<?php

require_once
 "srv/dao/usuRolAgrega.php";

use srv\dao\AccesoBd;
use srv\modelo\Usuario;

function usuarioAgrega(
 Usuario $modelo
) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 $stmt = $con->prepare(
  "INSERT INTO USUARIO
    (USU_CUE)
   VALUES
    (:cue)"
 );
 $stmt->execute([
  ":cue" => $modelo->cue
 ]);
 /* Si usas una secuencia para
  * generar el id, pasa como
  * parámetro de lastInsertId el
  * nombre de dicha secuencia. */
 $modelo->id =
  $con->lastInsertId();
 usuRolAgrega($modelo);
 $con->commit();
}
