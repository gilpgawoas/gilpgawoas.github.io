<?php

namespace srv\modelo;

require_once "lib/php/valida.php";
require_once
 "lib/php/validaIdNoVacio.php";
require_once
 "lib/php/validaTextoNoVacio.php";
require_once
 "srv/txt/txtFaltaElCue.php";
require_once
 "srv/txt/txtNoEsUnRol.php";

 use srv\modelo\Rol;

class Usuario
{

 public int $id;
 public string $cue;
 /** @var Rol[] */
 public array $roles;

 function valida()
 {
  $this->validaCueNoVacio();
  $this->validaRoles();
 }

 function validaCueNoVacio()
 {
  validaTextoNoVacio(
   $this->cue,
   txtFaltaElCue()
  );
 }

 function validaRoles()
 {
  foreach ($this->roles as $rol) {
   valida(
    $rol instanceof Rol,
    txtNoEsUnRol()
   );
   validaIdNoVacio($rol->id);
  }
 }
}
