<?php

function txtUsuarioNoEncontrado()
{
 return "Usuario no encontrado.";
}
