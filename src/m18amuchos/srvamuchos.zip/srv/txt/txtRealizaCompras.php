<?php

function txtRealizaCompras()
{
 return "Realiza compras.";
}
