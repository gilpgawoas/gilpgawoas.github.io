<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";

ejecuta(function () {
 return [
  "nombre" => "pp",
  "mensaje" => "Hola."
 ];
});
