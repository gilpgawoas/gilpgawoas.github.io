<?php

require_once
 "lib/php/leeForanea.php";

use srv\modelo\Pasatiempo;

function leePasatiempo()
{
 $pasId = leeForanea("pasId");
 if ($pasId === null) {
  return null;
 } else {
  $pasatiempo = new Pasatiempo();
  $pasatiempo->id = $pasId;
  return $pasatiempo;
 }
}
