<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "srv/dao/pasatiempoConsulta.php";
require_once
 "srv/txt/txtSinPasatiempo.php";

use \lib\php\Servicio;

class SrvPasatiempoOpciones
extends Servicio
{

 protected
 function implementacion()
 {
  $lista = pasatiempoConsulta();
  $txtSinPasatiempo = htmlentities(
   txtSinPasatiempo()
  );
  $render =
   "<option value=''>
     $txtSinPasatiempo
    </option>";
  foreach ($lista as $modelo) {
   $id = htmlentities($modelo->id);
   $nombre =
    htmlentities($modelo->nombre);
   $render .=
    "<option value='$id'>
      {$nombre}
     </option>";
  }
  return $render;
 }
}

$servicio =
 new SrvPasatiempoOpciones();
$servicio->ejecuta();
