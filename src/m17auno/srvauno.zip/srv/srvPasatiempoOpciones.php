<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/dao/pasatiempoConsulta.php";

ejecuta(function () {
 $lista = pasatiempoConsulta();
 $render = "<option value=''>-- Sin pasatiempo --</option>";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo->id);
  $nombre = htmlentities($modelo->nombre);
  $render .= "<option value='$id'>{$nombre}</option>";
 }
 return $render;
});
