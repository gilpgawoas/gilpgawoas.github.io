<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "lib/php/leeEntero.php";
require_once
 "srv/dao/amigoBusca.php";
require_once "srv/txt/"
 . "txtAmigoNoEncontrado.php";

use \lib\php\Servicio;

class SrvAmigoBusca
extends Servicio
{

 protected
 function implementacion()
 {
  $id = leeEntero("id");
  $modelo = amigoBusca($id);
  if ($modelo === false) {
   throw new Exception(
    txtAmigoNoEncontrado()
   );
  } else {
   return $modelo;
  }
 }
}

$servicio = new SrvAmigoBusca();
$servicio->ejecuta();
