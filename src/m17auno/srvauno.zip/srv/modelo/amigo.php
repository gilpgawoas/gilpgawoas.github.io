<?php

namespace srv\modelo;

require_once
 "lib/php/validaNombreNoVacio.php";

class Amigo
{

 public int $id;
 public string $nombre;
 public ?Pasatiempo $pasatiempo;

 public function valida()
 {
  validaNombreNoVacio(
   $this->nombre
  );
 }
}
