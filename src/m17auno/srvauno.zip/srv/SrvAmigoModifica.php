<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "lib/php/leeEntero.php";
require_once "lib/php/" .
 "leeSinEspaciosInFin.php";
require_once
 "srv/leePasatiempo.php";
require_once
 "srv/dao/amigoModifica.php";

use \lib\php\Servicio;
use \srv\modelo\Amigo;

class SrvAmigoModifica
extends Servicio
{

 protected
 function implementacion()
 {
  $modelo = new Amigo();
  $modelo->id = leeEntero("id");
  $modelo->nombre =
   leeSinEspaciosInFin("nombre");
  $modelo->pasatiempo =
   leePasatiempo();
  amigoModifica($modelo);
  return $modelo;
 }
}

$servicio = new SrvAmigoModifica();
$servicio->ejecuta();
