<?php

use srv\dao\AccesoBd;

function amigoElimina(int $id)
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "DELETE FROM AMIGO
   WHERE
    AMI_ID = :id"
 );
 $stmt->execute([":id" => $id]);
}
