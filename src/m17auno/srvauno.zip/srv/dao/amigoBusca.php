<?php

use srv\dao\AccesoBd;
use srv\modelo\Amigo;
use srv\modelo\Pasatiempo;

function amigoBusca(int $amiId)
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    A.AMI_ID AS amiId,
    A.AMI_NOMBRE AS amiNombre,
    A.PAS_ID AS pasId,
    P.PAS_NOMBRE AS pasNombre
   FROM AMIGO A
    LEFT JOIN PASATIEMPO P
    ON A.PAS_ID = P.PAS_ID
   WHERE A.AMI_ID = :amiId"
 );
 $stmt->execute([
  ":amiId" => $amiId
 ]);
 $stmt->setFetchMode(
  PDO::FETCH_OBJ
 );
 $obj = $stmt->fetch();
 if ($obj === false) {
  return false;
 } else {
  $amigo = new Amigo();
  $amigo->id = $obj->amiId;
  $amigo->nombre = $obj->amiNombre;
  if ($obj->pasId === null) {
   $amigo->pasatiempo = null;
  } else {
   $pasatiempo = new Pasatiempo();
   $pasatiempo->id = $obj->pasId;
   $pasatiempo->nombre =
    $obj->pasNombre;
   $amigo->pasatiempo =
    $pasatiempo;
  }
  return $amigo;
 }
}
