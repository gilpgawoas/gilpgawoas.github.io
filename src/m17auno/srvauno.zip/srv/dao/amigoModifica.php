<?php

require_once __DIR__ . "/../modelo/Amigo.php";
require_once __DIR__ . "/AccesoBd.php";

function amigoModifica(Amigo $modelo)
{
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "UPDATE AMIGO
   SET
    AMI_NOMBRE = :nombre,
    PAS_ID = :pasId
   WHERE AMI_ID = :id"
 );
 $stmt->execute([
  ":id" => $modelo->id,
  ":nombre" => $modelo->nombre,
  ":pasId" => $modelo->pasatiempo === null
   ? null
   : $modelo->pasatiempo->id
 ]);
}
