<?php

require_once __DIR__ . "/../modelo/Pasatiempo.php";
require_once __DIR__ . "/bdCrea.php";
require_once __DIR__ . "/pasatiempoConsulta.php";
require_once __DIR__ . "/pasatiempoAgrega.php";

class AccesoBd
{

 private static ?PDO $con = null;

 static function getCon(): PDO
 {
  if (self::$con === null) {
   self::$con = self::conecta();
   self::prepara(self::$con);
  }
  return self::$con;
 }

 private static function conecta(): PDO
 {
  return new PDO(
   // cadena de conexión
   "sqlite:srvauno.db",
   // usuario
   null,
   // contraseña
   null,
   [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
  );
 }

 private static function prepara(PDO $con)
 {
  bdCrea($con);
  $pasatiempo = pasatiempoConsulta();
  if (sizeof($pasatiempo) === 0) {

   $pasatiempo = new Pasatiempo(nombre: "Futbol");
   pasatiempoAgrega($pasatiempo);

   $pasatiempo = new Pasatiempo(nombre: "Videojuegos");
   pasatiempoAgrega($pasatiempo);
  }
 }
}
