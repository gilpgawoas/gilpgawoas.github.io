<?php

namespace srv\dao;

require_once "srv/dao/bdCrea.php";
require_once
 "srv/dao/pasatiempoConsulta.php";
require_once
 "srv/dao/pasatiempoAgrega.php";
require_once
 "srv/txt/txtFutbol.php";
require_once
 "srv/txt/txtVideojuegos.php";

use \PDO;
use srv\modelo\Pasatiempo;

class AccesoBd
{

 private static ?PDO $con = null;

 static function getCon(): PDO
 {
  if (self::$con === null) {
   self::$con = self::conecta();
   self::prepara(self::$con);
  }
  return self::$con;
 }

 private static
 function conecta(): PDO
 {
  return new PDO(
   // cadena de conexión
   "sqlite:srvauno.db",
   // usuario
   null,
   // contraseña
   null,
   [PDO::ATTR_ERRMODE
   => PDO::ERRMODE_EXCEPTION]
  );
 }

 private static
 function prepara(PDO $con)
 {
  bdCrea($con);
  $pasatiempo =
   pasatiempoConsulta();
  if (sizeof($pasatiempo) === 0) {

   $pasatiempo = new Pasatiempo();
   $pasatiempo->nombre =
    txtFutbol();
   pasatiempoAgrega($pasatiempo);

   $pasatiempo = new Pasatiempo();
   $pasatiempo->nombre =
    txtVideojuegos();
   pasatiempoAgrega($pasatiempo);
  }
 }
}
