<?php

require_once __DIR__ . "/../../lib/php/recibeFetchAll.php";
require_once __DIR__ . "/../modelo/Pasatiempo.php";
require_once __DIR__ . "/AccesoBd.php";

/** @return Pasatiempo[] */
function pasatiempoConsulta()
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
    PAS_ID AS id,
    PAS_NOMBRE AS nombre
   FROM PASATIEMPO
   ORDER BY PAS_NOMBRE"
 );
 $resultado = $stmt->fetchAll(
  PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE,
  Pasatiempo::class
 );
 return recibeFetchAll($resultado);
}
