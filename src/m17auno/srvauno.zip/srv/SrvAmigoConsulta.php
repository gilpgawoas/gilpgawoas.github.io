<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "srv/dao/amigoConsulta.php";
require_once "srv/txt/"
 . "txtSinPasatiempo.php";

use \lib\php\Servicio;

class SrvAmigoConsulta
extends Servicio
{
 protected
 function implementacion()
 {
  $lista = amigoConsulta();
  $txtSinPasatiempo =
   txtSinPasatiempo();
  $render = "";
  foreach ($lista as $modelo) {
   $amiId =
    htmlentities($modelo->amiId);
   $amiNombre = htmlentities(
    $modelo->amiNombre
   );
   $pasNombre =
    $modelo->pasNombre === null
    ? "<em>$txtSinPasatiempo</em>"
    : htmlentities(
     $modelo->pasNombre
    );
   $render .=
    "<li>
      <p>
 <a href='modifica.html?id=$amiId'>
  <strong>{$amiNombre}</strong>
  <br>{$pasNombre}</a>
      </p>
     </li>";
  }
  return $render;
 }
}

$servicio = new SrvAmigoConsulta();
$servicio->ejecuta();
