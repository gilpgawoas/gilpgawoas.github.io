<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "lib/php/leeEntero.php";
require_once
 "srv/dao/amigoElimina.php";

use \lib\php\Servicio;

class SrvAmigoElimina
extends Servicio
{

 protected
 function implementacion()
 {
  $id = leeEntero("id");
  amigoElimina($id);
  return [];
 }
}

$servicio = new SrvAmigoElimina();
$servicio->ejecuta();
