<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";
require_once __DIR__ . "/modelo/Amigo.php";
require_once __DIR__ . "/modelo/Pasatiempo.php";
require_once __DIR__ . "/dao/amigoAgrega.php";

ejecuta(function () {
 $nombre = trim(leeTexto("nombre"));
 $pasId = leeEntero("pasId");
 $pasatiempo = $pasId === null
  ? null
  : new Pasatiempo(id: $pasId);
 $modelo = new Amigo(nombre: $nombre, pasatiempo: $pasatiempo);
 amigoAgrega($modelo);
 return $modelo;
});
