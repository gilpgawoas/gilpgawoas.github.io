<?php

function txtSinPasatiempo()
{
 return "-- Sin pasatiempo --";
}
