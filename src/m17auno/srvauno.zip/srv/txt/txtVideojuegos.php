<?php

function txtVideojuegos()
{
 return "Videojuegos";
}
