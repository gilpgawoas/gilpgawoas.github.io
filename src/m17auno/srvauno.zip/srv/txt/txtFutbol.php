<?php

function txtFutbol()
{
 return "Futbol";
}
