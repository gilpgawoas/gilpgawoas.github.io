<?php

function txtAmigoNoEncontrado()
{
 return "Amigo no encontrada.";
}
