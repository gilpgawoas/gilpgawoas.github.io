<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "lib/php/leeEntero.php";
require_once "lib/php/" .
 "leeSinEspaciosInFin.php";
require_once
 "srv/leePasatiempo.php";
require_once
 "srv/dao/amigoAgrega.php";

use lib\php\Servicio;
use srv\modelo\Amigo;

class SrvAmigoAgrega
extends Servicio
{

 protected
 function implementacion()
 {
  $modelo = new Amigo();
  $modelo->nombre =
   leeSinEspaciosInFin("nombre");
  $modelo->pasatiempo =
   leePasatiempo();
  amigoAgrega($modelo);
  return $modelo;
 }
}

$servicio = new SrvAmigoAgrega();
$servicio->ejecuta();
