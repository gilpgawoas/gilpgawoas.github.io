import {
 ejecuta
} from "../lib/js/ejecuta.js"

export async function
 descargaPasatiempoOpciones() {
 return await ejecuta(fetch("srv/"
  + "SrvPasatiempoOpciones.php"))
}