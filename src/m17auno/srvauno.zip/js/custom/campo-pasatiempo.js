export class CampoPasatiempo
 extends HTMLElement {

 connectedCallback() {
  this.style.display = "block"
  this.innerHTML = /* HTML */
   `<p>
     <label>
      Pasatiempo
      <select name="pasId">
       <option value="">
        Cargando…
       </option>
      </select>
     </label>
    </p>`
 }

}

customElements.define(
 "campo-pasatiempo",
 CampoPasatiempo)