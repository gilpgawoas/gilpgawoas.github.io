<?php

require_once
 "lib/php/leeTexto.php";

/**
 * Recupera el texto de un
 * parámetro correspindiente a una
 * llave foránea numérica enviada
 * al servidor por medio de GET,
 * POST o cookie.
 */
function leeForanea(
 string $parametro
): ?string {
 /* Si el parámetro no está
  * asignado o es un texto vacío,
  * devuelve null; de lo contrario,
  * devuelve el valor recibido. */
 $valor = leeTexto($parametro);
 return $valor === ""
  ? null
  : $valor;
}
