/* Ejemplo de render en el cliente
 * no se usa import porque Firefox
 * no lo soporta en los webworkers.
 */

/**
 * @typedef {Object} Elemento
 * @property {string} nombre
 */

 render([
  { nombre: "Pepe" },
  { nombre: "Cuca" },
  { nombre: "Teté" }])
 setTimeout(lista, 5000)
 
 async function lista() {
  const json = await ejecuta(
   fetch("srv/SrvLista.php"))
  render(json.lista)
 }
 
 /** @param {Elemento[]} lista */
 function render(lista) {
  let ren = ""
  for (const modelo of lista) {
   ren += /* html */
    `<li>
      <p>
       ${cod(modelo.nombre)}
      </p>
     </li>`
  }
  if (self
   instanceof WorkerGlobalScope) {
   self.postMessage(ren)
  }
 }
 
 /**
  * @param {Promise<Response>
  *         } fetch
  * @returns {Promise<any>}
  */
 async function ejecuta(fetch) {
  const resp = await fetch
  if (resp.ok) {
   return await resp.json()
  } else if (
   resp.status === 500) {
   throw new Error(
    await resp.text())
  } else {
   throw new Error(resp.statusText)
  }
 }
 
 /**
  * Codifica un texto para que
  * escape los caracteres
  * especiales y no se pueda
  * interpretar como HTML. Esta
  * técnica evita la inyección de
  * código.
  * @param {string} texto
  * @returns {string} un texto que
  *  no puede interpretarse como
  *  HTML.
  */
 function cod(texto) {
  return texto.toString().
   replace(/[<>"']/g, reemplaza)
 }
 
 /** @param {string} letra */
 function reemplaza(letra) {
  switch (letra) {
   case "<": return "&lt;"
   case ">": return "&gt;"
   case '"': return "&quot;"
   case "'": return "&#039;"
   default: return letra
  }
 }