/* Ejemplo de render en el cliente. No se usa import
 * porque Firefox no lo soporta en los web workers. */

ejecuta("srv/srvLista.php")
 .then(lista => {
  // Genera el código HTML de la lista.
  let render = ""
  for (const modelo of lista) {
   /* Codifica nombre y color para que cambie los
    * caracteres especiales y el texto no se pueda
    * interpretar como HTML. Esta técnica evita la
    * inyección de código. */
   const nombre = htmlentities(modelo.nombre)
   const color = htmlentities(modelo.color)
   render += /* html */
    `<dt>${nombre}</dt>
     <dd>${color}</dd>`
  }

  // Verifica si el código corre dentro de un web worker.
  if (self instanceof WorkerGlobalScope) {
   // Envía el render a la página que invocó este web worker.
   self.postMessage(render)
  }
 })
 .catch(error => console.log(error))

/**
 * Espera a que la promesa de un fetch termine. Si
 * hay error, lanza una excepción. Si no hay error,
 * interpreta la respuesta del servidor como JSON y
 * la convierte en una literal de objeto. 
 * @param { string | Promise<Response> } servicio
 */
export async function ejecuta(servicio) {
 let f = servicio
 if (typeof servicio === "string") {
  f = fetch(servicio)
 } else if (!(f instanceof Promise)) {
  throw new Error("Servicio de tipo incorrecto.")
 }
 const respuesta = await f
 if (respuesta.ok) {
  const texto = await respuesta.text()
  try {
   return JSON.parse(texto)
  } catch (error) {
   throw new Error(texto)
  }
 } else if (respuesta.status === 500) {
  throw new Error(await respuesta.text())
 } else {
  throw new Error(respuesta.statusText)
 }
}

/**
 * Codifica un texto para que cambie los caracteres
 * especiales y no se pueda interpretar como
 * etiiqueta HTML. Esta técnica evita la inyección
 * de código.
 * @param { string } texto
 * @returns { string } un texto que no puede
 *  interpretarse como HTML. */
export function htmlentities(texto) {
 return texto.replace(/[<>"']/g, textoDetectado => {
  switch (textoDetectado) {
   case "<": return "&lt;"
   case ">": return "&gt;"
   case '"': return "&quot;"
   case "'": return "&#039;"
   default: return textoDetectado
  }
 })
}