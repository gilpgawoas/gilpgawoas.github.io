<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";

ejecuta(function () {
 $lista = [
  [
   "nombre" => "pp",
   "color" => "azul"
  ],
  [
   "nombre" => "kq",
   "color" => "rojo"
  ],
  [
   "nombre" => "tt",
   "color" => "rosa"
  ],
  [
   "nombre" => "bb",
   "color" => "azul"
  ]
 ];
 return $lista;
});
