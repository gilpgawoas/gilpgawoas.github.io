<?php

require_once __DIR__ . "/BAD_REQUEST.php";
require_once __DIR__ . "/recibeBytes.php";
require_once __DIR__ . "/ProblemDetailsException.php";

function recibeBytesObligatorios(string $parametro)
{
 $bytes = recibeBytes($parametro);

 if ($bytes === false)
  throw new ProblemDetailsException([
   "status" => BAD_REQUEST,
   "title" => "Falta el valor $parametro.",
   "type" => "/errors/faltavalor.html",
   "detail" => "La solicitud no tiene el valor de $parametro."
  ]);

 if ($bytes === "")
  throw new ProblemDetailsException([
   "status" => BAD_REQUEST,
   "title" => "Archivo no seleccionado o vacío para el campo $parametro.",
   "type" => "/errors/archivovacio.html",
   "detail" => "Selecciona un archivo que no esté vacío en el campo $parametro."
  ]);

 return $bytes;
}
