<?php

require_once __DIR__ . "/recibeBytes.php";

function recibeBytesOpcionales(string $parametro)
{
 $enteroOpcional = recibeBytes($parametro);
 return $enteroOpcional === false ? "" : $enteroOpcional;
}
