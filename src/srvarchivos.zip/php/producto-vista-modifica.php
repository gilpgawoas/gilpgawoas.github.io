<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";

$prodId = recibeEnteroObligatorio("id");

$bd = Bd::pdo();
$modelo = productoBusca($bd, $prodId);

$modelo = validaEntidadObligatoria("Producto",  $modelo);

$encodeArchId =
 $modelo["ARCH_ID"] === null ? "" : urlencode($modelo["ARCH_ID"]);
$htmlEncodeArchId = htmlentities($encodeArchId);
// Los bytes de las imágenes se descargan con "archivo.php"; no desde aquí.
devuelveJson([
 "id" => ["value" => $prodId],
 "nombre" => ["value" => $modelo["PROD_NOMBRE"]],
 "imagen" => [
  "data-src" => $htmlEncodeArchId === ""
   ? ""
   : "php/archivo.php?id=$htmlEncodeArchId"
 ]
]);
