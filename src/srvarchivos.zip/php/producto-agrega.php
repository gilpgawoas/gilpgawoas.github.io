<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeTextoObligatorio.php";
require_once __DIR__ . "/lib/recibeBytesObligatorios.php";
require_once __DIR__ . "/lib/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/archivoAgrega.php";

$nombre = recibeTextoObligatorio("nombre");
$bytes = recibeBytesObligatorios("imagen");

$bd = Bd::pdo();
$bd->beginTransaction();

$archId = archivoAgrega($bd, $bytes);

$stmt = $bd->prepare(
 "INSERT INTO PRODUCTO (
    PROD_NOMBRE, ARCH_ID
   ) values (
    :PROD_NOMBRE, :ARCH_ID
   )"
);
$stmt->execute([
 ":PROD_NOMBRE" => $nombre,
 ":ARCH_ID" => $archId
]);
$prodId = $bd->lastInsertId();

$bd->commit();

$encodeId = urlencode($prodId);
$encodeArchId = urlencode($archId);
$htmlEncodeArchId = htmlentities($encodeArchId);
// Los bytes de las imágenes se descargan con "archivo.php"; no desde aquí.
devuelveCreated("/php/producto-vista-modifica.php?id=$encodeId", [
 "id" => ["value" => $prodId],
 "nombre" => ["value" => $nombre],
 "imagen" => [
  "imagen" => [
   "data-src" => $htmlEncodeArchId === ""
    ? ""
    : "php/archivo.php?id=$htmlEncodeArchId"
  ]
 ]
]);
