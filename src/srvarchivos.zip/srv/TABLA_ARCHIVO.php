<?php

const ARCHIVO = "ARCHIVO";
const ARCH_ID = "ARCH_ID";
const ARCH_BYTES = "ARCH_BYTES";
