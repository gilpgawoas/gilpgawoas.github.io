<?php

const PRODUCTO = "PRODUCTO";
const PROD_ID = "PROD_ID";
const PROD_NOMBRE = "PROD_NOMBRE";
