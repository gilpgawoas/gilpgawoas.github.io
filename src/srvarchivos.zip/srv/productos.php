<?php

require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/select.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

ejecutaServicio(function () {

 $lista = select(pdo: Bd::pdo(), from: PRODUCTO, orderBy: PROD_NOMBRE);

 $render = "";
 foreach ($lista as $modelo) {
  $prodId = htmlentities($modelo[PROD_ID]);
  $prodNombre = htmlentities($modelo[PROD_NOMBRE]);
  $encodeArchId = $modelo[ARCH_ID] === null ? "" : urlencode($modelo[ARCH_ID]);
  $archId = $encodeArchId === "" ? "" : htmlentities($encodeArchId);
  $src = $archId === "" ? "" : "srv/archivo.php?id=$archId";
  $render .=
   "<div style='display: flex; flex-direction: row-reverse;
      align-items: center; gap: 0.5rem'>
     <dt style='flex: 1 1 0'>
      <a href='modifica.html?id=$prodId'>$prodNombre</a>
     </dt>
     <dd style='flex: 1 1 0; margin: 0'>
      <a href='modifica.html?id=$prodId'><img
        style='width: 100%; aspect-ratio:16/9; object-fit: cover'
        alt='Imagen del producto' src='$src'></a>
     </dd>
    </div>";
 }

 devuelveJson(["lista" => ["innerHTML" => $render]]);
});
