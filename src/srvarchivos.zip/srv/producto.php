<?php

require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/selectFirst.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

ejecutaServicio(function () {

 $prodId = recuperaIdEntero("id");

 $modelo =
  selectFirst(pdo: Bd::pdo(), from: PRODUCTO, where: [PROD_ID => $prodId]);

 if ($modelo === false) {
  $prodIdHtml = htmlentities($prodId);
  throw new ProblemDetails(
   status: NOT_FOUND,
   title: "Producto no encontrado.",
   type: "/error/productonoencontrado.html",
   detail: "No se encontró ningún producto con el id $prodIdHtml.",
  );
 }

 $encodeArchId = $modelo[ARCH_ID] === null ? "" : urlencode($modelo[ARCH_ID]);
 $htmlEncodeArchId = htmlentities($encodeArchId);
 devuelveJson([
  "id" => ["value" => $prodId],
  "nombre" => ["value" => $modelo[PROD_NOMBRE]],
  "imagen" => [
   "data-file" => $htmlEncodeArchId === ""
    ? ""
    : "srv/archivo.php?id=$htmlEncodeArchId"
  ]
 ]);
});
