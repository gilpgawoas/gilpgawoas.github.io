<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once  __DIR__ . "/../lib/php/leeJson.php";

ejecuta(function () {
 $json = leeJson();
 $saludo = $json->saludo;
 $nombre = $json->nombre;
 $resultado =
  "{$saludo} {$nombre}.";
 return $resultado;
});
