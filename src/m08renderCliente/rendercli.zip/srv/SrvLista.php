<?php
require_once __DIR__ .
 "/../lib/php/Servicio.php";

class SrvLista extends Servicio
{
 protected
 function implementacion()
 {
  $lista = [
   ["nombre" => "pp"],
   ["nombre" => "kq"],
   ["nombre" => "tt"],
   ["nombre" => "bb"]
  ];
  return ["lista" => $lista];
 }
}

$servicio = new SrvLista();
$servicio->ejecuta();
