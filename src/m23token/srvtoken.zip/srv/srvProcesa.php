<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";

ejecuta(function () {

 session_start();

 $token = leeTexto("token");
 $hallado = false;

 if (!isset($_SESSION["formulario"]))
  throw new Exception("Formulario no registrado.");

 $tokensParaFormulario = $_SESSION["formulario"];

 if (!is_array($tokensParaFormulario))
  throw new Exception("No hay arereglo de tokens.");

 // Valida que el token se haya registrado.
 foreach ($tokensParaFormulario as $llave => $tokenParaFormulario) {

  if (strcmp($token, $tokenParaFormulario["texto"]) === 0) {

   if ($tokenParaFormulario["expiracion"] < time()) {
    unset($tokensParaFormulario[$llave]);
    $_SESSION["formulario"] = $tokensParaFormulario;
    throw new Exception("Te tardaste mucho.");
   }

   $hallado = true;
  } elseif ($tokenParaFormulario["expiracion"] > time()) {

   // Elimina tokens expirados
   unset($tokensParaFormulario[$llave]);
  }
 }

 $_SESSION["formulario"] = $tokensParaFormulario;

 if ($hallado === false)
  throw new Exception("No autorizado");

 // Si el token se halló, precesa normalmente la forma.
 $saludo = leeTexto("saludo");
 $nombre = leeTexto("nombre");
 if ($saludo === "") {
  throw new Exception("Falta el saludo");
 }
 if ($nombre === "") {
  throw new Exception("Falta el nombre");
 }
 $resultado =
  "{$saludo} {$nombre}.";
 return $resultado;
});
