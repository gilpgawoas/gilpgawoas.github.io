<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";

ejecuta(function () {

 session_start();

 $criptografiaFuerte = true;
 // Crea el token
 $token = [
  // El token expira en 5 minutos.
  "expiracion" => time() + 60 * 5,
  // El token es de 80 caracteres, criptográficamente fuerte.
  "texto" => bin2hex(openssl_random_pseudo_bytes(80, $criptografiaFuerte))
 ];

 // Verifica que ya haya tokens para la pagina "formulario".
 if (isset($_SESSION["formulario"])) {

  $tokensParaFormulario = $_SESSION["formulario"];

  // Como ya exite el arreglo, elimina los tokens expirados para esta pagina.
  foreach ($tokensParaFormulario as $llave => $tokenParaFormulario) {
   if ($tokenParaFormulario["expiracion"] > time()) {
    unset($tokensParaFormulario[$llave]);
   }
  }

  // Se puede usar uno o varios tokens por forma.
  $tokensParaFormulario[] = $token;
  $_SESSION["formulario"] = $tokensParaFormulario;
 } else {

  // Se puede usar uno o varios tokens por forma 
  $_SESSION["formulario"] = [$token];
 }

 return $token["texto"];
});
