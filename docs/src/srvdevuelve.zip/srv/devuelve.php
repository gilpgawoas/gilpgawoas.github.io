<?php

require_once __DIR__ . "/../lib/php/devuelveJson.php";

devuelveJson([
 "nombre" => "pp",
 "mensaje" => "Hola."
]);
