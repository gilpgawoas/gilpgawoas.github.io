<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "lib/php/leeJson.php";

use \lib\php\Servicio;

class SrvJson extends Servicio
{
 protected
 function implementacion()
 {
  $json = leeJson();
  $saludo = $json->saludo;
  $nombre = $json->nombre;
  $resultado =
   "{$saludo} {$nombre}.";
  return $resultado;
 }
}
$servicio = new SrvJson();
$servicio->ejecuta();
