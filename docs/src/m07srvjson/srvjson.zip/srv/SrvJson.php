<?php
require_once __DIR__ .
 "/../lib/php/Servicio.php";
require_once __DIR__ .
 "/../lib/php/leeJson.php";

class SrvJson extends Servicio
{
 protected
 function implementacion()
 {
  $json = leeJson();
  $saludo = $json->saludo;
  $nombre = $json->nombre;
  $resultado =
   "{$saludo} {$nombre}.";
  return [
   "resultado" => $resultado
  ];
 }
}
$servicio = new SrvJson();
$servicio->ejecuta();
