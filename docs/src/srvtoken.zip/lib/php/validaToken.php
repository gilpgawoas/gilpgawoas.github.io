<?php

require_once __DIR__ . "/ProblemDetails.php";

const FORBIDDEN = 403;

function validaToken(string $pagina, string $token)
{

 if (!isset($_SESSION[$pagina]))
  throw new ProblemDetails(
   status: FORBIDDEN,
   title: "Página no registrada.",
   type: "/error/paginanoregistrada.html",
  );

 $tokensParaPagina = $_SESSION[$pagina];

 if (!is_array($tokensParaPagina))
  throw new ProblemDetails(
   status: FORBIDDEN,
   title: "No hay arereglo de tokens.",
   type: "/error/sintokens.html",
  );

 $hallado = false;

 // Valida que el token se haya registrado.
 foreach ($tokensParaPagina as $llave => $tokenParaPagina) {

  if (strcmp($token, $tokenParaPagina["texto"]) === 0) {

   if ($tokenParaPagina["expiracion"] < time()) {
    unset($tokensParaPagina[$llave]);
    $_SESSION[$pagina] = $tokensParaPagina;
    throw new ProblemDetails(
     status: FORBIDDEN,
     title: "Tiempo de expiración excedido.",
     type: "/error/paginaexpirada.html",
    );
   }

   $hallado = true;
  } elseif ($tokenParaPagina["expiracion"] > time()) {

   // Elimina tokens expirados
   unset($tokensParaPagina[$llave]);
  }
 }

 $_SESSION[$pagina] = $tokensParaPagina;

 if ($hallado === false)
  throw new ProblemDetails(
   status: FORBIDDEN,
   title: "Página no registrada.",
   type: "/error/paginanoregistrada.html",
  );
}
