<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/creaToken.php";
require_once __DIR__ . "/lib/devuelveJson.php";

session_start();
// Crea un token para la página "formulario" que expira en 5 minutos.
devuelveJson(["token" => ["value" => creaToken("formulario", 5)]]);
