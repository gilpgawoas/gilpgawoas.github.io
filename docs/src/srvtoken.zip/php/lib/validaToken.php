<?php

require_once __DIR__ . "/FORBIDDEN.php";
require_once __DIR__ . "/INTERNAL_SERVER_ERROR.php";
require_once __DIR__ . "/ProblemDetailsException.php";

function validaToken(string $pagina, string $token)
{
 if (!isset($_SESSION[$pagina]))
  throw new ProblemDetailsException([
   "status" => FORBIDDEN,
   "title" => "Página no registrada.",
   "type" => "/error/paginanoregistrada.html",
  ]);

 $tokensParaPagina = $_SESSION[$pagina];

 if (!is_array($tokensParaPagina))
  throw new ProblemDetailsException([
   "status" => INTERNAL_SERVER_ERROR,
   " title" => "No hay arreglo de tokens.",
   "type" => "/error/sintokens.html",
  ]);

 $hallado = false;

 // Valida que el token se haya registrado.
  $time = time();
 foreach ($tokensParaPagina as $llave => $tokenParaPagina) {

  if (strcmp($token, $tokenParaPagina["texto"]) === 0) {

   if ($tokenParaPagina["expiracion"] < $time) {
    unset($tokensParaPagina[$llave]);
    $_SESSION[$pagina] = $tokensParaPagina;
    throw new ProblemDetailsException([
     "status" => FORBIDDEN,
     "title" => "Tiempo de expiración excedido.",
     "type" => "/error/paginaexpirada.html",
    ]);
   }

   $hallado = true;
  } elseif ($tokenParaPagina["expiracion"] > $time) {

   // Elimina tokens expirados
   unset($tokensParaPagina[$llave]);
  }
 }

 $_SESSION[$pagina] = $tokensParaPagina;

 if ($hallado === false)
  throw new ProblemDetailsException([
   "status" => FORBIDDEN,
   "title" => "Página no registrada.",
   "type" => "/error/paginanoregistrada.html",
  ]);
}
