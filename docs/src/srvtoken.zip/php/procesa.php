<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeTextoObligatorio.php";
require_once __DIR__ . "/lib/validaToken.php";
require_once __DIR__ . "/lib/devuelveJson.php";

session_start();

$token = $_POST["token"];
validaToken("formulario", $token);

// Si el token se halló, precesa normalmente la forma.

$saludo = recibeTextoObligatorio("saludo");
$nombre = recibeTextoObligatorio("nombre");

$resultado = "{$saludo} {$nombre}.";

devuelveJson($resultado);
