<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/creaToken.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";

session_start();
// Crea un token para la página "formulario" que expira en 5 minutos.
devuelveJson(["x" => ["value" => creaToken("formulario", 5)]]);
