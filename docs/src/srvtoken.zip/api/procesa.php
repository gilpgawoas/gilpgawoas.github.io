<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeTextoObligatorio.php";
require_once __DIR__ . "/../libservidorphp/validaToken.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";

session_start();

$token = recibeTextoObligatorio("x");
validaToken("formulario", $token);

// Si el token se halló, precesa normalmente la forma.

$saludo = recibeTextoObligatorio("saludo");
$nombre = recibeTextoObligatorio("nombre");

$resultado = "{$saludo} {$nombre}.";

devuelveJson($resultado);
