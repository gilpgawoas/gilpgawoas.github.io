<?php

require_once __DIR__ . "/../lib/php/creaToken.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";

try {

 session_start();
 // Crea un token para la página "formulario" que expira en 5 minutos.
 devuelveJson(creaToken("formulario", 5));
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
