<?php

require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/creaToken.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";

ejecutaServicio(function () {
 session_start();
 // Crea un token para la página "formulario" que expira en 5 minutos.
 devuelveJson(creaToken("formulario", 5));
});
