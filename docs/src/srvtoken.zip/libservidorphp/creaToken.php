<?php

require_once __DIR__ . "/FORBIDDEN.php";
require_once __DIR__ . "/INTERNAL_SERVER_ERROR.php";
require_once __DIR__ . "/ProblemDetailsException.php";

function creaToken(string $pagina, int $duracionEnMinutos)
{
 $criptografiaFuerte = true;

 // Crea el token
 $token = [
  "expiracion" => time() + 60 * $duracionEnMinutos,
  // El token es de 80 caracteres, criptográficamente fuerte.
  "texto" => bin2hex(openssl_random_pseudo_bytes(80, $criptografiaFuerte))
 ];

 // Verifica que ya haya tokens $pagina.
 if (isset($_SESSION[$pagina])) {

  $tokensParaPagina = $_SESSION[$pagina];

  if (!is_array($tokensParaPagina))
   throw new ProblemDetailsException([
    "status" => INTERNAL_SERVER_ERROR,
    " title" => "No hay arreglo de tokens.",
    "type" => "/error/sintokens.html",
   ]);

  // Como ya existe el arreglo, elimina los tokens expirados para esta pagina.
  $time = time();
  foreach ($tokensParaPagina as $llave => $tokenParaPagina) {
   if ($tokenParaPagina["expiracion"] > $time) {
    unset($tokensParaPagina[$llave]);
   }
  }

  // Se puede usar uno o varios tokens por pagina.
  $tokensParaPagina[] = $token;
  $_SESSION[$pagina] = $tokensParaPagina;
 } else {

  // Se puede usar uno o varios tokens por pagina 
  $_SESSION[$pagina] = [$token];
 }

 return $token["texto"];
}
