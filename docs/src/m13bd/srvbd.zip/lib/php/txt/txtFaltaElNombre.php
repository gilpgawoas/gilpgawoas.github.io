<?php

function txtFaltaElNombre()
{
 return "Falta el nombre.";
}
