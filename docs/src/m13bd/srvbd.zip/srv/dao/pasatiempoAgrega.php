<?php

use srv\dao\AccesoBd;
use srv\modelo\Pasatiempo;

function pasatiempoAgrega(
 Pasatiempo $modelo
) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "INSERT INTO PASATIEMPO
    (PAS_NOMBRE)
   VALUES
    (:nombre)"
 );
 $stmt->execute([
  ":nombre" => $modelo->nombre
 ]);
 /* Si usas una secuencia para
  * generar el id, pasa como
  * parámetro de lastInsertId el
  * nombre de dicha secuencia. */
 $modelo->id =
  $con->lastInsertId();
}
