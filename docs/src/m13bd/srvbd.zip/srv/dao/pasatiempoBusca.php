<?php

use srv\dao\AccesoBd;
use srv\modelo\Pasatiempo;

function pasatiempoBusca(
 int $id
): false|Pasatiempo {
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    PAS_ID AS id,
    PAS_NOMBRE AS nombre
   FROM PASATIEMPO
   WHERE PAS_ID = :id"
 );
 $stmt->execute([":id" => $id]);
 $stmt->setFetchMode(
  PDO::FETCH_CLASS,
  Pasatiempo::class
 );
 return $stmt->fetch();
}
