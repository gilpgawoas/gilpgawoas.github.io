<?php

use srv\dao\AccesoBd;

function pasatiempoElimina(
 int $id
) {
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "DELETE FROM PASATIEMPO
   WHERE PAS_ID = :id"
 );
 $stmt->execute([":id" => $id]);
}
