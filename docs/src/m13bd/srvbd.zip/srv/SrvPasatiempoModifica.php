<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "lib/php/leeEntero.php";
require_once "lib/php/"
 . "leeSinEspaciosInFin.php";
require_once
 "srv/dao/pasatiempoModifica.php";

use \lib\php\Servicio;
use \srv\modelo\Pasatiempo;

class SrvPasatiempoModifica
extends Servicio
{

 protected
 function implementacion()
 {
  $modelo = new Pasatiempo();
  $modelo->id = leeEntero("id");
  $modelo->nombre =
   leeSinEspaciosInFin("nombre");
  pasatiempoModifica($modelo);
  return $modelo;
 }
}

$servicio =
 new SrvPasatiempoModifica();
$servicio->ejecuta();
