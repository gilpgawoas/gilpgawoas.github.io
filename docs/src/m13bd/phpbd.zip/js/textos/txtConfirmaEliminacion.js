export function txtConfirmaEliminacion() {
 return "Confirma la eliminación"
}