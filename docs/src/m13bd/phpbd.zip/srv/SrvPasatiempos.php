<?php
require_once __DIR__ .
 "/dao/pasatiempoConsulta.php";
require_once __DIR__ .
 "/modelo/Pasatiempo.php";
require_once __DIR__ .
 "/../lib/php/Servicio.php";

class SrvPasatiempos
extends Servicio
{
 protected
 function implementacion()
 {
  $lista = pasatiempoConsulta();
  $render = "";
  foreach ($lista as $it) {
   $id = htmlentities($it->id);
   $nombre =
    htmlentities($it->nombre);
   $render .=
    "<li>
     <p>
      <a
       href='modifica.html?id=$id'>
       {$nombre}
      </a>
     </p>
    </li>";
  }
  return ["render" => $render];
 }
}

$servicio = new SrvPasatiempos();
$servicio->ejecuta();
