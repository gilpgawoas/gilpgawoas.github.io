<?php
require_once __DIR__ .
 "/dao/pasatiempoElimina.php";
require_once __DIR__ .
 "/../lib/php/Servicio.php";
require_once __DIR__ .
 "/../lib/php/leeValor.php";

class SrvPasatiempoElimina
extends Servicio
{
 protected
 function implementacion()
 {
  $id = leeValor("id");
  pasatiempoElimina($id);
  return [];
 }
}

$servicio =
 new SrvPasatiempoElimina();
$servicio->ejecuta();
