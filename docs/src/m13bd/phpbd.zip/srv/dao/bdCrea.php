<?php
function bdCrea(\PDO $con)
{
 $con->exec(
  'CREATE TABLE
   IF NOT EXISTS PASATIEMPO (
    PAS_ID INTEGER PRIMARY KEY,
    PAS_NOMBRE TEXT NOT NULL
   )'
 );
}
