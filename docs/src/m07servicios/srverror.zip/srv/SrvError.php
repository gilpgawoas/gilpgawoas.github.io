<?php
require_once __DIR__ .
 "/../lib/php/Servicio.php";

class SrvError extends Servicio
{
 protected
 function implementacion()
 {
  throw new Exception("Ouch");
 }
}

$servicio = new SrvError();
$servicio->ejecuta();
