<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "lib/php/leeTexto.php";

use \lib\php\Servicio;

class SrvProcesa extends Servicio
{
 protected
 function implementacion()
 {
  $saludo = leeTexto("saludo");
  $nombre = leeTexto("nombre");
  if ($saludo === "") {
   throw new Exception(
    "Falta el saludo"
   );
  }
  if ($nombre === "") {
   throw new Exception(
    "Falta el nombre"
   );
  }
  $resultado =
   "{$saludo} {$nombre}.";
  return $resultado;
 }
}

$servicio = new SrvProcesa();
$servicio->ejecuta();
