<?php

use PHPUnit\Framework\TestCase;

require_once __DIR__ . "/../src/recomienda.php";

final class RecomiendaTest extends TestCase
{
 public function testPop()
 {
  $this->assertEquals("Dua Lipa.", recomienda("pop"), "Probando pop");
 }
 public function testReg()
 {
  $this->assertEquals("Bad Bunny.", recomienda("reg"), "Probando reg");
 }
 public function testReg2()
 {
  $this->assertEquals("Daddy Yankee.", recomienda("reg"), "Probando reg 2");
 }
}
