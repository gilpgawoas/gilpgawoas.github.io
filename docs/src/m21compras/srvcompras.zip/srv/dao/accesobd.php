<?php

namespace srv\dao;

require_once "srv/dao/bdCrea.php";
require_once
 "srv/dao/productoCuenta.php";
require_once
 "srv/dao/productoAgrega.php";
require_once
 "srv/dao/ventaCuenta.php";
require_once
 "srv/dao/ventaAgrega.php";
require_once
 "srv/txt/txtSandwich.php";
require_once
 "srv/txt/txtHotDog.php";
require_once
 "srv/txt/txtHamburguesa.php";

use \PDO;
use srv\modelo\Producto;
use srv\modelo\Venta;

class AccesoBd
{

 private static ?PDO $con = null;

 public static
 function getCon(): PDO
 {
  if (self::$con === null) {
   self::$con = self::conecta();
   self::prepara(self::$con);
  }
  return self::$con;
 }

 private static
 function conecta(): PDO
 {
  return new PDO(
   // cadena de conexión
   "sqlite:srvcompras.db",
   // usuario
   null,
   // contraseña
   null,
   [PDO::ATTR_ERRMODE
   => PDO::ERRMODE_EXCEPTION]
  );
 }
 private static
 function prepara(PDO $con)
 {
  bdCrea($con);
  if (productoCuenta()=== 0) {

   $producto = new Producto();
   $producto->nombre =
    txtSandwich();
   $producto->existencias = 50;
   $producto->precio = 15;
   productoAgrega($producto);

   $producto = new Producto();
   $producto->nombre = txtHotDog();
   $producto->existencias = 40;
   $producto->precio = 30;
   productoAgrega($producto);

   $producto = new Producto();
   $producto->nombre =
    txtHamburguesa();
   $producto->existencias = 30;
   $producto->precio = 40;
   productoAgrega($producto);
  }
  if (ventaCuenta() === 0) {
   $venta = new Venta();
   $venta->activa = true;
   $venta->detalles = [];
   ventaAgrega($venta);
  }
 }
}
