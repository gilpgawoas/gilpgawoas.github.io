<?php

function
txtDetalleVentaNoEncontrado()
{
 return "Detalle de venta no " .
  "encontrado.";
}
