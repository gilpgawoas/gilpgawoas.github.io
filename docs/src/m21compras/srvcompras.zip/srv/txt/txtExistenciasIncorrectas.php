<?php

function
txtExistenciasIncorrectas()
{
 return "Las existencias no "
  . "pueden ser NAN.";
}
