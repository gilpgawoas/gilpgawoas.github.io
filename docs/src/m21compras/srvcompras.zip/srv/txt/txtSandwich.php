<?php

function txtSandwich()
{
 return "Sandwich";
}
