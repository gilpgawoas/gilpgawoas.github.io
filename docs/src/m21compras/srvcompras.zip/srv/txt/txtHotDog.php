<?php

function txtHotDog()
{
 return "Hot dog";
}
