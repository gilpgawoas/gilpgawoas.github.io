<?php

function txtVentaNoEncontrada()
{
 return "Venta no encontrada.";
}
