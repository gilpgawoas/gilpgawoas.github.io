<?php

function txtProductoNoEncontrado()
{
 return "Producto no encontrado.";
}
