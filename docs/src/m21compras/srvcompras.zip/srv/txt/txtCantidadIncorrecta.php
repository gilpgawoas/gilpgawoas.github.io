<?php

function txtCantidadIncorrecta()
{
 return
  "La cantidad no puede ser NAN.";
}
