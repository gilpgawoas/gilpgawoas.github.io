<?php

function txtPrecioIncorrecto()
{
 return
  "El precio no puede ser NAN.";
}
