<?php

function txtNoEsDetalle()
{
 return
  "Detalle de tipo incorrecto.";
}
