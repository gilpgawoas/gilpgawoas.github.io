<?php

function txtHamburguesa()
{
 return "Hamburguesa";
}
