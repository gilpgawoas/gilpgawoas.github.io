export function
txtProductoAgregado() {
 return "Producto agregado."
}