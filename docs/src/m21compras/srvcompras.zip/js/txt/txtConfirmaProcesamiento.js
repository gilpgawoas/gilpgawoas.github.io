export function
 txtConfirmaProcesamiento() {
 return "Confirma procesar"
}