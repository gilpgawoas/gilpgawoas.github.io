<?php
require_once __DIR__ .
 "/../lib/php/Servicio.php";

class SrvRender extends Servicio
{
 protected
 function implementacion()
 {
  $lista = [
   ["nombre" => "pp"],
   ["nombre" => "kq"],
   ["nombre" => "tt"],
   ["nombre" => "bb"]
  ];
  $render = "";
  foreach ($lista as $it) {
   $nombre =
    htmlentities($it["nombre"]);
   $render .= /* html */
    "<div class='simple'>
      <div class='primario'>
       {$nombre}
      </div>
     </div>";
  }
  return ["render" => $render];
 }
}

$servicio = new SrvRender();
$servicio->ejecuta();
