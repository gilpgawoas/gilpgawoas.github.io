<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/pasatiempoOptions.php";

devuelveJson(["pasId" => ["innerHTML" => pasatiempoOptons()]]);
