<?php

require_once __DIR__ . "/../lib/php/OrmPdo.php";


const PASATIEMPO = "PASATIEMPO";
const PAS_ID = "PAS_ID";
const PAS_NOMBRE = "PAS_NOMBRE";

$pasatiempoOrm = new OrmPdo(
 nombreDeTabla: PASATIEMPO,
 nombresDeLlaves: [PAS_ID],
 nombresDeCampos: [PAS_NOMBRE]
);
