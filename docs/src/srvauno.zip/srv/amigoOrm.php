<?php

require_once __DIR__ . "/../lib/php/OrmPdo.php";
require_once __DIR__ . "/pasatiempoOrm.php";


const AMIGO = "AMIGO";
const AMI_ID = "AMI_ID";
const AMI_NOMBRE = "AMI_NOMBRE";

$amigoOrm = new OrmPdo(
 nombreDeTabla: AMIGO,
 nombresDeLlaves: [AMI_ID],
 nombresDeCampos: [AMI_NOMBRE, PAS_ID]
);
