<?php

const AMIGO = "AMIGO";
const AMI_ID = "AMI_ID";
const AMI_NOMBRE = "AMI_NOMBRE";
