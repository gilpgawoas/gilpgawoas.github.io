<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/pasatiempoOrm.php";

try {

 $conexionexion = Bd::getConexion($pasatiempoOrm);
 $lista = fetchAll($conexionexion->query(
  "SELECT *
   FROM PASATIEMPO
   ORDER BY PAS_NOMBRE"
 ));

 $render = "<option value=''>-- Sin pasatiempo --</option>";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo[PAS_ID]);
  $nombre = htmlentities($modelo[PAS_NOMBRE]);
  $render .= "<option value='$id'>{$nombre}</option>";
 }

 devuelveJson(["pasId" => ["innerHTML" => $render]]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
