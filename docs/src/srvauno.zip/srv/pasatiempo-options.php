<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $conexionexion = Bd::getConexion();
 $lista = fetchAll($conexionexion->query(
  "SELECT
    PAS_ID AS id,
    PAS_NOMBRE AS nombre
   FROM PASATIEMPO
   ORDER BY PAS_NOMBRE"
 ));

 $render = "<option value=''>-- Sin pasatiempo --</option>";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo->id);
  $nombre = htmlentities($modelo->nombre);
  $render .= "<option value='$id'>{$nombre}</option>";
 }

 devuelveJson(["pasId" => ["innerHTML" => $render]]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
