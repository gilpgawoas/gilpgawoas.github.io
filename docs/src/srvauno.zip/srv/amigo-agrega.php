<?php

require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaEntero.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/insert.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaPasId.php";

ejecutaServicio(function () {

 $nombre = recuperaTexto("nombre");
 $pasId = recuperaEntero("pasId");

 $nombre = validaNombre($nombre);
 $pasId = validaPasId($pasId);

 $pdo = Bd::pdo();
 insert(
  pdo: $pdo,
  into: AMIGO,
  values: [AMI_NOMBRE => $nombre, PAS_ID => $pasId]
 );
 $id = $pdo->lastInsertId();

 $encodeId = urlencode($id);

 devuelveCreated("/srv/amigo.php?id=$encodeId", [
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
  "pasId" => ["value" => $pasId === null ? "" : $pasId]
 ]);
});
