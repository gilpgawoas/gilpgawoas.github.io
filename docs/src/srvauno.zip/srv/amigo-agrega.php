<?php

require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaEntero.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaPasId.php";
require_once __DIR__ . "/amigoOrm.php";

try {

 $nombre = recuperaTexto("nombre");
 $pasId = recuperaEntero("pasId");

 $nombre = validaNombre($nombre);
 $pasId = validaPasId($pasId);

 list($id) = $amigoOrm->insert(
  Bd::getConexion($pasatiempoOrm),
  [[AMI_NOMBRE => $nombre, PAS_ID => $pasId]]
 );

 $encodeId = urlencode($id);

 devuelveCreated("/srv/amigo.php?id=$encodeId", [
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
  "pasId" => ["value" => $pasId === null ? "" : $pasId]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
