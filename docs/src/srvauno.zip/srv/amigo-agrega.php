<?php

require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaEntero.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaPasId.php";

try {

 $nombre = recuperaTexto("nombre");
 $pasId = recuperaEntero("pasId");

 $nombre = validaNombre($nombre);
 $pasId = validaPasId($pasId);

 $conexion = Bd::getConexion();
 $conexion->prepare(
  "INSERT INTO AMIGO
    (AMI_NOMBRE, PAS_ID)
   VALUES
    (:nombre, :pasId)"
 )
  ->execute([
   ":nombre" => $nombre,
   ":pasId" => $pasId
  ]);

 /* Recupera el id generado. Si usas una secuencia, pasa como
  * parámetro de lastInsertId el nombre de dicha secuencia y
  * poner esta instrucción antes del INSERT, al cual se le
  * pasarle el id generado. */
 $id = $conexion->lastInsertId();
 $encodeId = urlencode($id);

 devuelveCreated("/srv/amigo.php?id=$encodeId", [
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
  "pasId" => ["value" => $pasId === null ? "" : $pasId]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
