<?php

require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $amiId = recuperaIdEntero("id");

 $conexion = Bd::getConexion();

 $modelo = fetch(
  $conexion->prepare(
   "SELECT
     A.AMI_NOMBRE AS amiNombre,
     A.PAS_ID AS pasId,
     P.PAS_NOMBRE AS pasNombre
    FROM AMIGO A
     LEFT JOIN PASATIEMPO P
     ON A.PAS_ID = P.PAS_ID
    WHERE A.AMI_ID = :amiId"
  ),
  [":amiId" => $amiId]
 );

 if ($modelo === false) {

  $amiIdHtml = htmlentities($amiId);
  throw new ProblemDetails(
   status: NOT_FOUND,
   title: "Amigo no encontrado.",
   type: "/error/amigonoencontrado.html",
   detail: "No se encontró ningún amigo con el id $amiIdHtml.",
  );
 }

 $pasId = $modelo->pasId;
 devuelveJson([
  "id" => ["value" => $amiId],
  "nombre" => ["value" => $modelo->amiNombre],
  "pasId" => ["value" => $pasId === null ? "" : $pasId]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
