<?php

require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/selectFirst.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/Bd.php";

ejecutaServicio(function () {

 $amiId = recuperaIdEntero("id");

 $modelo = selectFirst(pdo: Bd::pdo(), from: AMIGO,  where: [AMI_ID => $amiId]);

 if ($modelo === false) {
  $amiIdHtml = htmlentities($amiId);
  throw new ProblemDetails(
   status: NOT_FOUND,
   title: "Amigo no encontrado.",
   type: "/error/amigonoencontrado.html",
   detail: "No se encontró ningún amigo con el id $amiIdHtml.",
  );
 }

 devuelveJson([
  "id" => ["value" => $amiId],
  "nombre" => ["value" => $modelo[AMI_NOMBRE]],
  "pasId" => ["value" => $modelo[PAS_ID] === null ? "" : $modelo[PAS_ID]]
 ]);
});
