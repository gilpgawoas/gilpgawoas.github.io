<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaEntero.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaPasId.php";

try {

 $id = recuperaIdEntero("id");
 $nombre = recuperaTexto("nombre");
 $pasId = recuperaEntero("pasId");

 $nombre = validaNombre($nombre);
 $pasId = validaPasId($pasId);

 $conexion = Bd::getConexion();
 $conexion->prepare(
  "UPDATE AMIGO
    SET
     AMI_NOMBRE = :nombre,
     PAS_ID = :pasId
    WHERE AMI_ID = :id"
 )
  ->execute([
   ":id" => $id,
   ":nombre" => $nombre,
   ":pasId" => $pasId
  ]);

 devuelveJson([
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
  "pasId" => ["value" => $pasId === null ? "" : $pasId]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
