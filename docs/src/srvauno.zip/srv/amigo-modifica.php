<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaEntero.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaPasId.php";
require_once __DIR__ . "/amigoOrm.php";
require_once __DIR__ . "/pasatiempoOrm.php";

try {

 $id = recuperaIdEntero("id");
 $nombre = recuperaTexto("nombre");
 $pasId = recuperaEntero("pasId");

 $nombre = validaNombre($nombre);
 $pasId = validaPasId($pasId);

 $amigoOrm->update(
  Bd::getConexion($pasatiempoOrm),
  [[AMI_ID => $id, AMI_NOMBRE => $nombre, PAS_ID => $pasId]]
 );

 devuelveJson([
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
  "pasId" => ["value" => $pasId === null ? "" : $pasId]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
