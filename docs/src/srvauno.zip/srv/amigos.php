<?php

require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/TABLA_AMIGO.php";
require_once __DIR__ . "/TABLA_PASATIEMPO.php";

ejecutaServicio(function () {

 $lista = fetchAll(Bd::pdo()->query(
  "SELECT
    A.AMI_ID,
    A.AMI_NOMBRE,
    P.PAS_NOMBRE
   FROM AMIGO A
    LEFT JOIN PASATIEMPO P
    ON A.PAS_ID = P.PAS_ID
   ORDER BY A.AMI_NOMBRE"
 ));

 $render = "";
 foreach ($lista as $modelo) {
  $encodeAmiId = urlencode($modelo[AMI_ID]);
  $amiId = htmlentities($encodeAmiId);
  $amiNombre = htmlentities($modelo[AMI_NOMBRE]);
  $pasNombre = $modelo[PAS_NOMBRE] === null
   ? "<em>-- Sin pasatiempo --</em>"
   : htmlentities($modelo[PAS_NOMBRE]);
  $render .=
   "<dt><a href='modifica.html?id=$amiId'>$amiNombre</a></dt>
    <dd><a href='modifica.html?id=$amiId'>$pasNombre</a></dd>";
 }

 devuelveJson(["lista" => ["innerHTML" => $render]]);
});
