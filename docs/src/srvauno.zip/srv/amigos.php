<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $conexionexion = Bd::getConexion();
 $lista = fetchAll($conexionexion->query(
  "SELECT
    A.AMI_ID AS amiId,
    A.AMI_NOMBRE AS amiNombre,
    P.PAS_NOMBRE AS pasNombre
   FROM AMIGO A
    LEFT JOIN PASATIEMPO P
    ON A.PAS_ID = P.PAS_ID
   ORDER BY A.AMI_NOMBRE"
 ));

 $render = "";
 foreach ($lista as $modelo) {
  $encodeAmiId = urlencode($modelo->amiId);
  $amiId = htmlentities($encodeAmiId);
  $amiNombre = htmlentities($modelo->amiNombre);
  $pasNombre = $modelo->pasNombre === null
   ? "<em>-- Sin pasatiempo --</em>"
   : htmlentities($modelo->pasNombre);
  $render .=
   "<dt><a href='modifica.html?id=$amiId'>$amiNombre</a></dt>
    <dd><a href='modifica.html?id=$amiId'>$pasNombre</a></dd>";
 }

 devuelveJson(["lista" => ["innerHTML" => $render]]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
