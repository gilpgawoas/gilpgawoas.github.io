<?php

require_once __DIR__ . "/pasatiempoOrm.php";

class Bd
{

 private static ?PDO $conexion = null;

 static function getConexion(OrmPdo $pasatiempoOrm): PDO
 {
  if (self::$conexion === null) {

   self::$conexion = new PDO(
    // cadena de conexión
    "sqlite:srvauno.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: conexiones persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS PASATIEMPO (
      PAS_ID INTEGER,
      PAS_NOMBRE TEXT NOT NULL,
      CONSTRAINT PAS_PK
       PRIMARY KEY(PAS_ID),
      CONSTRAINT PAS_NOM_UNQ
       UNIQUE(PAS_NOMBRE),
      CONSTRAINT PAS_NOM_NV
       CHECK(LENGTH(PAS_NOMBRE) > 0)
     )'
   );
   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS AMIGO (
      AMI_ID INTEGER,
      AMI_NOMBRE TEXT NOT NULL,
      PAS_ID INTEGER,
      CONSTRAINT AMI_PK
       PRIMARY KEY(AMI_ID),
      CONSTRAINT AMI_NOM_UNQ
       UNIQUE(AMI_NOMBRE),
      CONSTRAINT AMI_NOM_NV
       CHECK(LENGTH(AMI_NOMBRE) > 0),
      CONSTRAINT AMI_PAS_FK
       FOREIGN KEY (PAS_ID) REFERENCES PASATIEMPO(PAS_ID)
     )'
   );

   $cantidadDePasatiempos =
    self::$conexion->query("SELECT COUNT(PAS_ID) FROM PASATIEMPO")
    ->fetchColumn();

   if ($cantidadDePasatiempos === 0) {
    $pasatiempoOrm->insert(
     self::$conexion,
     [[PAS_NOMBRE => 'Futbol'], [PAS_NOMBRE => 'Videojuegos']]
    );
   }
  }

  return self::$conexion;
 }
}
