<?php

require_once __DIR__ . "/../lib/php/insert.php";

const AMIGO = "AMIGO";
const AMI_ID = "AMI_ID";
const AMI_NOMBRE = "AMI_NOMBRE";

const PASATIEMPO = "PASATIEMPO";
const PAS_ID = "PAS_ID";
const PAS_NOMBRE = "PAS_NOMBRE";

class Bd
{
 private static ?PDO $pdo = null;

 static function pdo(): PDO
 {
  if (self::$pdo === null) {

   self::$pdo = new PDO(
    // cadena de conexión
    "sqlite:srvauno.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: conexiones persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS PASATIEMPO (
      PAS_ID INTEGER,
      PAS_NOMBRE TEXT NOT NULL,
      CONSTRAINT PAS_PK
       PRIMARY KEY(PAS_ID),
      CONSTRAINT PAS_NOM_UNQ
       UNIQUE(PAS_NOMBRE),
      CONSTRAINT PAS_NOM_NV
       CHECK(LENGTH(PAS_NOMBRE) > 0)
     )'
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS AMIGO (
      AMI_ID INTEGER,
      AMI_NOMBRE TEXT NOT NULL,
      PAS_ID INTEGER,
      CONSTRAINT AMI_PK
       PRIMARY KEY(AMI_ID),
      CONSTRAINT AMI_NOM_UNQ
       UNIQUE(AMI_NOMBRE),
      CONSTRAINT AMI_NOM_NV
       CHECK(LENGTH(AMI_NOMBRE) > 0),
      CONSTRAINT AMI_PAS_FK
       FOREIGN KEY (PAS_ID) REFERENCES PASATIEMPO(PAS_ID)
     )'
   );

   $cantidadDePasatiempos =
    self::$pdo->query("SELECT COUNT(PAS_ID) FROM PASATIEMPO")->fetchColumn();

   if ($cantidadDePasatiempos === 0) {
    insert(pdo: self::$pdo, into: PASATIEMPO, values: [PAS_NOMBRE => 'Futbol']);
    insert(self::$pdo, PASATIEMPO, [PAS_NOMBRE => 'Videojuegos']);
   }
  }

  return self::$pdo;
 }
}
