export function
txtRolIdsIncorrecto() {
 return "rolIds debe ser arreglo."
}