export function
 txtCueIncorrecto() {
 return "cue debe ser string."
}