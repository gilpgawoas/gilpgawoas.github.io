export const ROL_ADMINISTRADOR =
 "Administrador"