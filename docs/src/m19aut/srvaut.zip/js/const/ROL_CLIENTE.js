export const ROL_CLIENTE =
 "Cliente"