<?php

function txtFaltaElId()
{
 return "Falta el id.";
}
