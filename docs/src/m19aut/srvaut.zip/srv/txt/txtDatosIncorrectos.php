<?php

function txtDatosIncorrectos()
{
 return "Datos incorrectos.";
}
