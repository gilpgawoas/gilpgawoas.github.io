<?php

function txtNoEsUnRol()
{
 return "Rol de un tipo inválido.";
}
