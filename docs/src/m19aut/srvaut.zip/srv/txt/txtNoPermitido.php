<?php

function txtNoPermitido()
{
 return "No permitido.";
}
