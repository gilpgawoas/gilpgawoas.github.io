<?php

function txtFaltaElCue()
{
 return "Falta el cue.";
}
