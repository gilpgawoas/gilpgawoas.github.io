<?php

function txtAdministraElSistema()
{
 return "Administra el sistema.";
}
