<?php

function txtFaltaLaDescripcion()
{
 return "Faltala la descripción.";
}
