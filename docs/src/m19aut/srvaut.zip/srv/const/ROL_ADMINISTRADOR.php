<?php

const ROL_ADMINISTRADOR =
"Administrador";
