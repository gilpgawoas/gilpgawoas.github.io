<?php

const ROL_CLIENTE = "Cliente";