<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";

use \lib\php\Servicio;

class SrvRender extends Servicio
{
 protected
 function implementacion()
 {
  $lista = [
   [
    "nombre" => "pp",
    "color" => "azul"
   ],
   [
    "nombre" => "kq",
    "color" => "rojo"
   ],
   [
    "nombre" => "tt",
    "color" => "rosa"
   ],
   [
    "nombre" => "bb",
    "color" => "azul"
   ]
  ];
  $render = "";
  foreach ($lista as $modelo) {
   /* Codifica el nombre para que
    * cambie los caracteres
    * especiales y no se pueda
    * interpretar como HTML. Esta
    * técnica evita la inyección de
    * código. */
   $nombre = htmlentities(
    $modelo["nombre"]
   );
   $color = htmlentities(
    $modelo["color"]
   );
   $render .=
    "<li>
      <p>
       <strong>{$nombre}</strong>
       <br>{$color}
      </p>
     </li>";
  }
  return $render;
 }
}

$servicio = new SrvRender();
$servicio->ejecuta();
