<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";

use \lib\php\Servicio;

class SrvResultado
extends Servicio
{
 protected
 function implementacion()
 {
  return [
   "nombre" => "pp",
   "mensaje" => "Hola."
  ];
 }
}

$servicio = new SrvResultado();
$servicio->ejecuta();
