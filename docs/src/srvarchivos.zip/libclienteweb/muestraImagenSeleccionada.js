/**
 * @param {HTMLInputElement} input
 * @param {HTMLImageElement} img
 */
export function muestraImagenSeleccionada(input, img) {
 return new Promise((resolve, reject) => {
  setTimeout(() => {

   try {

    const objectUrl = getObjectUrlDeSeleccion(input)

    if (objectUrl === "") {

     const src = input.dataset.src
     if (src === undefined || src === "") {
      img.hidden = true
      img.src = ""
     } else {
      img.hidden = false
      img.src = src
     }

    } else {

     img.hidden = false
     img.src = objectUrl

    }

    resolve(true)

   } catch (error) {

    img.hidden = true

    reject(error)

   }

  },
   500)
 })
}

/**
 * @param {HTMLInputElement} input
 */
export function getObjectUrlDeSeleccion(input) {
 const seleccion = getArchivoSeleccionado(input)
 if (seleccion === null) {
  return ""
 } else {
  return URL.createObjectURL(seleccion)
 }
}


/**
 * @param { HTMLInputElement } input
 */
export function getArchivoSeleccionado(input) {
 if (input.type !== "file") throw new Error('El input debe ser type="file')
 const seleccion = input.files
 if (seleccion === null) throw new Error('El input debe ser type="file')
 if (seleccion.length === 0) {
  return null
 } else {
  return seleccion.item(0)
 }
}