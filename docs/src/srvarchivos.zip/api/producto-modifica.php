<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeTextoObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeBytesOpcionales.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";

$prodId = recibeEnteroObligatorio("id");
$nombre = recibeTextoObligatorio("nombre");
$bytes = recibeBytesOpcionales("imagen");

$bd = Bd::conexion();
$bd->beginTransaction();

$producto = productoBusca($bd, $prodId);
$producto = validaEntidadObligatoria("Producto",  $producto);

$archId = $producto["PRD_ARCH_ID"];

if ($bytes !== "") {
 if ($archId === null) {
  $archId = archivoAgrega($bd, $bytes);
 } else {
  $stmt = $bd->prepare(
   "UPDATE ARCHIVO
   SET
    ARCH_BYTES = :ARCH_BYTES
   WHERE
    ARCH_ID = :ARCH_ID"
  );
  $stmt->execute([
   ":ARCH_BYTES" => $bytes,
   ":ARCH_ID" => $archId,
  ]);
 }
}

$stmt = $bd->prepare(
 "UPDATE PRODUCTO
   SET
    PRD_NOMBRE = TRIM(:PRD_NOMBRE),
    PRD_ARCH_ID = :PRD_ARCH_ID
   WHERE
    PRD_ID = :PRD_ID"
);
$stmt->execute([
 ":PRD_NOMBRE" => $nombre,
 ":PRD_ARCH_ID" => $archId,
 ":PRD_ID" => $prodId,
]);

$bd->commit();

$queryArch = http_build_query(["id" => $archId]);
// Los bytes de las imágenes se descargan con "archivo.php"; no desde aquí.
devuelveJson([
 "id" => ["value" => $prodId],
 "nombre" => ["value" => $nombre],
 "imagen" => ["data-src" => $archId === "" ? "" : "api/archivo.php?$queryArch"]
]);
