<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeTextoObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeBytesObligatorios.php";
require_once __DIR__ . "/../libservidorphp/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/archivoAgrega.php";

$nombre = recibeTextoObligatorio("nombre");
$bytes = recibeBytesObligatorios("imagen");

$bd = Bd::conexion();
$bd->beginTransaction();

$archId = archivoAgrega($bd, $bytes);

$stmt = $bd->prepare(
 "INSERT INTO PRODUCTO (
    PRD_NOMBRE, PRD_ARCH_ID
   ) values (
    TRIM(:PRD_NOMBRE), :PRD_ARCH_ID
   )"
);
$stmt->execute([
 ":PRD_NOMBRE" => $nombre,
 ":PRD_ARCH_ID" => $archId
]);
$prodId = $bd->lastInsertId();

$bd->commit();

$query = http_build_query(["id" => $prodId]);
$queryArch = http_build_query(["id" => $archId]);
// Los bytes de las imágenes se descargan con "archivo.php"; no desde aquí.
devuelveCreated("/api/producto-vista-modifica.php?$query", [
 "id" => ["value" => $prodId],
 "nombre" => ["value" => $nombre],
 "imagen" => ["data-src" => $archId === "" ? "" : "api/archivo.php?$queryArch"]
]);
