<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/devuelveNoContent.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";

$prodId = recibeEnteroObligatorio("id");

$bd = Bd::conexion();
$bd->beginTransaction();

$producto = productoBusca($bd, $prodId);

if ($producto !== false) {

 $archId = $producto["PRD_ARCH_ID"];

 $stmt = $bd->prepare("DELETE FROM PRODUCTO WHERE PRD_ID = :PRD_ID");
 $stmt->execute([":PRD_ID" => $prodId]);

 if ($archId !== null) {
  $stmt = $bd->prepare("DELETE FROM ARCHIVO WHERE ARCH_ID = :ARCH_ID");
  $stmt->execute([":ARCH_ID" => $archId]);
 }
}

$bd->commit();

devuelveNoContent();
