<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

$bd = Bd::conexion();
$stmt = $bd->query("SELECT * FROM PRODUCTO ORDER BY PRD_NOMBRE");
$lista = $stmt->fetchAll(PDO::FETCH_ASSOC);

$render = "";
foreach ($lista as $modelo) {
 $prodId = $modelo["PRD_ID"];
 $archId = $modelo["PRD_ARCH_ID"] === null ? "" : $modelo["PRD_ARCH_ID"];
 $query = htmlentities(http_build_query(["id" => $prodId]));
 $urlModifica = "modifica.html?$query";
 $queryArch = htmlentities(http_build_query(["id" => $archId]));
 $alt = $archId === "" ? "Sin imagen" : "Imagen del producto";
 $src = $archId === "" ? "" : "api/archivo.php?$queryArch";
 $prodNombre = htmlentities($modelo["PRD_NOMBRE"]);
 // Los bytes de las imágenes se descargan con "archivo.php"; no desde aquí.
 $render .=
  "<div style='display: flex; flex-direction: row-reverse;
      align-items: center; gap: 0.5rem'>
     <dt style='flex: 1 1 0'>
      <a href='$urlModifica'>$prodNombre</a>
     </dt>
     <dd style='flex: 1 1 0; margin: 0'>
      <a href='$urlModifica'><img
        style='width: 100%; aspect-ratio:16/9; object-fit: contain'
        alt=$alt src='$src'></a>
     </dd>
    </div>";
}

devuelveJson(["lista" => ["innerHTML" => $render]]);
