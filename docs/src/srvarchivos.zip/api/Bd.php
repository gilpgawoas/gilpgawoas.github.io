<?php

class Bd
{
 private static ?PDO $pdo = null;

 static function conexion(): PDO
 {
  if (self::$pdo === null) {

   self::$pdo = new PDO(
    // cadena de conexión
    "sqlite:" . __DIR__ . "/srvarchivos.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: pdos no persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS ARCHIVO (
      ARCH_ID INTEGER,
      ARCH_BYTES BLOB NOT NULL,
      CONSTRAINT PK_ARCH PRIMARY KEY(ARCH_ID)
     )'
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS PRODUCTO (
      PRD_ID INTEGER,
      PRD_NOMBRE TEXT NOT NULL,
      PRD_ARCH_ID INTEGER NOT NULL,
      CONSTRAINT PK_PRD PRIMARY KEY(PRD_ID),
      CONSTRAINT UQ_PRD_NOM UNIQUE(PRD_NOMBRE),
      CONSTRAINT CHK_PRD_NOM CHECK(LENGTH(PRD_NOMBRE) > 0),
      CONSTRAINT FK_PRD_ARCH
       FOREIGN KEY (PRD_ARCH_ID) REFERENCES ARCHIVO(ARCH_ID)
      )'
   );
  }

  return self::$pdo;
 }
}
