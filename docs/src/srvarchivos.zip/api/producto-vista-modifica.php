<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";

$prodId = recibeEnteroObligatorio("id");

$bd = Bd::conexion();
$modelo = productoBusca($bd, $prodId);

$modelo = validaEntidadObligatoria("Producto",  $modelo);

$archId = $modelo["PRD_ARCH_ID"] === null ? "" : $modelo["PRD_ARCH_ID"];
$queryArch = http_build_query(["id" => $archId]);
$src = $archId === "" ? "" : "api/archivo.php?$queryArch";
// Los bytes de las imágenes se descargan con "archivo.php"; no desde aquí.
devuelveJson([
 "id" => ["value" => $prodId],
 "nombre" => ["value" => $modelo["PRD_NOMBRE"]],
 "imagen" => ["data-src" => $src]
]);
