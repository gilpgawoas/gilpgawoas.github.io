<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/devuelveNoContent.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";

$prodId = recibeEnteroObligatorio("id");

$bd = Bd::pdo();
$bd->beginTransaction();

$producto = productoBusca($bd, $prodId);
if ($producto !== false) {

 $stmt = $bd->prepare("DELETE FROM PRODUCTO WHERE PROD_ID = :PROD_ID");
 $stmt->execute([":PROD_ID" => $prodId]);

 if ($producto["ARCH_ID"] !== null) {
  $stmt = $bd->prepare("DELETE FROM ARCHIVO WHERE ARCH_ID = :ARCH_ID");
  $stmt->execute([":ARCH_ID" => $producto["ARCH_ID"]]);
 }
}

$bd->commit();

devuelveNoContent();
