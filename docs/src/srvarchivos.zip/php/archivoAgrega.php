<?php

function archivoAgrega(PDO $bd, string $bytes)
{
 $stmt = $bd->prepare(
  "INSERT INTO ARCHIVO (
    ARCH_BYTES
   ) values (
    :ARCH_BYTES
   )"
 );
 $stmt->execute([
  ":ARCH_BYTES" => $bytes
 ]);
 $archId = $bd->lastInsertId();
 return $archId;
}
