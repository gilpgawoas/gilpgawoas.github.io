<?php

require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/Bd.php";

// Evita que la imagen se cargue en el caché del navegador.
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

$archId = recibeEnteroObligatorio("id");

$bd = Bd::pdo();

$stmt = $bd->prepare("SELECT * FROM ARCHIVO WHERE ARCH_ID = :ARCH_ID");
$stmt->execute([":ARCH_ID" => $archId]);
$archivo = $stmt->fetch(PDO::FETCH_ASSOC);

$archivo = validaEntidadObligatoria("Archivo",  $archivo);

$bytes = $archivo["ARCH_BYTES"];
$contentType = (new finfo(FILEINFO_MIME_TYPE))->buffer($bytes);
header("Content-Type: $contentType");
echo $bytes;
