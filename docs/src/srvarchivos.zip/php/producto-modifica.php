<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeEnteroObligatorio.php";
require_once __DIR__ . "/lib/recibeTextoObligatorio.php";
require_once __DIR__ . "/lib/recibeBytesOpcionales.php";
require_once __DIR__ . "/lib/validaEntidadObligatoria.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/productoBusca.php";

$prodId = recibeEnteroObligatorio("id");
$nombre = recibeTextoObligatorio("nombre");
$bytes = recibeBytesOpcionales("imagen");

$bd = Bd::pdo();
$bd->beginTransaction();

$producto = productoBusca($bd, $prodId);
$producto = validaEntidadObligatoria("Producto",  $producto);

$archId = $producto["ARCH_ID"];

if ($bytes !== "") {
 if ($archId === null) {
  $archId = archivoAgrega($bd, $bytes);
 } else {
  $stmt = $bd->prepare(
   "UPDATE ARCHIVO
   SET
    ARCH_BYTES = :ARCH_BYTES
   WHERE
    ARCH_ID = :ARCH_ID"
  );
  $stmt->execute([
   ":ARCH_BYTES" => $bytes,
   ":ARCH_ID" => $archId,
  ]);
 }
}

$stmt = $bd->prepare(
 "UPDATE PRODUCTO
   SET
    PROD_NOMBRE = :PROD_NOMBRE,
    ARCH_ID = :ARCH_ID
   WHERE
    PROD_ID = :PROD_ID"
);
$stmt->execute([
 ":PROD_NOMBRE" => $nombre,
 ":ARCH_ID" => $archId,
 ":PROD_ID" => $prodId,
]);

$bd->commit();

$encodeArchId = $archId === null ? "" : urlencode($archId);
$htmlEncodeArchId = htmlentities($encodeArchId);
// Los bytes de las imágenes se descargan con "archivo.php"; no desde aquí.
devuelveJson([
 "id" => ["value" => $prodId],
 "nombre" => ["value" => $nombre],
 "imagen" => [
  "data-src" => $htmlEncodeArchId === ""
   ? ""
   : "php/archivo.php?id=$htmlEncodeArchId"
 ]
]);
