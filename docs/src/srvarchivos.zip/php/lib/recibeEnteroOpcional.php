<?php

require_once __DIR__ . "/recibeEntero.php";

function recibeEnteroOpcional(string $parametro)
{
 $enteroOpcional = recibeEntero($parametro);
 return $enteroOpcional === false ? null : $enteroOpcional;
}
