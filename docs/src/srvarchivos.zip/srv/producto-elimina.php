<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/../lib/php/devuelveNoContent.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $prodId = recuperaIdEntero("id");

 $conexion = Bd::getConexion();
 $conexion->beginTransaction();

 $archId = fetch(
  $conexion->prepare(
   "SELECT
     A.ARCH_ID
    FROM PRODUCTO P
     LEFT JOIN ARCHIVO A
     ON P.ARCH_ID = A.ARCH_ID
    WHERE P.PROD_ID = :prodId"
  ),
  [":prodId" => $prodId],
  PDO::FETCH_COLUMN
 );

 if ($archId === false) {

  // No encontró un producto con ese $prodId. Ya está borrado. 
  $conexioncon->rollBack();
 } else {

  if ($archId !== null) {
   $conexion->prepare(
    "DELETE FROM ARCHIVO
      WHERE ARCH_ID = :archId"
   )->execute([":archId" => $archId]);
  }

  $conexion->prepare(
   "DELETE FROM PRODUCTO
     WHERE PROD_ID = :prodId"
  )
   ->execute([":prodId" => $prodId]);

  $conexion->commit();
 }

 devuelveNoContent();
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
