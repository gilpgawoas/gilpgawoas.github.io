<?php

require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $prodId = recuperaIdEntero("id");

 $conexion = Bd::getConexion();

 $modelo = fetch(
  $conexion->prepare(
   "SELECT
     P.PROD_NOMBRE AS prodNombre,
     A.ARCH_ID AS archId
    FROM PRODUCTO P
     LEFT JOIN ARCHIVO A
     ON P.ARCH_ID = A.ARCH_ID
    WHERE P.PROD_ID = :prodId"
  ),
  [":prodId" => $prodId]
 );

 if ($modelo === false) {

  $prodIdHtml = htmlentities($prodId);
  throw new ProblemDetails(
   status: NOT_FOUND,
   title: "Producto no encontrado.",
   type: "/error/productonoencontrado.html",
   detail: "No se encontró ningún producto con el id $prodIdHtml.",
  );
 }

 $encodeArchId = $modelo->archId === null ? "" : urlencode($modelo->archId);
 $htmlEncodeArchId = htmlentities($encodeArchId);
 devuelveJson([
  "id" => ["value" => $prodId],
  "nombre" => ["value" => $modelo->prodNombre],
  "imagen" => [
   "data-file" => $htmlEncodeArchId === ""
    ? ""
    : "srv/archivo.php?id=$htmlEncodeArchId"
  ]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
