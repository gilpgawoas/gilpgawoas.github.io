<?php

class Bd
{

 private static ?PDO $conexion = null;

 static function getConexion(): PDO
 {

  if (self::$conexion === null) {

   self::$conexion = new PDO(
    // cadena de conexión
    "sqlite:srvarchivos.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: conexiones persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS ARCHIVO (
      ARCH_ID INTEGER,
      ARCH_BYTES BLOB NOT NULL,
      CONSTRAINT ARCH_PK
       PRIMARY KEY(ARCH_ID)
     )'
   );
   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS PRODUCTO (
      PROD_ID INTEGER,
      PROD_NOMBRE TEXT NOT NULL,
      ARCH_ID INTEGER NOT NULL,
      CONSTRAINT PROD_PK
       PRIMARY KEY(PROD_ID),
      CONSTRAINT PROD_NOM_UNQ
       UNIQUE(PROD_NOMBRE),
      CONSTRAINT PROD_NOM_NV
       CHECK(LENGTH(PROD_NOMBRE) > 0),
      CONSTRAINT PROD_ARCH_FK
       FOREIGN KEY (ARCH_ID) REFERENCES ARCHIVO(ARCH_ID)
      )'
   );
  }

  return self::$conexion;
 }
}
