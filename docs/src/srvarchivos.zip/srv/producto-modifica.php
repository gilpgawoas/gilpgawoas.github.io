<?php

require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaBytes.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaImagen.php";

try {

 $prodId = recuperaIdEntero("id");
 $nombre = recuperaTexto("nombre");
 $bytes = recuperaBytes("imagen");

 $nombre = validaNombre($nombre);
 $bytes = validaImagen($bytes);

 $conexion = Bd::getConexion();
 $conexion->beginTransaction();

 $archId = fetch(
  $conexion->prepare(
   "SELECT
     A.ARCH_ID AS archId
    FROM PRODUCTO P
     LEFT JOIN ARCHIVO A
     ON P.ARCH_ID = A.ARCH_ID
    WHERE P.PROD_ID = :prodId"
  ),
  [":prodId" => $prodId],
  PDO::FETCH_COLUMN
 );

 if ($archId === false) {

  $prodIdHtml = htmlentities($prodId);
  throw new ProblemDetails(
   status: NOT_FOUND,
   title: "Producto no encontrado.",
   type: "/error/productonoencontrado.html",
   detail: "No se encontró ningún producto con el id $prodIdHtml.",
  );
 }

 if ($bytes !== "") {

  if ($archId === null) {

   $conexion->prepare(
    "INSERT INTO ARCHIVO
       (ARCH_BYTES)
      VALUES
       (:bytes)"
   )
    ->execute([":bytes" => $bytes]);

   /* Recupera el id generado. Si usas una secuencia, pasa como
    * parámetro de lastInsertId el nombre de dicha secuencia y
    * poner esta instrucción antes del INSERT, al cual se le
    * pasarle el id generado. */
   $archId = $conexion->lastInsertId();
  } else {

   $conexion->prepare(
    "UPDATE ARCHIVO
     SET ARCH_BYTES = :bytes
     WHERE ARCH_ID = :archId"
   )
    ->execute([
     ":bytes" => $bytes,
     ":archId" => $archId
    ]);
  }
 }

 $conexion->prepare(
  "UPDATE PRODUCTO
   SET
    PROD_NOMBRE = :nombre,
    ARCH_ID = :archId
   WHERE PROD_ID = :prodId"
 )
  ->execute([
   ":prodId" => $prodId,
   ":nombre" => $nombre,
   ":archId" => $archId
  ]);

 $conexion->commit();

 $encodeArchId = $archId === null ? "" : urlencode($archId);
 $htmlEncodeArchId = htmlentities($encodeArchId);

 // Los bytes se descargan con "archivo.php"; no desde aquí.
 devuelveJson([
  "id" => ["value" => $prodId],
  "nombre" => ["value" => $nombre],
  "imagen" => [
   "data-file" => $htmlEncodeArchId === ""
    ? ""
    : "srv/archivo.php?id=$htmlEncodeArchId"
  ]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
