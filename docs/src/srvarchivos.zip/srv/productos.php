<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $conexion = Bd::getConexion();
 $lista = fetchAll($conexion->query(
  "SELECT
    P.PROD_ID AS prodId,
    P.PROD_NOMBRE AS prodNombre,
    A.ARCH_ID AS archId
   FROM PRODUCTO P
    LEFT JOIN ARCHIVO A
    ON P.ARCH_ID = A.ARCH_ID
   ORDER BY P.PROD_NOMBRE"
 ));

 $render = "";
 foreach ($lista as $modelo) {
  $prodId = htmlentities($modelo->prodId);
  $prodNombre = htmlentities($modelo->prodNombre);
  $encodeArchId = $modelo->archId === null ? "" : urlencode($modelo->archId);
  $archId = $encodeArchId === "" ? "" : htmlentities($encodeArchId);
  $src = $archId === "" ? "" : "srv/archivo.php?id=$archId";

  $render .=
   "<div style='display: flex; flex-direction: row-reverse;
      align-items: center; gap: 0.5rem'>
     <dt style='flex: 1 1 0'>
      <a href='modifica.html?id=$prodId'>$prodNombre</a>
     </dt>
     <dd style='flex: 1 1 0; margin: 0'>
      <a href='modifica.html?id=$prodId'><img
        style='width: 100%; aspect-ratio:16/9; object-fit: cover'
        alt='Imagen del producto' src='$src'></a>
     </dd>
    </div>";
 }

 devuelveJson(["lista" => ["innerHTML" => $render]]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
