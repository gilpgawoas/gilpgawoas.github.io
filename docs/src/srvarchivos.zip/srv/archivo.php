<?php

require_once __DIR__ . "/../lib/php/NOT_FOUND.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/fetch.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 // Evita que la imagen se cargue en el caché de la computadora.
 header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
 header("Cache-Control: post-check=0, pre-check=0", false);
 header("Pragma: no-cache");

 $amiId = recuperaIdEntero("id");

 $conexion = Bd::getConexion();

 $bytes = fetch(
  $conexion->prepare(
   "SELECT
     ARCH_BYTES
    FROM ARCHIVO
    WHERE ARCH_ID = :id"
  ),
  [":id" => $amiId],
  PDO::FETCH_COLUMN
 );

 if ($bytes === false) {

  $idHtml = htmlentities($amiId);
  throw new ProblemDetails(
   status: NOT_FOUND,
   title: "Archivo no encontrado.",
   type: "/error/archivonoencontrado.html",
   detail: "No se encontró ningún archivo con el id $idHtml.",
  );
 }

 $contentType = (new finfo(FILEINFO_MIME_TYPE))->buffer($bytes);
 header("Content-Type: $contentType");
 echo $bytes;
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
