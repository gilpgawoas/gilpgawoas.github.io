<?php

require_once __DIR__ . "/../lib/php/BAD_REQUEST.php";
require_once __DIR__ . "/../lib/php/recuperaBytes.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/validaImagen.php";

try {

 $nombre = recuperaTexto("nombre");
 $bytes = recuperaBytes("imagen");

 $nombre = validaNombre($nombre);
 $bytes = validaImagen($bytes);

 if ($bytes === "") {

  throw new ProblemDetails(
   status: BAD_REQUEST,
   title: "Imagen vacía.",
   type: "/error/imagenvacia.html",
   detail: "Selecciona un archivo que no esté vacío."
  );
 }

 $conexion = Bd::getConexion();
 $conexion->beginTransaction();

 $conexion->prepare(
  "INSERT INTO ARCHIVO
     (ARCH_BYTES)
    VALUES
     (:bytes)"
 )
  ->execute([":bytes" => $bytes]);

 /* Recupera el id generado. Si usas una secuencia, pasa como
  * parámetro de lastInsertId el nombre de dicha secuencia y
  * poner esta instrucción antes del INSERT, al cual se le
  * pasarle el id generado. */
 $archId = $conexion->lastInsertId();
 $encodeArchId = urlencode($archId);
 $htmlEncodeArchId = htmlentities($encodeArchId);

 $conexion->prepare(
  "INSERT INTO PRODUCTO
    (PROD_NOMBRE, ARCH_ID)
   VALUES
    (:nombre, :archId)"
 )
  ->execute([
   ":nombre" => $nombre,
   ":archId" => $archId
  ]);
 $id = $conexion->lastInsertId();
 $encodeId = urlencode($id);

 $conexion->commit();

 // Los bytes se descargan con "archivo.php"; no desde aquí.
 devuelveCreated("/srv/producto.php?id=$encodeId", [
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
  "imagen" => ["data-file" => "srv/archivo.php?id=$htmlEncodeArchId"]
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
