<?php
/**
 * Recupera un valor enviado al
 * servicio por medio de GET, POST
 * o cookie.
 */
function leeValor(
 string $nombre
): string {
 $valor =
  isset($_REQUEST[$nombre])
  ? $_REQUEST[$nombre]
  : "";
 return $valor;
}
