<?php
require_once __DIR__ .
 "/../lib/php/Servicio.php";
require_once __DIR__ .
 "/../lib/php/leeValor.php";

class SrvProcesa extends Servicio
{
 protected
 function implementacion()
 {
  $nombre = leeValor("nombre");
  if ($nombre === "") {
   throw new Exception(
    "Falta el nombre"
   );
  }
  $resultado = "Hola {$nombre}";
  return [
   "resultado" => $resultado
  ];
 }
}

$servicio = new SrvProcesa();
$servicio->ejecuta();
