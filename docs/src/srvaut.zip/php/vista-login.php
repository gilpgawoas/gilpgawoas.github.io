<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/protegeLogin.php";

list($san) = protegeLogin([]);

devuelveJson([
 "ocupado" => ["hidden" => true],
 "formulario" => ["hidden" =>  false],
]);
