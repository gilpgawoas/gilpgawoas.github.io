<?php

require_once __DIR__ . "/lib/NO_AUTORIZADO.php";
require_once __DIR__ . "/lib/ProblemDetailsException.php";
require_once __DIR__ . "/protege.php";

function protegeLogin(array $rolIdsPermitidos)
{

 list($san, $rolIds, $usuId) = protege($rolIdsPermitidos);

 if ($san !== "")
  throw new ProblemDetailsException([
   "status" => NO_AUTORIZADO,
   "type" => "/errors/sesioniniciada.html",
   "title" => "Sesión iniciada.",
   "detail" => "La sesión ya está iniciada.",
  ]);

 return [$san, $rolIds, $usuId];
}
