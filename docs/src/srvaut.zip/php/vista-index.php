<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/protege.php";
require_once __DIR__ . "/lib/devuelveJson.php";
require_once __DIR__ . "/jsonMiNav.php";

list($san, $rolIds) = protege([]);

devuelveJson(jsonMiNav($san, $rolIds));
