export const ROL_ID_ADMINISTRADOR = "Administrador"

// Permite que los eventos de html usen la constante.
window["ROL_ID_ADMINISTRADOR"] = ROL_ID_ADMINISTRADOR