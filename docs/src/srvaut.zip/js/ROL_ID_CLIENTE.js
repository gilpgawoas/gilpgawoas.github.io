export const ROL_ID_CLIENTE = "Cliente"

// Permite que los eventos de html usen la constante.
window["ROL_ID_CLIENTE"] = ROL_ID_CLIENTE