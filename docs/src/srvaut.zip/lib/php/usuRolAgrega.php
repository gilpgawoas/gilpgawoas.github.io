<?php

function usuRolAgrega(PDO $conexion, int $usuId, array $rolIds)
{
 if (sizeof($rolIds) > 0) {
  $insert = $conexion->prepare(
   "INSERT INTO USU_ROL
     (USU_ID, ROL_ID)
    VALUES
     (:usuId, :rolId)"
  );
  foreach ($rolIds as $rolId) {
   $insert->execute(
    [
     ":usuId" => $usuId,
     ":rolId" => $rolId
    ]
   );
  }
 }
}
