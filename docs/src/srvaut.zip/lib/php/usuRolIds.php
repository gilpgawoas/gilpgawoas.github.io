<?php

require_once __DIR__ . "/fetchAll.php";

function usuRolIds(PDO $conexion, int $usuId)
{
 return fetchAll(
  $conexion->query(
   "SELECT
    ROL_ID
   FROM USU_ROL
   WHERE
    USU_ID = :usuId
   ORDER BY ROL_ID"
  ),
  [":usuId" => $usuId],
  PDO::FETCH_COLUMN
 );
}
