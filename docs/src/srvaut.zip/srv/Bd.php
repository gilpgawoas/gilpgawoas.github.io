<?php


require_once __DIR__ . "/ROL_ID_CLIENTE.php";
require_once __DIR__ . "/ROL_ID_ADMINISTRADOR.php";
require_once __DIR__ . "/../lib/php/usuRolAgrega.php";
class Bd
{

 private static ?PDO $conexion = null;

 static function getConexion(): PDO
 {
  if (self::$conexion === null) {

   self::$conexion = new PDO(
    // cadena de conexión
    "sqlite:srvaut.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: conexiones persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS USUARIO (
      USU_ID INTEGER,
      USU_CUE TEXT NOT NULL,
      USU_MATCH TEXT NOT NULL,
      CONSTRAINT USU_PK
       PRIMARY KEY(USU_ID),
      CONSTRAINT USU_CUE_UNQ
       UNIQUE(USU_CUE),
      CONSTRAINT USU_CUE_NV
       CHECK(LENGTH(USU_CUE) > 0)
     )'
   );
   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS ROL (
      ROL_ID TEXT NOT NULL,
      ROL_DESCRIPCION TEXT NOT NULL,
      CONSTRAINT ROL_PK
       PRIMARY KEY(ROL_ID),
      CONSTRAINT ROL_ID_NV
       CHECK(LENGTH(ROL_ID) > 0),
      CONSTRAINT ROL_DESCR_UNQ
       UNIQUE(ROL_DESCRIPCION),
      CONSTRAINT ROL_DESCR_NV
       CHECK(LENGTH(ROL_DESCRIPCION) > 0)
     )'
   );
   self::$conexion->exec(
    'CREATE TABLE IF NOT EXISTS USU_ROL (
       USU_ID INTEGER NOT NULL,
       ROL_ID TEXT NOT NULL,
       CONSTRAINT USU_ROL_PK
        PRIMARY KEY(USU_ID, ROL_ID),
       CONSTRAINT USU_ROL_USU_FK
        FOREIGN KEY (USU_ID) REFERENCES USUARIO(USU_ID),
       CONSTRAINT USU_ROL_ROL_FK
        FOREIGN KEY (ROL_ID) REFERENCES ROL(ROL_ID)
      )'
   );

   $insertRol = self::$conexion->prepare(
    "INSERT INTO ROL
      (ROL_ID, ROL_DESCRIPCION)
     VALUES
      (:id, :descripcion)"
   );

   $selectRol =
    self::$conexion->prepare("SELECT ROL_ID FROM ROL WHERE ROL_ID = :id");

   $selectRol->execute([":id" => ROL_ID_ADMINISTRADOR]);
   if ($selectRol->fetchColumn() === false) {
    $insertRol->execute([
     ":id" => ROL_ID_ADMINISTRADOR,
     ":descripcion" => "Administra el sistema."
    ]);
   }

   $selectRol->execute([":id" => ROL_ID_CLIENTE]);
   if ($selectRol->fetchColumn() === false) {
    $insertRol->execute([
     ":id" => ROL_ID_CLIENTE,
     ":descripcion" => "Realiza compras."
    ]);
   }

   $insertUsuario = self::$conexion->prepare(
    "INSERT INTO USUARIO
      (USU_CUE, USU_MATCH)
     VALUES
      (:cue, :match)"
   );

   $selectUsuario = self::$conexion->prepare(
    "SELECT USU_CUE FROM USUARIO WHERE USU_CUE = :cue"
   );

   $selectUsuario->execute([":cue" => "pepito"]);
   if ($selectUsuario->fetchColumn() === false) {
    $insertUsuario->execute([
     ":cue" => "pepito",
     ":match" => password_hash("cuentos", PASSWORD_DEFAULT)
    ]);
    /* Recupera el id generado. Si usas una secuencia, pasa como
     * parámetro de lastInsertId el nombre de dicha secuencia y
     * poner esta instrucción antes del INSERT, al cual se le
     * pasarle el id generado. */
    $usuId = self::$conexion->lastInsertId();
    usuRolAgrega(self::$conexion, $usuId, [ROL_ID_CLIENTE]);
   }

   $selectUsuario->execute([":cue" => "susana"]);
   if ($selectUsuario->fetchColumn() === false) {
    $insertUsuario->execute([
     ":cue" => "susana",
     ":match" => password_hash("alegria", PASSWORD_DEFAULT)
    ]);
    $usuId = self::$conexion->lastInsertId();
    usuRolAgrega(self::$conexion, $usuId, [ROL_ID_ADMINISTRADOR]);
   }

   $selectUsuario->execute([":cue" => "bebe"]);
   if ($selectUsuario->fetchColumn() === false) {
    $insertUsuario->execute([
     ":cue" => "bebe",
     ":match" => password_hash("saurio", PASSWORD_DEFAULT)
    ]);
    $usuId = self::$conexion->lastInsertId();
    usuRolAgrega(
     self::$conexion,
     $usuId,
     [ROL_ID_ADMINISTRADOR, ROL_ID_CLIENTE]
    );
   }
  }

  return self::$conexion;
 }
}
