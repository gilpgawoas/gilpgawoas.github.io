<?php

const NOT_FOUND = 404;
