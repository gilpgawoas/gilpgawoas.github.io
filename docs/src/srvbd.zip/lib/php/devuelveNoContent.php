<?php

function devuelveNoContent()
{
 http_response_code(204);
}
