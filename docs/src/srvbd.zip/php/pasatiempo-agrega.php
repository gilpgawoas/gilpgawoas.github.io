<?php

require_once __DIR__ . "/lib/manejaErrores.php";
require_once __DIR__ . "/lib/recibeTextoObligatorio.php";
require_once __DIR__ . "/lib/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";

$nombre = recibeTextoObligatorio("nombre");

$bd = Bd::pdo();
$stmt = $bd->prepare(
 "INSERT INTO PASATIEMPO (
    PAS_NOMBRE
   ) values (
    :PAS_NOMBRE
   )"
);
$stmt->execute([
 ":PAS_NOMBRE" => $nombre
]);
$id = $bd->lastInsertId();

$encodeId = urlencode($id);
devuelveCreated(
 "/php/pasatiempo-vista-modifica.php?id=$encodeId",
 [
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
 ]
);
