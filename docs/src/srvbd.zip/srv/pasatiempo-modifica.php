<?php

require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $id = recuperaIdEntero("id");
 $nombre = recuperaTexto("nombre");

 $nombre = validaNombre($nombre);

 $conexion = Bd::getConexion();
 $conexion->prepare(
  "UPDATE PASATIEMPO
    SET PAS_NOMBRE = :nombre
    WHERE PAS_ID = :id"
 )
  ->execute([
   ":id" => $id,
   ":nombre" => $nombre
  ]);

 devuelveJson([
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
