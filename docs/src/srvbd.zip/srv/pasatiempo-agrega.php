<?php

require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/validaNombre.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $nombre = recuperaTexto("nombre");

 $nombre = validaNombre($nombre);

 $conexion = Bd::getConexion();
 $conexion->prepare(
  "INSERT INTO PASATIEMPO
    (PAS_NOMBRE)
   VALUES
    (:nombre)"
 )
  ->execute([":nombre" => $nombre]);

 /* Recupera el id generado. Si usas una secuencia, pasa como
  * parámetro de lastInsertId el nombre de dicha secuencia y
  * poner esta instrucción antes del INSERT, al cual se le
  * pasarle el id generado. */
 $id = $conexion->lastInsertId();
 $encodeId = urlencode($id);

 devuelveCreated("/srv/pasatiempo.php?id=$encodeId", [
  "id" => ["value" => $id],
  "nombre" => ["value" => $nombre],
 ]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
