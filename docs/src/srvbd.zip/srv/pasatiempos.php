<?php

require_once __DIR__ . "/../lib/php/fetchAll.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/../lib/php/ProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveProblemDetails.php";
require_once __DIR__ . "/../lib/php/devuelveErrorInterno.php";
require_once __DIR__ . "/Bd.php";

try {

 $conexionexion = Bd::getConexion();
 $lista = fetchAll($conexionexion->query(
  "SELECT
    PAS_ID AS id,
    PAS_NOMBRE AS nombre
   FROM PASATIEMPO
   ORDER BY PAS_NOMBRE"
 ));

 $render = "";
 foreach ($lista as $modelo) {
  $encodeId = urlencode($modelo->id);
  $id = htmlentities($encodeId);
  $nombre = htmlentities($modelo->nombre);
  $render .=
   "<li>
     <p>
      <a href='modifica.html?id=$id'>$nombre</a>
     </p>
    </li>";
 }

 devuelveJson(["lista" => ["innerHTML" => $render]]);
} catch (ProblemDetails $details) {

 devuelveProblemDetails($details);
} catch (Throwable $error) {

 devuelveErrorInterno($error);
}
