<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";

use \lib\php\Servicio;

class SrvLista extends Servicio
{
 protected
 function implementacion()
 {
  $lista = [
   [
    "nombre" => "pp",
    "color" => "azul"
   ],
   [
    "nombre" => "kq",
    "color" => "rojo"
   ],
   [
    "nombre" => "tt",
    "color" => "rosa"
   ],
   [
    "nombre" => "bb",
    "color" => "azul"
   ]
  ];
  return $lista;
 }
}

$servicio = new SrvLista();
$servicio->ejecuta();
