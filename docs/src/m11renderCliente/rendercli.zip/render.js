/* Ejemplo de render en el cliente
 * no se usa import porque Firefox
 * no lo soporta en los webworkers.
 */

/**
 * Literales de objeto que llevan
 * los campos nombre y color.
 * @typedef {Object} Elemento
 * @property {string} nombre
 * @property {string} color
 */

const render = generaHtmlDeLista([
 {
  nombre: "Pepe",
  color: "azul"
 },
 {
  nombre: "Cuca",
  color: "rojo"
 },
 {
  nombre: "Teté",
  color: "rosa"
 },
 {
  nombre: "Bebé",
  color: "azul"
 }])
enviaALaPagina(render)
/* Espera 5 segundos e invoca la
 * función lista. */
setTimeout(lista, 5000)

async function lista() {
 const lista = await ejecuta(
  fetch("srv/SrvLista.php"))
 const render =
  generaHtmlDeLista(lista)
 enviaALaPagina(render)
}

/**
 * Genera el HTML para mostrar el
 * contenido de la lista
 * @param {Elemento[]} lista
 */
function generaHtmlDeLista(lista) {
 let render = ""
 for (const modelo of lista) {
  const nombre =
   htmlentities(modelo.nombre)
  const color =
   htmlentities(modelo.color)
  render += /* html */
   `<li>
     <p>
      <strong>${nombre}</strong>
      <br>${color}
     </p>
    </li>`
 }
 return render
}

/** @param {string} render */
function enviaALaPagina(render) {
 /* Verifica si el código corre
  * dentro de un web worker. */
 if (self
  instanceof WorkerGlobalScope) {
  /* Envía el render a la página
   * que invocó este web worker.*/
  self.postMessage(render)
 }
}

/**
 * @param {Promise<Response>} fetch
 * @returns {Promise<any>}
 */
async function ejecuta(fetch) {
 const resp = await fetch
 if (resp.ok) {
  return await resp.json()
 } else if (resp.status === 500) {
  throw new Error(
   await resp.text())
 } else {
  throw new Error(resp.statusText)
 }
}

/**
 * Codifica un texto para que
 * cambie los caracteres
 * especiales y no se pueda
 * interpretar como HTML. Esta
 * técnica evita la inyección de
 * código.
 * @param {string} texto
 * @returns {string} un texto que
 *  no puede interpretarse como
 *  HTML.
 */
function htmlentities(texto) {
 return texto.
  replace(/[<>"']/g, reemplaza)
}

/**
 * Devuelve una cadena de reemplazo
 * para evitar que el texto se
 * interprete como HTML. 
 * @param {string} texto
 */
function reemplaza(texto) {
 switch (texto) {
  case "<": return "&lt;"
  case ">": return "&gt;"
  case '"': return "&quot;"
  case "'": return "&#039;"
  default: return texto
 }
}