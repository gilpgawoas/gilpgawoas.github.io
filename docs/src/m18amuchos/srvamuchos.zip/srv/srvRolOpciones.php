<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/dao/rolConsulta.php";

ejecuta(function () {
 $lista = rolConsulta();
 $render = "";
 foreach ($lista as $modelo) {
  $id = htmlentities($modelo->id);
  $descripcion = htmlentities($modelo->descripcion);
  $render .=
   "<p>
     <label style='display: flex'>
      <input type='checkbox' name='rolIds[]' value='$id'>
      <span>
       <strong>{$id}</strong>
       <br>{$descripcion}
      </span>
     </label>
    </p>";
 }
 return $render;
});
