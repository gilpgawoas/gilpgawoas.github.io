<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/dao/usuarioConsulta.php";

ejecuta(function () {
 $lista = usuarioConsulta();
 $render = "";
 foreach ($lista as $modelo) {
  $usuId = htmlentities($modelo->usuId);
  $usuCue = htmlentities($modelo->usuCue);
  $roles = $modelo->roles === null || $modelo->roles === ""
   ? "<em>-- Sin roles --</em>"
   : htmlentities($modelo->roles);
  $render .=
   "<dt><a href='modifica.html?id=$usuId'>{$usuCue}</a></dt>
    <dd><a href='modifica.html?id=$usuId'>{$roles}</a></dd>";
 }
 return $render;
});
