<?php

require_once __DIR__ . "/../modelo/Rol.php";
require_once __DIR__ . "/bdCrea.php";
require_once __DIR__ . "/rolConsulta.php";
require_once __DIR__ . "/rolAgrega.php";

class AccesoBd
{

 private static ?PDO $con = null;

 static function getCon(): PDO
 {
  if (self::$con === null) {
   self::$con = self::conecta();
   self::prepara(self::$con);
  }
  return self::$con;
 }

 private static function conecta(): PDO
 {
  return new PDO(
   // cadena de conexión
   "sqlite:srvamuchos.db",
   // usuario
   null,
   // contraseña
   null,
   [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
  );
 }

 private static function prepara(PDO $con)
 {
  bdCrea($con);
  if (sizeof(rolConsulta()) === 0) {

   $administrador = new Rol(
    id: "Administrador",
    descripcion: "Administra el sistema."
   );
   rolAgrega($administrador);

   $cliente = new Rol(
    id: "Cliente",
    descripcion: "Realiza compras."
   );
   rolAgrega($cliente);
  }
 }
}
