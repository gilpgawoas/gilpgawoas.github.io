<?php

 require_once __DIR__ . "/../modelo/Usuario.php";
 require_once __DIR__ . "/AccesoBd.php";
 require_once __DIR__ . "/usuRolAgrega.php";
 require_once __DIR__ . "/usuRolElimina.php";
 
function usuarioModifica(Usuario $modelo) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 $stmt = $con->prepare(
  "UPDATE USUARIO
   SET USU_CUE = :cue
   WHERE USU_ID = :id"
 );
 $stmt->execute([
  ":id" => $modelo->id,
  ":cue" => $modelo->cue
 ]);
 usuRolElimina($modelo->id);
 usuRolAgrega($modelo);
 $con->commit();
}
