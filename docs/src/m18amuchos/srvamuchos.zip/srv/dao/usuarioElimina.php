<?php

require_once __DIR__ . "/AccesoBd.php";
require_once __DIR__ . "/usuRolElimina.php";

function usuarioElimina(int $id)
{
 $con = AccesoBd::getCon();
 usuRolElimina($id);
 $stmt = $con->prepare(
  "DELETE FROM USUARIO
   WHERE USU_ID = :id"
 );
 $stmt->execute([":id" => $id]);
}
