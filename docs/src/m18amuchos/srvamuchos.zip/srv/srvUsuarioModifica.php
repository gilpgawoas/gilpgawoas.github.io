<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeArray.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/modelo/Usuario.php";
require_once __DIR__ . "/dao/usuarioModifica.php";

ejecuta(function () {
 $id = leeEntero("id");
 if ($id === null)
  throw new Exception("Falta el id.");
 $cue = trim(leeTexto("cue"));
 $rolIds = leeArray("rolIds");
 /** @var Rol[] $roles */
 $roles = [];
 foreach ($rolIds as $rolId) {
  $roles[] = new Rol(id: $rolId);
 }
 $usuario = new Usuario(cue: $cue, roles: $roles, id: $id);
 usuarioModifica($usuario);
 return $usuario;
});
