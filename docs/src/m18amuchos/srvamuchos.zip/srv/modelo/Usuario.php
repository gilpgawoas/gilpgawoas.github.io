<?php


require_once __DIR__ . "/Rol.php";

class Usuario
{

 public int $id;
 public string $cue;
 /** @var Rol[] */
 public array $roles;

 public function __construct(
  string $cue = "",
  array $roles = [],
  int $id = 0
 ) {
  $this->id = $id;
  $this->cue = $cue;
  $this->roles = $roles;
 }

 public function valida()
 {
  if ($this->cue === "")
   throw new Exception("Falta el cue.");
  foreach ($this->roles as $rol) {
   if (!($rol instanceof Rol))
    throw new Exception("Tipo incorrecto para un rol.");
  }
 }
}
