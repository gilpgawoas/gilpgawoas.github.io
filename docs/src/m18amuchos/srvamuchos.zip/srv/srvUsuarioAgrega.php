<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeArray.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";
require_once __DIR__ . "/modelo/Rol.php";
require_once __DIR__ . "/dao/usuarioAgrega.php";

ejecuta(function () {
 $cue = trim(leeTexto("cue"));
 $rolIds = leeArray("rolIds");
 /** @var Rol[] $roles */
 $roles = [];
 foreach ($rolIds as $rolId) {
  $roles[] = new Rol(id: $rolId);
 }
 $usuario = new Usuario(cue: $cue, roles: $roles);
 usuarioAgrega($usuario);
 return $usuario;
});
