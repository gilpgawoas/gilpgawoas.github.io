<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/dao/usuarioBusca.php";

ejecuta(function () {
 $id = leeEntero("id");
 if ($id === null)
  throw new Exception("Falta el parámetro id.");
 $modelo = usuarioBusca($id);
 if ($modelo === false) {
  throw new Exception("Usuario no encontrado.");
 }
 $rolIds = [];
 foreach ($modelo->roles as $rol) {
  $rolIds[] = $rol->id;
 }
 return [
  "id" => $modelo->id,
  "cue" => $modelo->cue,
  "rolIds[]" => $rolIds
 ];
});
