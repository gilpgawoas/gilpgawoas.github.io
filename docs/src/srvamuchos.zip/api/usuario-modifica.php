<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeTextoObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeArray.php";
require_once __DIR__ . "/../libservidorphp/usuRolAgrega.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/usuRolElimina.php";
require_once __DIR__ . "/rolCheckboxes.php";

$usuId = recibeEnteroObligatorio("id");
$san = recibeTextoObligatorio("san");
$rolIds = recibeArray("rolIds");

$bd = Bd::conexion();
$bd->beginTransaction();

$stmt = $bd->prepare(
 "UPDATE USUARIO
   SET
    USU_SAN = TRIM(:USU_SAN)
   WHERE
    USU_ID = :USU_ID"
);
$stmt->execute([
 ":USU_SAN" => $san,
 ":USU_ID" => $usuId,
]);

usuRolElimina($bd, $usuId);
usuRolAgrega($bd, $usuId, $rolIds);

$bd->commit();

devuelveJson([
 "id" => ["value" => $usuId],
 "san" => ["value" => $san],
 "roles" => ["innerHTML" =>  rolCheckboxes()],
 "rolIds" => ["value" => $rolIds],
]);
