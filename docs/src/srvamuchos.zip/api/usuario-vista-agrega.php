<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/rolCheckboxes.php";

devuelveJson(["roles" => ["innerHTML" =>  rolCheckboxes()]]);
