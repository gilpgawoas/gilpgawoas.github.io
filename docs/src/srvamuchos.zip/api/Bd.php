<?php

require_once __DIR__ . "/../libservidorphp/rolBusca.php";
require_once __DIR__ . "/../libservidorphp/rolAgrega.php";

class Bd
{

 private static ?PDO $pdo = null;

 static function conexion(): PDO
 {
  if (self::$pdo === null) {

   self::$pdo = new PDO(
    // cadena de conexión
    "sqlite:" . __DIR__ . "/srvamuchos.db",
    // usuario
    null,
    // contraseña
    null,
    // Opciones: pdos no persistentes y lanza excepciones.
    [PDO::ATTR_PERSISTENT => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
   );

   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS USUARIO (
      USU_ID INTEGER,
      USU_SAN TEXT NOT NULL,
      CONSTRAINT PK_USU PRIMARY KEY(USU_ID),
      CONSTRAINT UQ_USU_SAN UNIQUE(USU_SAN),
      CONSTRAINT CHK_USU_SAN CHECK(LENGTH(USU_SAN) > 0)
     )'
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS ROL (
      ROL_ID TEXT NOT NULL,
      ROL_DESCRIPCION TEXT NOT NULL,
      CONSTRAINT PK_ROL PRIMARY KEY(ROL_ID),
      CONSTRAINT CHK_ROL_ID CHECK(LENGTH(ROL_ID) > 0),
      CONSTRAINT UQ_ROL_DESCR UNIQUE(ROL_DESCRIPCION),
      CONSTRAINT CHK_ROL_DESCR CHECK(LENGTH(ROL_DESCRIPCION) > 0)
     )'
   );
   self::$pdo->exec(
    'CREATE TABLE IF NOT EXISTS USU_ROL (
      UR_USU_ID INTEGER NOT NULL,
      UR_ROL_ID TEXT NOT NULL,
      CONSTRAINT PK_USU_ROL PRIMARY KEY(UR_USU_ID, UR_ROL_ID),
      CONSTRAINT FK_UR_USU FOREIGN KEY (UR_USU_ID) REFERENCES USUARIO(USU_ID),
      CONSTRAINT FK_UR_ROL FOREIGN KEY (UR_ROL_ID) REFERENCES ROL(ROL_ID)
     )'
   );

   self::$pdo->beginTransaction();

   $rolAdministrador = rolBusca(self::$pdo, "Administrador");
   $rolAdministrador = rolBusca(self::$pdo, "Cliente");

   if ($rolAdministrador === false) {
    rolAgrega(
     bd: self::$pdo,
     id: "Administrador",
     descripcion: "Administra el sistema."
    );
   }

   if (rolBusca(self::$pdo, "Cliente") === false) {
    rolAgrega(
     bd: self::$pdo,
     id: "Cliente",
     descripcion: "Realiza compras."
    );
   }

   self::$pdo->commit();
  }

  return self::$pdo;
 }
}
