<?php

function usuRolElimina(\PDO $bd, string $usuId)
{
 $usuRolElimina =
  $bd->prepare("DELETE FROM USU_ROL WHERE UR_USU_ID = :UR_USU_ID");
 $usuRolElimina->execute([":UR_USU_ID" => $usuId]);
}
