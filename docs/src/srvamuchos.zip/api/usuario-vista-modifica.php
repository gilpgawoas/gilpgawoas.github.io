<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeEnteroObligatorio.php";
require_once __DIR__ . "/../libservidorphp/validaEntidadObligatoria.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/../libservidorphp/rolIdsParaUsuId.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/rolCheckboxes.php";

$usuId = recibeEnteroObligatorio("id");

$bd = Bd::conexion();

$stmt = $bd->prepare("SELECT * FROM USUARIO WHERE USU_ID = :USU_ID");
$stmt->execute([":USU_ID" => $usuId]);
$modelo = $stmt->fetch(PDO::FETCH_ASSOC);

$modelo = validaEntidadObligatoria("Usuario",  $modelo);

$rolIds = rolIdsParaUsuId(Bd::conexion(), $usuId);

devuelveJson([
 "id" => ["value" => $usuId],
 "san" => ["value" => $modelo["USU_SAN"]],
 "roles" => ["innerHTML" =>  rolCheckboxes()],
 "rolIds[]" => $rolIds
]);
