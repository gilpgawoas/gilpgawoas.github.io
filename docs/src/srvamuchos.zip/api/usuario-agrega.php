<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/recibeTextoObligatorio.php";
require_once __DIR__ . "/../libservidorphp/recibeArray.php";
require_once __DIR__ . "/../libservidorphp/usuRolAgrega.php";
require_once __DIR__ . "/../libservidorphp/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";
require_once __DIR__ . "/rolCheckboxes.php";

$san = recibeTextoObligatorio("san");
$rolIds = recibeArray("rolIds");

$bd = Bd::conexion();
$bd->beginTransaction();

$stmt = $bd->prepare(
 "INSERT INTO USUARIO (
    USU_SAN
   ) values (
    TRIM(:USU_SAN)
   )"
);
$stmt->execute([
 ":USU_SAN" => $san
]);
$usuId = $bd->lastInsertId();

usuRolAgrega($bd, $usuId, $rolIds);

$bd->commit();

$encodeUsuId = urlencode($usuId);
$query = http_build_query(["id" => $usuId]);
devuelveCreated("/api/usuario-vista-modifica.php?$query", [
 "id" => ["value" => $usuId],
 "san" => ["value" => $san],
 "roles" => ["innerHTML" =>  rolCheckboxes()],
 "rolIds[]" => ["value" => $rolIds],
]);
