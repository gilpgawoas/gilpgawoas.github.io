<?php

require_once __DIR__ . "/../libservidorphp/manejaErrores.php";
require_once __DIR__ . "/../libservidorphp/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

$bd = Bd::conexion();
$stmt = $bd->query(
 "SELECT
    U.USU_ID,
    U.USU_SAN,
    GROUP_CONCAT(UR.UR_ROL_ID, ', ') AS roles
   FROM
    USUARIO U LEFT JOIN USU_ROL UR
     ON U.USU_ID = UR.UR_USU_ID
   GROUP BY
    U.USU_SAN
   ORDER BY
    U.USU_SAN"
);
$lista = $stmt->fetchAll(PDO::FETCH_ASSOC);

$render = "";
foreach ($lista as $modelo) {
 $usuId = $modelo["USU_ID"];
 $query = htmlentities(http_build_query(["id" => $usuId]));
 $urlModifica = "modifica.html?$query";
 $usuSan = htmlentities($modelo["USU_SAN"]);
 $roles = $modelo["roles"] === null || $modelo["roles"] === ""
  ? "<em>-- Sin roles --</em>"
  : htmlentities($modelo["roles"]);
 $render .=
  "<dt><a href='$urlModifica'>$usuSan</a></dt>
   <dd><a href='$urlModifica'>$roles</a></dd>";
}

devuelveJson(["lista" => ["innerHTML" => $render]]);
