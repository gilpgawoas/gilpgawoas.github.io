<?php

function rolIdsParaUsuId(\PDO $bd, int $usuId)
{
 $stmt = $bd->prepare(
  "SELECT UR_ROL_ID
   FROM USU_ROL
   WHERE UR_USU_ID = :UR_USU_ID
   ORDER BY UR_ROL_ID"
 );
 $stmt->execute([":UR_USU_ID" => $usuId]);
 $rolIds = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
 return $rolIds;
}
