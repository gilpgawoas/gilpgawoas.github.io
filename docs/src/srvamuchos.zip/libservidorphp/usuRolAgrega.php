<?php

function usuRolAgrega(\PDO $bd, string $usuId, array $rolIds)
{
 $usuRolAgrega = $bd->prepare(
  "INSERT INTO USU_ROL (
    UR_USU_ID, UR_ROL_ID
   ) values (
    :UR_USU_ID, TRIM(:UR_ROL_ID)
   )"
 );
 foreach ($rolIds as $rolId) {
  $usuRolAgrega->execute([
   ":UR_USU_ID" => $usuId,
   ":UR_ROL_ID" => $rolId,
  ]);
 }
}
