<?php

require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/recuperaIdEntero.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaArray.php";
require_once __DIR__ . "/../lib/php/validaCue.php";
require_once __DIR__ . "/../lib/php/update.php";
require_once __DIR__ . "/../lib/php/delete.php";
require_once __DIR__ . "/../lib/php/insertBridges.php";
require_once __DIR__ . "/../lib/php/devuelveJson.php";
require_once __DIR__ . "/Bd.php";

ejecutaServicio(function () {

 $usuId = recuperaIdEntero("id");
 $cue = recuperaTexto("cue");
 $rolIds = recuperaArray("rolIds");

 $cue = validaCue($cue);

 $pdo = Bd::pdo();
 $pdo->beginTransaction();

 update(
  pdo: $pdo,
  table: USUARIO,
  set: [USU_CUE => $cue],
  where: [USU_ID => $usuId]
 );
 delete(pdo: $pdo, from: USU_ROL, where: [USU_ID => $usuId]);
 insertBridges(
  pdo: $pdo,
  into: USU_ROL,
  valuesDePadre: [USU_ID => $usuId],
  valueDeHijos: [ROL_ID => $rolIds]
 );

 $pdo->commit();

 devuelveJson([
  "id" => ["value" => $usuId],
  "cue" => ["value" => $cue],
  "rolIds" => ["value" => $rolIds],
 ]);
});
