<?php

require_once __DIR__ . "/../lib/php/ejecutaServicio.php";
require_once __DIR__ . "/../lib/php/recuperaTexto.php";
require_once __DIR__ . "/../lib/php/recuperaArray.php";
require_once __DIR__ . "/../lib/php/validaCue.php";
require_once __DIR__ . "/../lib/php/insert.php";
require_once __DIR__ . "/../lib/php/insertBridges.php";
require_once __DIR__ . "/../lib/php/devuelveCreated.php";
require_once __DIR__ . "/Bd.php";

ejecutaServicio(function () {

 $cue = recuperaTexto("cue");
 $rolIds = recuperaArray("rolIds");

 $cue = validaCue($cue);

 $pdo = Bd::pdo();
 $pdo->beginTransaction();

 insert(pdo: $pdo, into: USUARIO, values: [USU_CUE => $cue]);
 $usuId = $pdo->lastInsertId();
 insertBridges(
  pdo: $pdo,
  into: USU_ROL,
  valuesDePadre: [USU_ID => $usuId],
  valueDeHijos: [ROL_ID => $rolIds]
 );

 $pdo->commit();

 $encodeUsuId = urlencode($usuId);
 devuelveCreated("/srv/usuario.php?id=$encodeUsuId", [
  "id" => ["value" => $usuId],
  "cue" => ["value" => $cue],
  "rolIds" => ["value" => $rolIds],
 ]);
});
