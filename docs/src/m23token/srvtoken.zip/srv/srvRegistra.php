<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/creaToken.php";
require_once __DIR__ . "/../lib/php/leeTexto.php";

ejecuta(function () {
 session_start();
 // Crea un token pa la página "formulario" que expira en 5 minutos.
 return creaToken("formulario", 5);
});
