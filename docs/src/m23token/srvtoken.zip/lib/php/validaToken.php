<?php

function validaToken(string $pagina, string $token)
{

 if (!isset($_SESSION[$pagina]))
  throw new Exception("Página $pagina no registrada.");

 $tokensParaPagina = $_SESSION[$pagina];

 if (!is_array($tokensParaPagina))
  throw new Exception("No hay arereglo de tokens.");

 $hallado = false;

 // Valida que el token se haya registrado.
 foreach ($tokensParaPagina as $llave => $tokenParaPagina) {

  if (strcmp($token, $tokenParaPagina["texto"]) === 0) {

   if ($tokenParaPagina["expiracion"] < time()) {
    unset($tokensParaPagina[$llave]);
    $_SESSION[$pagina] = $tokensParaPagina;
    throw new Exception("Tiempo de expiración excedido.");
   }

   $hallado = true;
  } elseif ($tokenParaPagina["expiracion"] > time()) {

   // Elimina tokens expirados
   unset($tokensParaPagina[$llave]);
  }
 }

 $_SESSION[$pagina] = $tokensParaPagina;

 if ($hallado === false)
  throw new Exception("No autorizado");
}
