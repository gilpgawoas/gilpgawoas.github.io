<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/../lib/php/leeEntero.php";
require_once __DIR__ . "/dao/amigoBusca.php";

ejecuta(function () {
 $id = leeEntero("id");
 if ($id === null)
  throw new Exception("Falta el parámetro id.");
 $modelo = amigoBusca($id);
 if ($modelo === false) {
  throw new Exception("Amigo no encontrado.");
 } else {
  $pasatiempo = $modelo->pasatiempo;
  return [
   "id" => $modelo->id,
   "nombre" => $modelo->nombre,
   "pasId" => $pasatiempo === null ? null : $pasatiempo->id
  ];
 }
});
