<?php

class Amigo
{

 public int $id;
 public string $nombre;
 public ?Pasatiempo $pasatiempo;

 public function __construct(
  string $nombre = "",
  ?Pasatiempo $pasatiempo = null,
  int $id = 0
 ) {
  $this->id = $id;
  $this->nombre = $nombre;
  $this->pasatiempo = $pasatiempo;
 }

 public function valida()
 {
  if ($this->nombre === "")
   throw new Exception("Faltala el nombre.");
 }
}
