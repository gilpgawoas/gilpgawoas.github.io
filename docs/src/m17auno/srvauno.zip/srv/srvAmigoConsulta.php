<?php

require_once __DIR__ . "/../lib/php/ejecuta.php";
require_once __DIR__ . "/dao/amigoConsulta.php";

ejecuta(function () {
 $lista = amigoConsulta();
 $render = "";
 foreach ($lista as $modelo) {
  $amiId = htmlentities($modelo->amiId);
  $amiNombre = htmlentities($modelo->amiNombre);
  $pasNombre = $modelo->pasNombre === null
   ? "<em>-- Sin pasatiempo --</em>"
   : htmlentities($modelo->pasNombre);
  $render .=
   "<dt><a href='modifica.html?id=$amiId'>{$amiNombre}</a></dt>
    <dd><a href='modifica.html?id=$amiId'>{$pasNombre}</a></dd>";
 }
 return $render;
});
