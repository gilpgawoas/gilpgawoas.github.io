<?php

require_once __DIR__ . "/../../lib/php/recibeFetchAll.php";
require_once __DIR__ . "/AccesoBd.php";

function amigoConsulta()
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
    A.AMI_ID AS amiId,
    A.AMI_NOMBRE AS amiNombre,
    P.PAS_NOMBRE AS pasNombre
   FROM AMIGO A
    LEFT JOIN PASATIEMPO P
    ON A.PAS_ID = P.PAS_ID
   ORDER BY A.AMI_NOMBRE"
 );
 $resultado = $stmt->fetchAll(PDO::FETCH_OBJ);
 return recibeFetchAll($resultado);
}
