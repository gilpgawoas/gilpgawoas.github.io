<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";

use \lib\php\Servicio;

class SrvError extends Servicio
{

 protected
 function implementacion()
 {
  throw new Exception("Ouch");
 }
}

$servicio = new SrvError();
$servicio->ejecuta();
