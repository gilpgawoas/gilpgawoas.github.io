export class
 CampoSubeImagenObligatorio
 extends HTMLElement {

 connectedCallback() {
  this.innerHTML = /* HTML */
   `<p>
     <label>
      Imagen *
      <input name="bytes" required
        type="file">
     </label>
    </p>`
 }

}

customElements.define(
 "campo-sube-magen-obligatorio",
 CampoSubeImagenObligatorio)