<?php

use srv\dao\AccesoBd;
use srv\modelo\Archivo;
use srv\modelo\Producto;

function productoBusca(int $prodId)
{
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    P.PROD_ID AS prodId,
    P.PROD_NOMBRE AS prodNombre,
    A.ARCH_ID AS archId
   FROM PRODUCTO P
    LEFT JOIN ARCHIVO A
    ON P.ARCH_ID = A.ARCH_ID
   WHERE P.PROD_ID = :prodId"
 );
 $stmt->execute([
  ":prodId" => $prodId
 ]);
 $stmt->setFetchMode(
  PDO::FETCH_OBJ
 );
 $obj = $stmt->fetch();
 if ($obj === false) {
  return false;
 } else {
  $producto = new Producto();
  $producto->id = $obj->prodId;
  $producto->nombre =
   $obj->prodNombre;

  if ($obj->archId === null) {
   $producto->archivo = null;
  } else {
   $archivo = new Archivo();
   $archivo->id = $obj->archId;
   $archivo->bytes = "";
   $producto->archivo = $archivo;
  }
  return $producto;
 }
}
