<?php

require_once
 "srv/dao/archivoElimina.php";
require_once
 "srv/dao/productoBusca.php";

use srv\dao\AccesoBd;

function productoElimina(int $id)
{
 $con = AccesoBd::getCon();
 $con->beginTransaction();
 $modelo = productoBusca($id);
 if ($modelo !== false) {
  archivoElimina(
   $modelo->archivo->id
  );
  $stmt = $con->prepare(
   "DELETE FROM PRODUCTO
   WHERE PROD_ID = :id"
  );
  $stmt->execute([
   ":id" => $modelo->id
  ]);
  $con->commit();
 } else {
  $con->rollBack();
 }
}
