<?php

require_once __DIR__ .
 "/../lib/php/autoload.php";
require_once
 "srv/dao/productoModifica.php";
require_once
 "lib/php/leeEntero.php";
require_once "lib/php/" .
 "leeSinEspaciosInFin.php";
require_once
 "lib/php/leeBytes.php";

use \lib\php\Servicio;
use \srv\modelo\Archivo;
use \srv\modelo\Producto;

class SrvProductoModifica
extends Servicio
{

 protected
 function implementacion()
 {
  $modelo = new Producto();
  $modelo->id = leeEntero("id");
  $modelo->nombre =
   leeSinEspaciosInFin("nombre");
  $bytes = leeBytes("bytes");
  if ($bytes === "") {
   $modelo->archivo = null;
  } else {
   $archivo = new Archivo();
   $archivo->bytes = $bytes;
   $modelo->archivo = $archivo;
  }
  productoModifica($modelo);
  /* Los bytes se daescargan con
   * SrvArchivo. */
  $archivo->bytes = "";
  return $modelo;
 }
}

$servicio =
 new SrvProductoModifica();
$servicio->ejecuta();
