<?php

function txtFaltaElArchivo()
{
 return "Falta el archivo.";
}
