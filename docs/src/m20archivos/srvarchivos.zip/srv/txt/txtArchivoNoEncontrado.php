<?php

function txtArchivoNoEncontrado()
{
 return "Archivo no encontrado.";
}
