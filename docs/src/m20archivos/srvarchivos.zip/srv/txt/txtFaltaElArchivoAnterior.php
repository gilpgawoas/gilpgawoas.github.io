<?php

function
txtFaltaElArchivoAnterior()
{
 return
  "Falta el archivo anterior.";
}
