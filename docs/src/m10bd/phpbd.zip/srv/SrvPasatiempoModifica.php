<?php
require_once __DIR__ .
 "/dao/pasatiempoModifica.php";
require_once __DIR__ .
 "/modelo/Pasatiempo.php";
require_once __DIR__ .
 "/../lib/php/Servicio.php";
require_once __DIR__ .
 "/../lib/php/leeValor.php";

class SrvPasatiempoModifica
extends Servicio
{
 protected
 function implementacion()
 {
  $modelo = new Pasatiempo();
  $modelo->id = leeValor("id");
  $modelo->nombre =
   leeValor("nombre");
  pasatiempoModifica($modelo);
  return [];
 }
}

$servicio =
 new SrvPasatiempoModifica();
$servicio->ejecuta();
