<?php
function
txtPasatiempoNoEncontrado()
{
 return
  "Pasatiempo no encontrado.";
}
