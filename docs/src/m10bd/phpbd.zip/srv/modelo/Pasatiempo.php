<?php
require_once __DIR__ .
 "/../textos/txtFaltaElNombre.php";
require_once __DIR__ .
 "/../textos/txtFaltaElId.php";

class Pasatiempo
{
 public $id;
 public $nombre;
 public function valida()
 {
  if (
   $this->nombre === null
   || $this->nombre === ""
  ) {
   throw new Exception(
    txtFaltaElNombre()
   );
  }
 }
 public function validaCambio()
 {
  if (
   $this->id === null
   || $this->id === ""
  ) {
   throw new Exception(
    txtFaltaElId()
   );
  }
  if (
   $this->nombre === null
   || $this->nombre === ""
  ) {
   throw new Exception(
    txtFaltaElNombre()
   );
  }
 }
}
