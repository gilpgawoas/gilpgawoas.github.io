<?php
require_once __DIR__ .
 "/dao/pasatiempoBusca.php";
require_once __DIR__ .
 "/../lib/php/Servicio.php";
require_once __DIR__ .
 "/../lib/php/leeValor.php";
require_once __DIR__ .
 "/textos/txtFaltaElId.php";
require_once __DIR__ .
 "/textos/" .
 "txtPasatiempoNoEncontrado.php";

class SrvPasatiempoBusca
extends Servicio
{
 protected
 function implementacion()
 {
  $id = leeValor("id");
  $modelo = pasatiempoBusca($id);
  if ($modelo) {
   return $modelo;
  } else {
   throw new Exception(
    txtPasatiempoNoEncontrado()
   );
  }
 }
}

$servicio =
 new SrvPasatiempoBusca();
$servicio->ejecuta();
