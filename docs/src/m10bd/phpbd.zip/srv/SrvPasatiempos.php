<?php
require_once __DIR__ .
 "/dao/pasatiempoConsulta.php";
require_once __DIR__ .
 "/modelo/Pasatiempo.php";
require_once __DIR__ .
 "/../lib/php/Servicio.php";

class SrvPasatiempos
extends Servicio
{
 protected
 function implementacion()
 {
  $lista = pasatiempoConsulta();
  $render = "";
  foreach ($lista as $it) {
   $id = htmlentities($it->id);
   $nombre =
    htmlentities($it->nombre);
   $render .=
    "<a class='simple'
       href='modifica.html?id=$id'>
      <span class='primario'>
       {$nombre}
      </span>
     </a>";
  }
  return ["render" => $render];
 }
}

$servicio = new SrvPasatiempos();
$servicio->ejecuta();
