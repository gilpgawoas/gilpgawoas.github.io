<?php
require_once __DIR__ .
 "/../modelo/Pasatiempo.php";
require_once __DIR__ .
 "/AccesoBd.php";

function pasatiempoBusca(
 string $id
) {
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "SELECT
    PAS_ID as id,
    PAS_NOMBRE as nombre
   FROM PASATIEMPO
   WHERE PAS_ID = :id"
 );
 $stmt->execute([":id" => $id]);
 $stmt->setFetchMode(
  PDO::FETCH_CLASS,
  "Pasatiempo"
 );
 return $stmt->fetch();
}
