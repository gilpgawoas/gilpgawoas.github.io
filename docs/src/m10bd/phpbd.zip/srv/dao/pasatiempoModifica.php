<?php
require_once __DIR__ .
 "/../modelo/Pasatiempo.php";
require_once __DIR__ .
 "/AccesoBd.php";

function pasatiempoModifica(
 Pasatiempo $modelo
) {
 $modelo->validaCambio();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "UPDATE PASATIEMPO
    SET PAS_NOMBRE = :nombre
   WHERE
    PAS_ID = :id"
 );
 $stmt->execute([
  ":id" => $modelo->id,
  ":nombre" => $modelo->nombre
 ]);
}
