<?php
require_once __DIR__ .
 "/../modelo/Pasatiempo.php";
require_once __DIR__ .
 "/AccesoBd.php";

function pasatiempoAgrega(
 Pasatiempo $modelo
) {
 $modelo->valida();
 $con = AccesoBd::getCon();
 $stmt = $con->prepare(
  "INSERT INTO PASATIEMPO
    (PAS_NOMBRE)
   VALUES
    (:nombre)"
 );
 $stmt->execute([
  ":nombre" => $modelo->nombre
 ]);
}
