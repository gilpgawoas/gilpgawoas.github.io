<?php
require_once __DIR__ .
 "/../modelo/Pasatiempo.php";
require_once __DIR__ .
 "/AccesoBd.php";

function pasatiempoConsulta()
{
 $con = AccesoBd::getCon();
 $stmt = $con->query(
  "SELECT
    PAS_ID as id,
    PAS_NOMBRE as nombre
   FROM PASATIEMPO
   ORDER BY PAS_NOMBRE"
 );
 return $stmt->fetchAll(
  PDO::FETCH_CLASS,
  "Pasatiempo"
 );
}
