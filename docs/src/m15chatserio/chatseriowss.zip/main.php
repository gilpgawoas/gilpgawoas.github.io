<?php

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . "/ChatSerio.php";

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

$server = IoServer::factory(
 new HttpServer(
  new WsServer(
   new ChatSerio()
  )
 ),
 80
);

$server->run();
