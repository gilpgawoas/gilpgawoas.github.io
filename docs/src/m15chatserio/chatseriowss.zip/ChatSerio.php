<?php

use \SplObjectStorage;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

const ID = "id";
const CASTIGADO = "castigado";
const PERDONAME = "Perdóname";

class ChatSerio implements MessageComponentInterface
{
 private SplObjectStorage $conexionesDeClientes;
 private string $jsonCastigado;

 public function __construct()
 {
  // Crea una colección que se accesa usando objetos.
  $this->conexionesDeClientes = new SplObjectStorage;
  $info_castigado = [
   "alias" => "Moderador",
   "mensaje" => "Castigado."
  ];
  $this->jsonCastigado = json_encode($info_castigado);
 }

 /** Se invoca al abrirse una conexión desde un cliente. */
 public function onOpen(ConnectionInterface $conexionDeCliente)
 {
  // Guarda la conexión.
  $this->conexionesDeClientes->attach(
   $conexionDeCliente,
   [
    ID => $conexionDeCliente->resourceId,
    CASTIGADO => false
   ]
  );
  echo "Conectado: " . $conexionDeCliente->resourceId . "\n";
 }

 /** Se invoca al recibir un mensaje de un cliente. */
 public function onMessage(
  ConnectionInterface $conexionDeClienteQueEnvia,
  $json
 ) {
  $conexionesDeClientes = $this->conexionesDeClientes;
  $info = $conexionesDeClientes[$conexionDeClienteQueEnvia];
  $id = $info[ID];
  $castigado = $info[CASTIGADO];
  /** dto significa objeto de transferencia de datos. */
  $dto = json_decode($json);
  $alias = $dto->alias;
  $mensaje = $dto->mensaje;

  if ($castigado && $mensaje === PERDONAME) {
   $castigado = false;
  } elseif ($castigado && $mensaje !== PERDONAME) {
   $conexionDeClienteQueEnvia->send($this->jsonCastigado);
  } elseif (preg_match("/(^|\s+)wey($|\s+)/i", $mensaje) !== 0) {
   $castigado = true;
   $conexionDeClienteQueEnvia->send($this->jsonCastigado);
  }
  $info[CASTIGADO] = $castigado;
  $conexionesDeClientes[$conexionDeClienteQueEnvia] = $info;
  $textoDeCastigado = $castigado ? "true" : "false";
  echo "
Origen: {$id}
Castigado: {$textoDeCastigado}
alias: {$alias}
Mensaje: {$mensaje}
";
  if (!$castigado) {
   for (
    $conexionesDeClientes->rewind();
    $conexionesDeClientes->valid();
    $conexionesDeClientes->next()
   ) {
    $conexionDeCliente = $conexionesDeClientes->current();
    $info = $conexionesDeClientes->getInfo();
    var_dump($info);
    if (!$info[CASTIGADO]) {
     $conexionDeCliente->send($json);
    }
   }
  }
 }

 /** Se invoca al cerrar la conexión de un cliente. */
 public function onClose(ConnectionInterface $conexionDeCliente)
 {
  $this->conexionesDeClientes->detach($conexionDeCliente);
  echo "Desconectado: " . $conexionDeCliente->resourceId . "\n";
 }

 /** Se invoca cuando hay un error en la conexión de un cliente. */
 public function onError(ConnectionInterface $conexionDeCliente, Exception $e)
 {
  echo "Error: " . $e->getMessage() . "\n";
  $conexionDeCliente->close();
 }
}
